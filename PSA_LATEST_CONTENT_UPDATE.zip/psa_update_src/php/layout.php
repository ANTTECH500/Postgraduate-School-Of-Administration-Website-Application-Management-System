<?php
// Shared layout for PSA public pages and portal pages.
function renderHead(string $title = 'PSA', string $extraCSS = ''): void {
    $siteTitle = h($title . ' | PSA - Postgraduate School of Administration');
    $desc = 'PSA provides education recruitment, admissions support, program guidance, scholarships information, student portal services and partner university pathways.';
    $css = asset('css/style.css');
    echo <<<HTML
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="{$desc}">
<meta name="theme-color" content="#0B1F3A">
<title>{$siteTitle}</title>
<link rel="stylesheet" href="{$css}">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&family=Playfair+Display:wght@700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
{$extraCSS}
</head>
<body>
HTML;
}

function navItem(string $href, string $label, string $activePage, string $key): string {
    $active = $activePage === $key ? 'active' : '';
    return '<li><a class="'.$active.'" href="'.h(url($href)).'">'.h($label).'</a></li>';
}

function renderHeader(string $activePage = ''): void {
    $user = currentUser();
    $portalLink = $user ? 'student/dashboard.php' : 'login.php';
    $portalText = $user ? 'My Portal' : 'Student Portal';
    $phone = h(SITE_PHONE); $email = h(SITE_EMAIL); $whatsapp = h(SITE_WHATSAPP);
    $home = h(url('index.php')); $portal = h(url($portalLink)); $login = h(url('login.php'));
    $apply = h(url('student/apply.php')); $contact = h(url('contact.php'));
    echo <<<HTML
<div class="top-strip">
  <div class="container top-strip-inner">
    <div><i class="fa-solid fa-graduation-cap"></i> Education Recruitment • Admissions Support • Student Guidance</div>
    <div class="top-links"><a href="tel:{$phone}"><i class="fa fa-phone"></i> {$phone}</a><a href="mailto:{$email}"><i class="fa fa-envelope"></i> {$email}</a><a target="_blank" href="https://wa.me/{$whatsapp}"><i class="fab fa-whatsapp"></i> WhatsApp</a></div>
  </div>
</div>
<header class="site-header" id="siteHeader">
  <div class="container nav-wrap">
    <a href="{$home}" class="brand" aria-label="PSA Home">
      <span class="brand-mark">C</span>
      <span class="brand-text"><strong>PSA</strong><small>Postgraduate School of Administration</small></span>
    </a>
    <button class="nav-toggle" id="navToggle" aria-label="Open Menu"><span></span><span></span><span></span></button>
    <nav class="main-nav" id="mainNav" aria-label="Main Navigation">
      <ul>
HTML;
    echo navItem('index.php','Home',$activePage,'home');
    echo '<li class="has-menu"><a class="'.($activePage==='about'?'active':'').'" href="'.h(url('about.php')).'">About PSA <i class="fa fa-angle-down"></i></a><div class="drop-menu"><a href="'.h(url('about.php#who-we-are')).'">Who We Are</a><a href="'.h(url('about.php#mission')).'">Mission & Vision</a><a href="'.h(url('about.php#values')).'">Core Values</a><a href="'.h(url('about.php#why-choose')).'">Why Choose PSA</a></div></li>';
    echo '<li class="has-mega"><a class="'.($activePage==='programs'?'active':'').'" href="'.h(url('programs.php')).'">Programs <i class="fa fa-angle-down"></i></a><div class="mega-menu"><div class="mega-intro"><h3>Explore Programs</h3><p>Find undergraduate and postgraduate academic opportunities aligned with your academic goals.</p><a class="btn btn-gold" href="'.h(url('programs.php')).'">View All Programs</a></div><div><h4>Study Levels</h4><a href="'.h(url('programs.php?level=undergraduate')).'">Undergraduate</a><a href="'.h(url('programs.php?level=postgraduate')).'">Postgraduate</a><a href="'.h(url('programs.php?level=certificate')).'">Certificates</a><a href="'.h(url('programs.php?level=online')).'">Online Learning</a></div><div><h4>Services</h4><a href="'.h(url('admissions.php')).'">How to Apply</a><a href="'.h(url('scholarships.php')).'">Scholarships</a><a href="'.h(url('universities.php')).'">Partner Universities</a><a href="'.h(url('contact.php')).'">Speak to an Advisor</a></div></div></li>';
    echo navItem('universities.php','Partner Universities',$activePage,'universities');
    echo navItem('scholarships.php','Scholarships',$activePage,'scholarships');
    echo navItem('admissions.php','Admissions',$activePage,'admissions');
    echo navItem('events.php','Events',$activePage,'events');
    echo navItem('blog.php','Blog',$activePage,'blog');
    echo navItem('contact.php','Contact',$activePage,'contact');
    echo <<<HTML
      </ul>
      <div class="nav-actions mobile-only"><a class="btn btn-outline" href="{$contact}">Book Consultation</a><a class="btn btn-gold" href="{$portal}">{$portalText}</a></div>
    </nav>
    <div class="nav-actions desktop-only"><a class="btn btn-outline" href="{$contact}">Book Consultation</a><a class="btn btn-gold" href="{$portal}">{$portalText}</a></div>
  </div>
</header>
HTML;
}

function renderFooter(): void {
    $year = date('Y'); $email=h(SITE_EMAIL); $phone=h(SITE_PHONE); $wa=h(SITE_WHATSAPP);
    $uIndex=h(url('index.php')); $uAbout=h(url('about.php')); $uPrograms=h(url('programs.php')); $uUniversities=h(url('universities.php'));
    $uScholarships=h(url('scholarships.php')); $uEvents=h(url('events.php')); $uAdmissions=h(url('admissions.php')); $uApply=h(url('student/apply.php'));
    $uLogin=h(url('login.php')); $uContact=h(url('contact.php')); $uUnder=h(url('programs.php?level=undergraduate')); $uPost=h(url('programs.php?level=postgraduate'));
    $js=h(asset('js/main.js'));
    echo <<<HTML
<footer class="site-footer">
  <div class="container footer-grid">
    <div>
      <a href="{$uIndex}" class="brand footer-brand"><span class="brand-mark">C</span><span class="brand-text"><strong>PSA</strong><small>Education Recruitment & Admissions Support</small></span></a>
      <p>PSA supports students with program guidance, admissions assistance, scholarships information, document support and online application services from first inquiry to enrollment.</p>
      <div class="socials"><a href="#"><i class="fab fa-facebook-f"></i></a><a href="#"><i class="fab fa-linkedin-in"></i></a><a href="#"><i class="fab fa-instagram"></i></a><a target="_blank" href="https://wa.me/{$wa}"><i class="fab fa-whatsapp"></i></a></div>
    </div>
    <div><h4>Quick Links</h4><a href="{$uAbout}">About PSA</a><a href="{$uPrograms}">Programs</a><a href="{$uUniversities}">Partner Universities</a><a href="{$uScholarships}">Scholarships</a><a href="{$uEvents}">Events</a></div>
    <div><h4>Admissions</h4><a href="{$uAdmissions}">How to Apply</a><a href="{$uUnder}">Undergraduate</a><a href="{$uPost}">Postgraduate</a><a href="{$uApply}">Apply Online</a><a href="{$uLogin}">Student Portal</a></div>
    <div><h4>Contact</h4><p><i class="fa fa-location-dot"></i> Ghana</p><p><i class="fa fa-phone"></i> <a href="tel:{$phone}">{$phone}</a></p><p><i class="fa fa-envelope"></i> <a href="mailto:{$email}">{$email}</a></p><a class="btn btn-gold footer-cta" href="{$uContact}">Speak to an Advisor</a></div>
  </div>
  <div class="container footer-bottom"><span>© {$year} PSA. All rights reserved.</span><span>Built for education recruitment, admissions, CRM and student support.</span></div>
</footer>
<button id="scrollTop" class="scroll-top" aria-label="Back to top"><i class="fa fa-chevron-up"></i></button>
<script src="{$js}"></script>
</body></html>
HTML;
}

function pageHero(string $kicker, string $title, string $text, string $bg = ''): void {
    $style = $bg ? " style=\"background-image:linear-gradient(135deg,rgba(11,31,58,.96),rgba(11,31,58,.78)),url('".h($bg)."')\"" : '';
    echo '<section class="page-hero"'.$style.'><div class="container"><div class="hero-kicker">'.h($kicker).'</div><h1>'.h($title).'</h1><p>'.h($text).'</p><div class="hero-actions"><a class="btn btn-gold" href="'.h(url('admissions.php')).'">Apply Now</a><a class="btn btn-white" href="'.h(url('contact.php')).'">Book Consultation</a></div></div></section>';
}
?>
