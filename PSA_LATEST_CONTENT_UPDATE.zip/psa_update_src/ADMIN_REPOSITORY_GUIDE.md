# PSA Enhanced Admin Repository Guide

This package expands the admin system from a single file into a functional admin repository.

## Admin Modules Added

1. `admin/login.php`
2. `admin/dashboard.php`
3. `admin/applications.php`
4. `admin/application-view.php`
5. `admin/students.php`
6. `admin/documents.php`
7. `admin/messages.php`
8. `admin/programs.php`
9. `admin/partners.php`
10. `admin/notices.php`
11. `admin/lms.php`
12. `admin/reports.php`
13. `admin/settings.php`
14. `admin/logout.php`
15. `admin/auth.php`
16. `admin/admin-header.php`
17. `admin/admin-footer.php`

## Admin Login

After importing the updated `database.sql`, use:

Email: `admin@cosbagh.com`  
Password: `Admin@12345`

Change this password after first login.

## Purpose of Key Modules

### Applications
Review applications, filter records, view applicant details, assign advisors, update application status, add notes, and automatically notify students.

### Students
Search and view registered students, reference codes, Student IDs and contact information.

### Documents
Review uploaded files and mark documents as Verified or Rejected.

### Messages
Send messages to students through the student portal.

### Programs
Add and manage PSA programs such as Executive Doctorate, International Masters, professional certificates, OHS, strategic management, accounting and audit administration.

### Partners
Track partner institutions and partnership status, including active, under review, suspended or terminated.

### Notices
Manage official notices such as student protection, transfer guidance, academic review updates and partnership updates.

### LMS
Create LMS-ready learning content such as orientation, document preparation guide and scholarship readiness sessions.

### Reports
View basic application status and program-based summaries.

### Settings
Manage PSA institutional profile:
- Address: Behind Kumasi Technical University, Kumasi
- GPS: AK-040-9257
- Phones: +233 32 219 4448
- Website: cosbagh.com

## Deployment

1. Backup current `public_html`.
2. Upload the ZIP into `public_html`.
3. Extract the files.
4. Import `database.sql` into phpMyAdmin.
5. Update `config.php` database credentials.
6. Open `/admin/login.php`.
7. Login with default credentials.
8. Change default password in a future password-management phase.

## Next Recommended Admin Enhancements

- Password change page
- User role management
- CSV/Excel export
- Email sending with SMTP
- WhatsApp notification API
- Student transfer workflow
- Payment tracking
- Full LMS lesson/content upload
- Audit logs
- Dashboard charts using Chart.js
