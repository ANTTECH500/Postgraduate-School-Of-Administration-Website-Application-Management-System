# PSA Web Application – Upgrade & Deployment Notes

## Project identity
The application branding is now **Postgraduate School of Administration (PSA)**.
The production domain remains **https://cosbagh.com** unless the institution changes its domain later.

## What was upgraded
- PSA branding applied across the PHP application and database seed content.
- Modern responsive public UI using Montserrat + Roboto.
- Bootstrap 5.3 CSS/JS and Bootstrap Icons integrated.
- jQuery 3.7.1 retained and used for UI enhancements.
- Font Awesome 4.7 retained for the requested icon style.
- Responsive mobile navigation, forms, cards, tables and portals.
- Modern application form with CSRF protection, password visibility control and generated Student ID / Reference / Application codes.
- Student login redesigned and supports email, Student ID or Reference Code.
- Application tracking redesigned with timeline/status information.
- Student portal profile and applications pages consolidated onto the current database schema.
- Legacy broken login/application modules redirected or replaced so they no longer depend on missing legacy `users` / `student_profiles` functions.
- Admin login secured with CSRF protection and session regeneration.
- Admin settings now includes administrator password change.
- Accreditation/partner logo layout fixed to a responsive flex/grid presentation and broken image references removed.
- Added `/category/learning/` to eliminate the reported 404 route.
- Added `sitemap.xml`, dynamic `sitemap.php`, and `robots.txt`.
- Added an additive production database migration for the stated PSA program catalogue.
- Existing student/application/LMS data is preserved by the production migration; it does not delete operational records.
- PHP syntax was checked across the project.

## Database deployment
### New installation
Import:
1. `database.sql`

### Existing production database
Back up the database first, then import:
- `database/psa_production_migration.sql`

Do **not** overwrite the live database with a fresh `database.sql` if it already contains real students/applications.

## cPanel deployment
1. Back up the current `public_html` and database.
2. Upload the contents of this package to `public_html`.
3. Keep the existing database credentials in `config.php`, or preferably set the supported `PSA_DB_HOST`, `PSA_DB_NAME`, `PSA_DB_USER`, and `PSA_DB_PASS` environment values on the server.
4. Confirm PHP 8.1+ is selected.
5. Set normal permissions: files 0644, directories 0755. Make only the upload directory writable as required by the hosting setup.
6. Import the production migration if the database already exists.
7. Change the administrator password immediately from **Admin → Settings → Change Password**.
8. Test:
   - `/`
   - `/programs.php`
   - `/apply.php`
   - `/student-login.php`
   - `/track-application.php`
   - `/category/learning/`
   - `/accreditations.php`
   - `/admin/login.php`
   - `/sitemap.xml`
9. Clear browser/CDN/cache if the old CSS or JS is still displayed.

## Important
The database seed contains a default administrator account for fresh installation. Change that password immediately after the first login. Never publish administrator credentials or the database password.

## External front-end libraries
- Google Fonts: Montserrat + Roboto
- jQuery 3.7.1
- Bootstrap 5.3.3
- Bootstrap Icons 1.11.3
- Font Awesome 4.7
- Swiper 11 for the existing hero carousel

The site can continue to use downloaded Flaticon assets where a specific Flaticon icon is preferred; the UI does not depend on Flaticon CDN delivery.
