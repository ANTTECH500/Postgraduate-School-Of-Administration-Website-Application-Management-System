# PSA Academic Programmes Reconciliation

Source: `PROFESSIONAL PROGRAMS(1).docx`
Current production baseline: 309 existing records
Authoritative source catalogue: 293 records

## Reconciliation

- Certified: 93 source records; all represented in the current project.
- Chartered: 103 source records; all represented.
- Fellow: 97 source records; all represented.
- Total Master: 293.
- Existing unmatched/legacy: 16.
- Records deleted: 0.

## Legacy records retained

- Chartered Anti Money Laundering Consultancy ChAMC
- Chartered Compliance Management ChCO
- Chartered Municipal Finance Management Practition ChMFMP
- Chartered Municipal Financial Management Accountancy CCMFMA
- Chartered Public Finance Management Accountancy ChPFMA
- Chartered Insurance Professional CCIP
- Chartered Banking CCB
- Chartered Personal Executive Assistantship CPEA
- Chartered Risk Management ChRM
- Chartered Operational Risk Management ChORM
- Chartered Governance Audit Ch.GA
- Chartered Marketing ChM
- Chartered Transport and Logistics Management ChTL
- Chartered Procurement Management ChP
- Chartered Strategic Management ChS
- Chartered Occupational Health and Safety Management ChHS

These records are retained as `catalogue_status = Legacy` and are excluded from the public Master catalogue. They remain available to administrators for historical review.

## Public catalogue rule

A professional programme is publicly listed only when:
- `catalogue_status = 'Master'`
- `status = 'Active'`

## Application rule

Applications may store:
- `program_id` for academic programmes
- `professional_program_id` for professional programmes

The professional programme relationship is therefore explicit and does not depend on free-text `preferred_program`.

## Source fidelity

Programme titles and ordering are based on the supplied document. No additional programmes were invented and the 16 unmatched production records were not silently removed.
