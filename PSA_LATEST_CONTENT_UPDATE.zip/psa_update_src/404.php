<?php
http_response_code(404);
include 'includes/header.php';
?>
<section class="module-hero"><div><div class="eyebrow">404 Error</div><h1>Page Not Found</h1><p>The page you requested may have moved or may no longer be available.</p><div class="hero-actions"><a class="btn btn-gold" href="/"><i class="fa fa-home"></i> Go Home</a><a class="btn btn-white" href="/programs.php"><i class="fa fa-graduation-cap"></i> Explore Programs</a></div></div></section>
<?php include 'includes/footer.php'; ?>