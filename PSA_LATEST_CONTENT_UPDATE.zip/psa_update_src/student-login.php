<?php
require_once __DIR__ . '/config.php';

$error = null;
if (!empty($_SESSION['student_id'])) {
    redirect_to('/student/dashboard.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf()) {
        $error = 'Your session expired. Please refresh and try again.';
    } else {
        $identifier = clean_input($_POST['identifier'] ?? '');
        $password = $_POST['password'] ?? '';

        $stmt = $pdo->prepare('SELECT * FROM students WHERE email=? OR student_id=? OR reference_code=? LIMIT 1');
        $stmt->execute([$identifier, $identifier, $identifier]);
        $student = $stmt->fetch();

        if ($student && password_verify($password, $student['password_hash'])) {
            session_regenerate_id(true);
            $_SESSION['student_id'] = (int)$student['id'];
            redirect_to('/student/dashboard.php');
        }
        $error = 'Invalid Student ID, Reference Code, email or password.';
    }
}
?>
<?php include 'includes/header.php'; ?>
<section class="auth-shell">
  <div class="auth-card">
    <div class="auth-side">
      <img src="/assets/images/psa-logo.png" alt="PSA logo">
      <div class="eyebrow">PSA Student Portal</div>
      <h2>Your admissions journey, in one place.</h2>
      <ul class="list-unstyled">
        <li><i class="fa fa-check-circle"></i> Track application progress</li>
        <li><i class="fa fa-check-circle"></i> Receive PSA messages and notices</li>
        <li><i class="fa fa-check-circle"></i> Manage supporting documents</li>
        <li><i class="fa fa-check-circle"></i> Access available LMS resources</li>
      </ul>
    </div>
    <div class="auth-form">
      <div class="eyebrow">Secure Login</div>
      <h1>Welcome Back</h1>
      <p class="text-muted">Use your email, Student ID or Reference Code.</p>
      <?php if ($error): ?><div class="alert error"><i class="fa fa-exclamation-circle"></i> <?= e($error) ?></div><?php endif; ?>
      <form method="post" class="form-card" style="box-shadow:none;border:0;padding:0" novalidate>
        <?= csrf_field() ?>
        <div class="form-group"><label>Email / Student ID / Reference Code</label><input name="identifier" required autocomplete="username" placeholder="e.g. PSA-2026-AB12CD34"></div>
        <div class="form-group"><label>Password</label>
          <div class="password-wrap"><input id="loginPassword" type="password" name="password" required autocomplete="current-password"><button class="password-toggle" type="button" data-password-toggle="loginPassword" aria-label="Show password"><i class="fa fa-eye"></i></button></div>
        </div>
        <button class="btn btn-gold w-100" type="submit"><i class="fa fa-sign-in"></i> Sign In</button>
      </form>
      <div class="mt-4 p-3 rounded-3" style="background:#F7F9FC">
        <strong>New applicant?</strong><p class="mb-2 text-muted">Apply online to receive your Student ID and Reference Code.</p>
        <a class="btn btn-outline" href="/apply.php"><i class="fa fa-user-plus"></i> Start Application</a>
      </div>
      <p class="small text-muted mt-3 mb-0">Need assistance? Call +233 32 219 4448 or WhatsApp +233 242 684 348.</p>
    </div>
  </div>
</section>
<?php include 'includes/footer.php'; ?>