<?php
http_response_code(403);
include 'includes/header.php';
?>
<section class="module-hero"><div><div class="eyebrow">403 Error</div><h1>Access Restricted</h1><p>You do not have permission to access this resource.</p><div class="hero-actions"><a class="btn btn-gold" href="/"><i class="fa fa-home"></i> Go Home</a><a class="btn btn-white" href="/student-login.php"><i class="fa fa-user"></i> Student Login</a></div></div></section>
<?php include 'includes/footer.php'; ?>