# Professional Programmes Module — Disabled

The Professional Programmes catalogue is intentionally **unloaded from the public PSA website and new applications** per the latest management instruction.

- Existing database records are preserved; no catalogue data is deleted.
- The public navigation and sitemap no longer expose the professional-programmes pages.
- New applications select only academic programmes.
- Legacy professional-programme fields remain for historical application records and can be reactivated later if management approves.
