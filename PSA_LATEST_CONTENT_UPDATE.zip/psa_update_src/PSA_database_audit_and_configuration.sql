-- ============================================================
-- PSA DATABASE AUDIT & CONFIGURATION QUERIES
-- Database: psaiaogy_db
-- Run in phpMyAdmin AFTER selecting psaiaogy_db
-- This file READS the database only (except the optional settings
-- section at the bottom).
-- ============================================================

-- 1. Confirm the active database
SELECT DATABASE() AS current_database;

-- 2. Show all tables
SHOW TABLES;

-- 3. Check required PSA tables
SELECT
    t.table_name AS table_name,
    CASE
        WHEN t.table_name IS NOT NULL THEN 'FOUND'
        ELSE 'MISSING'
    END AS status
FROM (
    SELECT 'programs' AS table_name
    UNION ALL SELECT 'students'
    UNION ALL SELECT 'applications'
    UNION ALL SELECT 'documents'
    UNION ALL SELECT 'messages'
    UNION ALL SELECT 'tracking_logs'
    UNION ALL SELECT 'lms_courses'
    UNION ALL SELECT 'lms_enrollments'
    UNION ALL SELECT 'admins'
    UNION ALL SELECT 'partners'
    UNION ALL SELECT 'notices'
    UNION ALL SELECT 'system_settings'
    UNION ALL SELECT 'professional_programs'
) required
LEFT JOIN information_schema.tables t
    ON t.table_schema = DATABASE()
   AND t.table_name = required.table_name;

-- 4. Table row counts
SELECT 'programs' AS table_name, COUNT(*) AS row_count FROM programs
UNION ALL SELECT 'students', COUNT(*) FROM students
UNION ALL SELECT 'applications', COUNT(*) FROM applications
UNION ALL SELECT 'documents', COUNT(*) FROM documents
UNION ALL SELECT 'messages', COUNT(*) FROM messages
UNION ALL SELECT 'tracking_logs', COUNT(*) FROM tracking_logs
UNION ALL SELECT 'lms_courses', COUNT(*) FROM lms_courses
UNION ALL SELECT 'lms_enrollments', COUNT(*) FROM lms_enrollments
UNION ALL SELECT 'admins', COUNT(*) FROM admins
UNION ALL SELECT 'partners', COUNT(*) FROM partners
UNION ALL SELECT 'notices', COUNT(*) FROM notices
UNION ALL SELECT 'system_settings', COUNT(*) FROM system_settings
UNION ALL SELECT 'professional_programs', COUNT(*) FROM professional_programs;

-- 5. Programs currently in the database
SELECT
    id,
    title,
    level,
    category,
    duration,
    study_mode,
    tuition,
    intake,
    status
FROM programs
ORDER BY level, category, title;

-- 6. Student table structure
DESCRIBE students;

-- 7. Application table structure
DESCRIBE applications;

-- 8. Document table structure
DESCRIBE documents;

-- 9. Message table structure
DESCRIBE messages;

-- 10. Tracking table structure
DESCRIBE tracking_logs;

-- 11. LMS tables
DESCRIBE lms_courses;
DESCRIBE lms_enrollments;

-- 12. Admin table
DESCRIBE admins;

-- 13. Partners
SELECT id, name, country, website, status, notes, created_at
FROM partners
ORDER BY name;

-- 14. Notices
SELECT id, title, notice_type, status, created_at
FROM notices
ORDER BY created_at DESC;

-- 15. Current PSA site settings
SELECT setting_key, setting_value, updated_at
FROM system_settings
ORDER BY setting_key;

-- 16. Professional programs
SELECT
    id,
    program_type,
    title,
    status,
    created_at
FROM professional_programs
ORDER BY program_type, title;

-- 17. Admin accounts (DO NOT expose password_hash)
SELECT
    id,
    full_name,
    email,
    role,
    created_at
FROM admins
ORDER BY id;

-- 18. Application status summary
SELECT application_status, COUNT(*) AS total
FROM applications
GROUP BY application_status
ORDER BY total DESC;

-- 19. Student status summary
SELECT status, COUNT(*) AS total
FROM students
GROUP BY status
ORDER BY total DESC;

-- 20. Document verification summary
SELECT verification_status, COUNT(*) AS total
FROM documents
GROUP BY verification_status
ORDER BY total DESC;

-- 21. LMS course summary
SELECT status, COUNT(*) AS total
FROM lms_courses
GROUP BY status;

-- 22. Check application foreign-key relationships
SELECT
    a.id,
    a.application_code,
    a.student_id,
    s.student_id AS student_reference,
    a.program_id,
    p.title AS program_title,
    a.application_status
FROM applications a
LEFT JOIN students s ON s.id = a.student_id
LEFT JOIN programs p ON p.id = a.program_id
ORDER BY a.id DESC
LIMIT 100;

-- ============================================================
-- OPTIONAL: STANDARDIZE PSA SETTINGS
-- Run only if these values are correct for your deployment.
-- ============================================================

INSERT INTO system_settings (setting_key, setting_value)
VALUES
('institution_name', 'Postgraduate School of Administration'),
('short_name', 'PSA'),
('website', 'https://pas.institute'),
('email', 'info@pas.institute'),
('phone_1', '+233322194448'),
('phone_2', ''),
('whatsapp', '+233242684348'),
('address', 'Ghana | Behind K. Poly / KsTU, Kumasi'),
('gps_address', 'AK-040-9257'),
('map_query', 'Behind K. Poly / KsTU, Kumasi, Ghana'),
('profile', 'Postgraduate School of Administration (PSA) provides academic guidance, admissions support, professional programmes, student services and digital application support in Ghana.')
ON DUPLICATE KEY UPDATE
    setting_value = VALUES(setting_value);
