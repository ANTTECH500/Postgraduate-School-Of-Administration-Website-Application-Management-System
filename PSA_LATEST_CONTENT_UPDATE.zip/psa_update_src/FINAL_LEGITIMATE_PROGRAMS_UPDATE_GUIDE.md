# PSA Final Legitimate Programs + UI Update

Updates included:
- 48 PSA programs added to website and database seed.
- Partner institutions: Charisma University, Shri Atmanand Jain Institute of Management and Technology, Abia State University via DEO'S International Institute in Nigeria.
- Accreditations page added: accreditations.php.
- Contact updated: +233 32 219 4448.
- Office updated: Behind K. Poly / KsTU, Kumasi.
- jQuery 3.7.1 added.
- Montserrat and Roboto retained.
- Student application form improved.
- Student dashboard improved.
- Admin dashboard improved.
- Accreditation and partner images included.

Deployment:
1. Backup public_html.
2. Upload and extract this ZIP in public_html.
3. Import database.sql in phpMyAdmin.
4. Update config.php database credentials.
5. Visit /admin/login.php.

Default admin:
Email: admin@cosbagh.com
Password: Admin@12345
