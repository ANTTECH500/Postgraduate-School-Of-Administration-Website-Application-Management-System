<?php include '../../includes/header.php'; ?>
<section class="module-hero"><div><div class="eyebrow">PSA Learning Resources</div><h1>Learning & Student Resources</h1><p>Explore practical resources, academic guidance, admissions information and student-support content from PSA.</p></div></section>
<section class="section light"><div class="section-title"><div class="eyebrow">Resources</div><h2>Support Beyond the Application Form</h2><p>PSA's digital platform is designed to support prospective and enrolled students from enquiry through application, tracking and learning.</p></div>
<div class="grid grid-3">
<div class="card"><div class="icon-box"><i class="fa fa-graduation-cap"></i></div><h3>Program Guidance</h3><p>Review available undergraduate and postgraduate programs before choosing an academic pathway.</p><a class="btn btn-gold" href="/programs.php">Explore Programs</a></div>
<div class="card"><div class="icon-box"><i class="fa fa-file-text"></i></div><h3>Admissions Guidance</h3><p>Understand the application process, required information and next steps.</p><a class="btn btn-gold" href="/admissions.php">Admissions Guide</a></div>
<div class="card"><div class="icon-box"><i class="fa fa-comments"></i></div><h3>Student Support</h3><p>Use your Student ID and Reference Code to track applications and access portal services.</p><a class="btn btn-gold" href="/track-application.php">Track Application</a></div>
</div></section>
<?php include '../../includes/footer.php'; ?>