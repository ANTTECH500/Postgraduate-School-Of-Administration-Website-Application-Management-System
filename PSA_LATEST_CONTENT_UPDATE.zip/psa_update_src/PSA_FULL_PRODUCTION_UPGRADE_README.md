# PSA FULL PRODUCTION UPGRADE

This package is based on the current PSA project supplied for review.

## Included upgrades

- Responsive public website and existing PSA visual system.
- Academic Programmes master catalogue.
- Reconciliation of existing 309 professional-programme records:
  - 293 current management-source records = Master.
  - 16 unmatched existing records = Legacy; they are retained and not deleted.
- Professional programme selection in applications.
- Professional programme display in application, tracking and student views.
- Role-based access control (RBAC).
- Super Admin / Admissions Officer / Student Advisor / Content Manager model.
- Granular permissions.
- Sub-Admin Management.
- Administrator account status: Active / Suspended / Inactive.
- Administrator last-login tracking.
- Login-attempt logging.
- Administrator activity/audit log.
- CSRF protection on admin mutations.
- Server-side permission checks.
- Secure password hashing with password_verify/password_hash.
- Improved admin login session handling.
- SEO canonical URL handling.
- Dynamic XML sitemap endpoint and `/sitemap.xml` rewrite.
- robots.txt.
- Apache protection for config, SQL, logs and sensitive directories.
- Removal of public diagnostic health output from the production package.
- Updated application integration for academic + professional programmes.
- Production deployment documentation.

## Current production database

The supplied project uses:

Host: localhost
Database: psaiaogy_db
User: psaiaogy_info
Site: https://psa.institute

The database password is intentionally NOT reproduced in this document.

## Deployment order

1. Back up `psaiaogy_db` in phpMyAdmin.
2. Back up the live `public_html`.
3. Upload the contents of this package to the PSA document root.
4. Preserve the production `config.php` values if they are already correct.
5. In phpMyAdmin select `psaiaogy_db`.
6. Import ONLY:
   `database/PSA_PRODUCTION_UPGRADE.sql`
7. Verify:
   `SELECT catalogue_status, COUNT(*) FROM professional_programs GROUP BY catalogue_status;`
   Expected:
   Master = 293
   Legacy = 16
8. Verify:
   `SELECT program_type, COUNT(*) FROM professional_programs WHERE catalogue_status='Master' GROUP BY program_type;`
   Expected:
   Certified = 93
   Chartered = 103
   Fellow = 97
9. Test `/admin/login.php`.
10. Test `/admin/sub-admins.php` using the Super Admin.
11. Test `/admin/professional-programs.php`.
12. Test `/professional-programs.php`.
13. Test `/apply.php?professional_program_id=...`.
14. Test `/sitemap.xml`.
15. Test `/robots.txt`.

## Do not

- Do not import `psa_database.sql` over the existing production database.
- Do not delete the 16 Legacy professional-programme records.
- Do not expose `config.php`.
- Do not leave database diagnostic scripts publicly accessible.
- Do not reuse the temporary administrator password as a permanent credential.

## Professional catalogue policy

The public site displays only records marked:
`catalogue_status = Master`
and
`status = Active`.

Legacy records remain available to administrators for historical/audit purposes.

## Security

Rotate the production MySQL password if the credential has been exposed outside the trusted deployment environment.


# Phase 2 — Connected Management Platform

The package now also contains the Phase 2 management platform:

- CRM / admissions inquiry capture from the public Contact page.
- Inquiry queue with assignment, status and follow-up dates.
- Admissions Kanban-style pipeline.
- Normalized admissions stage history.
- Application document/admission checklist with verification status.
- Student notifications.
- Functional student-to-PSA messaging.
- Payment ledger and student payment history.
- Management KPI dashboard.
- Applications CSV export.
- Professional programme linkage throughout the admissions/reporting layer.

## Phase 2 deployment

For an existing database, import:

`database/PSA_PHASE_2_MIGRATION.sql`

or, on a fresh deployment sequence, use the complete:

`database/PSA_PRODUCTION_UPGRADE.sql`

after the base production upgrade.

Recommended order for an existing live site:

1. Backup database and files.
2. Upload the upgraded project.
3. Import `PSA_PRODUCTION_UPGRADE.sql` only if the Phase 1 migration has not yet been run.
4. If Phase 1 has already been run on the live database, import `PSA_PHASE_2_MIGRATION.sql`.
5. Test the public Contact form and verify a new inquiry appears in `/admin/inquiries.php`.
6. Test `/admin/admissions-pipeline.php`.
7. Open an application and verify its checklist and stage history.
8. Test student `/student/messages.php`, `/student/notifications.php` and `/student/payments.php`.
9. Test `/admin/reports.php` and CSV export.

The payment module is currently a payment-record ledger; it does not claim to be a live payment gateway. Provider credentials and gateway callbacks must be configured separately before accepting online payments.
