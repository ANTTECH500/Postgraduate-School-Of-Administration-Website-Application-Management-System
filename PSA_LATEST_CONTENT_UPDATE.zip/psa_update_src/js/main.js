/**
 * PSA legacy compatibility layer.
 * The primary public-site interaction layer is assets/js/psa-modern.js.
 * This file remains safe for legacy layouts that use navToggle/mainNav.
 */
(function () {
    'use strict';

    document.addEventListener('DOMContentLoaded', function () {
        const toggle = document.getElementById('navToggle');
        const nav = document.getElementById('mainNav');

        if (toggle && nav) {
            toggle.addEventListener('click', function () {
                const open = nav.classList.toggle('show');
                toggle.classList.toggle('open', open);
                toggle.setAttribute('aria-expanded', String(open));
            });
        }

        document.querySelectorAll('.has-menu, .has-mega').forEach(function (item) {
            const link = item.querySelector(':scope > a');
            if (!link) return;

            link.addEventListener('click', function (event) {
                if (window.innerWidth <= 1180) {
                    event.preventDefault();
                    item.classList.toggle('open');
                }
            });
        });

        const top = document.getElementById('scrollTop');
        if (top) {
            const update = function () {
                top.classList.toggle('show', window.scrollY > 450);
            };
            window.addEventListener('scroll', update, { passive: true });
            update();

            top.addEventListener('click', function () {
                window.scrollTo({ top: 0, behavior: 'smooth' });
            });
        }

        document.querySelectorAll('.faq-question').forEach(function (question) {
            question.addEventListener('click', function () {
                const item = question.closest('.faq-item');
                if (!item) return;
                item.classList.toggle('active');
                const icon = question.querySelector('i');
                if (icon) {
                    icon.className = item.classList.contains('active')
                        ? 'fa fa-minus'
                        : 'fa fa-plus';
                }
            });
        });
    });
})();
