-- PSA production migration
-- Safe, additive migration. Run after backing up the database.
-- It does not delete student, application, document, message or LMS data.

UPDATE system_settings
SET setting_value = REPLACE(REPLACE(setting_value, 'PSA', 'PSA'), 'Postgraduate School of Administration', 'Postgraduate School of Administration')
WHERE setting_value LIKE '%PSA%' OR setting_value LIKE '%Postgraduate School of Administration%';

UPDATE programs
SET description = REPLACE(REPLACE(description, 'PSA', 'PSA'), 'Postgraduate School of Administration', 'Postgraduate School of Administration')
WHERE description LIKE '%PSA%' OR description LIKE '%Postgraduate School of Administration%';

UPDATE notices
SET title = REPLACE(REPLACE(title, 'PSA', 'PSA'), 'Postgraduate School of Administration', 'Postgraduate School of Administration'),
    content = REPLACE(REPLACE(content, 'PSA', 'PSA'), 'Postgraduate School of Administration', 'Postgraduate School of Administration')
WHERE title LIKE '%PSA%' OR content LIKE '%PSA%'
   OR title LIKE '%Postgraduate School of Administration%'
   OR content LIKE '%Postgraduate School of Administration%';

UPDATE partners
SET notes = REPLACE(REPLACE(notes, 'PSA', 'PSA'), 'Postgraduate School of Administration', 'Postgraduate School of Administration')
WHERE notes LIKE '%PSA%' OR notes LIKE '%Postgraduate School of Administration%';

INSERT INTO programs (title,level,category,duration,study_mode,tuition,intake,description,status)
SELECT 'PhD Law','Doctorate','Law','Contact PSA','Hybrid / Supported Learning','Contact PSA','Contact PSA','PhD Law is included in PSA''s current program catalogue. Contact PSA for current admission requirements, awarding institution, fees, intake and study route.','Active'
WHERE NOT EXISTS (SELECT 1 FROM programs WHERE title='PhD Law');

INSERT INTO programs (title,level,category,duration,study_mode,tuition,intake,description,status)
SELECT 'PhD Health Sciences','Doctorate','Health Sciences','Contact PSA','Hybrid / Supported Learning','Contact PSA','Contact PSA','PhD Health Sciences is included in PSA''s current program catalogue. Contact PSA for current admission requirements, awarding institution, fees, intake and study route.','Active'
WHERE NOT EXISTS (SELECT 1 FROM programs WHERE title='PhD Health Sciences');

INSERT INTO programs (title,level,category,duration,study_mode,tuition,intake,description,status)
SELECT 'PhD Psychology','Doctorate','Psychology','Contact PSA','Hybrid / Supported Learning','Contact PSA','Contact PSA','PhD Psychology is included in PSA''s current program catalogue. Contact PSA for current admission requirements, awarding institution, fees, intake and study route.','Active'
WHERE NOT EXISTS (SELECT 1 FROM programs WHERE title='PhD Psychology');

INSERT INTO programs (title,level,category,duration,study_mode,tuition,intake,description,status)
SELECT 'PhD Theology','Doctorate','Theology','Contact PSA','Hybrid / Supported Learning','Contact PSA','Contact PSA','PhD Theology is included in PSA''s current program catalogue. Contact PSA for current admission requirements, awarding institution, fees, intake and study route.','Active'
WHERE NOT EXISTS (SELECT 1 FROM programs WHERE title='PhD Theology');

INSERT INTO programs (title,level,category,duration,study_mode,tuition,intake,description,status)
SELECT 'PhD Forensic Accounting and Audit','Doctorate','Accounting & Audit','Contact PSA','Hybrid / Supported Learning','Contact PSA','Contact PSA','PhD Forensic Accounting and Audit is included in PSA''s current program catalogue. Contact PSA for current admission requirements, awarding institution, fees, intake and study route.','Active'
WHERE NOT EXISTS (SELECT 1 FROM programs WHERE title='PhD Forensic Accounting and Audit');

INSERT INTO programs (title,level,category,duration,study_mode,tuition,intake,description,status)
SELECT 'PhD Cyber security Administration','Doctorate','Cyber Security','Contact PSA','Hybrid / Supported Learning','Contact PSA','Contact PSA','PhD Cyber security Administration is included in PSA''s current program catalogue. Contact PSA for current admission requirements, awarding institution, fees, intake and study route.','Active'
WHERE NOT EXISTS (SELECT 1 FROM programs WHERE title='PhD Cyber security Administration');

INSERT INTO programs (title,level,category,duration,study_mode,tuition,intake,description,status)
SELECT 'PhD Business Administration','Doctorate','Business Administration','Contact PSA','Hybrid / Supported Learning','Contact PSA','Contact PSA','PhD Business Administration is included in PSA''s current program catalogue. Contact PSA for current admission requirements, awarding institution, fees, intake and study route.','Active'
WHERE NOT EXISTS (SELECT 1 FROM programs WHERE title='PhD Business Administration');

INSERT INTO programs (title,level,category,duration,study_mode,tuition,intake,description,status)
SELECT 'Doctor of Nursing Practice','Doctorate','Nursing','Contact PSA','Hybrid / Supported Learning','Contact PSA','Contact PSA','Doctor of Nursing Practice is included in PSA''s current program catalogue. Contact PSA for current admission requirements, awarding institution, fees, intake and study route.','Active'
WHERE NOT EXISTS (SELECT 1 FROM programs WHERE title='Doctor of Nursing Practice');

INSERT INTO programs (title,level,category,duration,study_mode,tuition,intake,description,status)
SELECT 'Doctor of Education','Doctorate','Education','Contact PSA','Hybrid / Supported Learning','Contact PSA','Contact PSA','Doctor of Education is included in PSA''s current program catalogue. Contact PSA for current admission requirements, awarding institution, fees, intake and study route.','Active'
WHERE NOT EXISTS (SELECT 1 FROM programs WHERE title='Doctor of Education');

INSERT INTO programs (title,level,category,duration,study_mode,tuition,intake,description,status)
SELECT 'Doctor of Psychology','Doctorate','Psychology','Contact PSA','Hybrid / Supported Learning','Contact PSA','Contact PSA','Doctor of Psychology is included in PSA''s current program catalogue. Contact PSA for current admission requirements, awarding institution, fees, intake and study route.','Active'
WHERE NOT EXISTS (SELECT 1 FROM programs WHERE title='Doctor of Psychology');

INSERT INTO programs (title,level,category,duration,study_mode,tuition,intake,description,status)
SELECT 'Msc Nursing (Clinical Track)','Masters','Nursing','Contact PSA','Hybrid / Supported Learning','Contact PSA','Contact PSA','Msc Nursing (Clinical Track) is included in PSA''s current program catalogue. Contact PSA for current admission requirements, awarding institution, fees, intake and study route.','Active'
WHERE NOT EXISTS (SELECT 1 FROM programs WHERE title='Msc Nursing (Clinical Track)');

INSERT INTO programs (title,level,category,duration,study_mode,tuition,intake,description,status)
SELECT 'Msc Nursing (Leadership and Management)','Masters','Nursing','Contact PSA','Hybrid / Supported Learning','Contact PSA','Contact PSA','Msc Nursing (Leadership and Management) is included in PSA''s current program catalogue. Contact PSA for current admission requirements, awarding institution, fees, intake and study route.','Active'
WHERE NOT EXISTS (SELECT 1 FROM programs WHERE title='Msc Nursing (Leadership and Management)');

INSERT INTO programs (title,level,category,duration,study_mode,tuition,intake,description,status)
SELECT 'Msc Psychology','Masters','Psychology','Contact PSA','Hybrid / Supported Learning','Contact PSA','Contact PSA','Msc Psychology is included in PSA''s current program catalogue. Contact PSA for current admission requirements, awarding institution, fees, intake and study route.','Active'
WHERE NOT EXISTS (SELECT 1 FROM programs WHERE title='Msc Psychology');

INSERT INTO programs (title,level,category,duration,study_mode,tuition,intake,description,status)
SELECT 'MA Education','Masters','Education','Contact PSA','Hybrid / Supported Learning','Contact PSA','Contact PSA','MA Education is included in PSA''s current program catalogue. Contact PSA for current admission requirements, awarding institution, fees, intake and study route.','Active'
WHERE NOT EXISTS (SELECT 1 FROM programs WHERE title='MA Education');

INSERT INTO programs (title,level,category,duration,study_mode,tuition,intake,description,status)
SELECT 'MA Philosophy','Masters','Philosophy','Contact PSA','Hybrid / Supported Learning','Contact PSA','Contact PSA','MA Philosophy is included in PSA''s current program catalogue. Contact PSA for current admission requirements, awarding institution, fees, intake and study route.','Active'
WHERE NOT EXISTS (SELECT 1 FROM programs WHERE title='MA Philosophy');

INSERT INTO programs (title,level,category,duration,study_mode,tuition,intake,description,status)
SELECT 'Master of Public Health','Masters','Public Health','Contact PSA','Hybrid / Supported Learning','Contact PSA','Contact PSA','Master of Public Health is included in PSA''s current program catalogue. Contact PSA for current admission requirements, awarding institution, fees, intake and study route.','Active'
WHERE NOT EXISTS (SELECT 1 FROM programs WHERE title='Master of Public Health');

INSERT INTO programs (title,level,category,duration,study_mode,tuition,intake,description,status)
SELECT 'Msc Human Resource Management','Masters','Human Resource Management','Contact PSA','Hybrid / Supported Learning','Contact PSA','Contact PSA','Msc Human Resource Management is included in PSA''s current program catalogue. Contact PSA for current admission requirements, awarding institution, fees, intake and study route.','Active'
WHERE NOT EXISTS (SELECT 1 FROM programs WHERE title='Msc Human Resource Management');

INSERT INTO programs (title,level,category,duration,study_mode,tuition,intake,description,status)
SELECT 'Msc Accounting','Masters','Accounting','Contact PSA','Hybrid / Supported Learning','Contact PSA','Contact PSA','Msc Accounting is included in PSA''s current program catalogue. Contact PSA for current admission requirements, awarding institution, fees, intake and study route.','Active'
WHERE NOT EXISTS (SELECT 1 FROM programs WHERE title='Msc Accounting');

INSERT INTO programs (title,level,category,duration,study_mode,tuition,intake,description,status)
SELECT 'Msc Finance','Masters','Finance','Contact PSA','Hybrid / Supported Learning','Contact PSA','Contact PSA','Msc Finance is included in PSA''s current program catalogue. Contact PSA for current admission requirements, awarding institution, fees, intake and study route.','Active'
WHERE NOT EXISTS (SELECT 1 FROM programs WHERE title='Msc Finance');

INSERT INTO programs (title,level,category,duration,study_mode,tuition,intake,description,status)
SELECT 'Msc Economics','Masters','Economics','Contact PSA','Hybrid / Supported Learning','Contact PSA','Contact PSA','Msc Economics is included in PSA''s current program catalogue. Contact PSA for current admission requirements, awarding institution, fees, intake and study route.','Active'
WHERE NOT EXISTS (SELECT 1 FROM programs WHERE title='Msc Economics');

INSERT INTO programs (title,level,category,duration,study_mode,tuition,intake,description,status)
SELECT 'MCA','Masters','Computing','Contact PSA','Hybrid / Supported Learning','Contact PSA','Contact PSA','MCA is included in PSA''s current program catalogue. Contact PSA for current admission requirements, awarding institution, fees, intake and study route.','Active'
WHERE NOT EXISTS (SELECT 1 FROM programs WHERE title='MCA');

INSERT INTO programs (title,level,category,duration,study_mode,tuition,intake,description,status)
SELECT 'LLM','Masters','Law','Contact PSA','Hybrid / Supported Learning','Contact PSA','Contact PSA','LLM is included in PSA''s current program catalogue. Contact PSA for current admission requirements, awarding institution, fees, intake and study route.','Active'
WHERE NOT EXISTS (SELECT 1 FROM programs WHERE title='LLM');

INSERT INTO programs (title,level,category,duration,study_mode,tuition,intake,description,status)
SELECT 'MBA','Masters','Business Administration','Contact PSA','Hybrid / Supported Learning','Contact PSA','Contact PSA','MBA is included in PSA''s current program catalogue. Contact PSA for current admission requirements, awarding institution, fees, intake and study route.','Active'
WHERE NOT EXISTS (SELECT 1 FROM programs WHERE title='MBA');

INSERT INTO programs (title,level,category,duration,study_mode,tuition,intake,description,status)
SELECT 'EMBA','Masters','Business Administration','Contact PSA','Hybrid / Supported Learning','Contact PSA','Contact PSA','EMBA is included in PSA''s current program catalogue. Contact PSA for current admission requirements, awarding institution, fees, intake and study route.','Active'
WHERE NOT EXISTS (SELECT 1 FROM programs WHERE title='EMBA');

INSERT INTO programs (title,level,category,duration,study_mode,tuition,intake,description,status)
SELECT 'MED Curriculum and Instruction','Masters','Education','Contact PSA','Hybrid / Supported Learning','Contact PSA','Contact PSA','MED Curriculum and Instruction is included in PSA''s current program catalogue. Contact PSA for current admission requirements, awarding institution, fees, intake and study route.','Active'
WHERE NOT EXISTS (SELECT 1 FROM programs WHERE title='MED Curriculum and Instruction');

INSERT INTO programs (title,level,category,duration,study_mode,tuition,intake,description,status)
SELECT 'MSc Mass Communication','Masters','Mass Communication','Contact PSA','Hybrid / Supported Learning','Contact PSA','Contact PSA','MSc Mass Communication is included in PSA''s current program catalogue. Contact PSA for current admission requirements, awarding institution, fees, intake and study route.','Active'
WHERE NOT EXISTS (SELECT 1 FROM programs WHERE title='MSc Mass Communication');

INSERT INTO programs (title,level,category,duration,study_mode,tuition,intake,description,status)
SELECT 'MSc Health, Safety and Environment','Masters','Health, Safety & Environment','Contact PSA','Hybrid / Supported Learning','Contact PSA','Contact PSA','MSc Health, Safety and Environment is included in PSA''s current program catalogue. Contact PSA for current admission requirements, awarding institution, fees, intake and study route.','Active'
WHERE NOT EXISTS (SELECT 1 FROM programs WHERE title='MSc Health, Safety and Environment');

INSERT INTO programs (title,level,category,duration,study_mode,tuition,intake,description,status)
SELECT 'M.Phil Public Administration','Masters','Public Administration','Contact PSA','Hybrid / Supported Learning','Contact PSA','Contact PSA','M.Phil Public Administration is included in PSA''s current program catalogue. Contact PSA for current admission requirements, awarding institution, fees, intake and study route.','Active'
WHERE NOT EXISTS (SELECT 1 FROM programs WHERE title='M.Phil Public Administration');

INSERT INTO programs (title,level,category,duration,study_mode,tuition,intake,description,status)
SELECT 'MSc Public Administration','Masters','Public Administration','Contact PSA','Hybrid / Supported Learning','Contact PSA','Contact PSA','MSc Public Administration is included in PSA''s current program catalogue. Contact PSA for current admission requirements, awarding institution, fees, intake and study route.','Active'
WHERE NOT EXISTS (SELECT 1 FROM programs WHERE title='MSc Public Administration');

INSERT INTO programs (title,level,category,duration,study_mode,tuition,intake,description,status)
SELECT 'MPA','Masters','Public Administration','Contact PSA','Hybrid / Supported Learning','Contact PSA','Contact PSA','MPA is included in PSA''s current program catalogue. Contact PSA for current admission requirements, awarding institution, fees, intake and study route.','Active'
WHERE NOT EXISTS (SELECT 1 FROM programs WHERE title='MPA');

INSERT INTO programs (title,level,category,duration,study_mode,tuition,intake,description,status)
SELECT 'MSc Criminology','Masters','Criminology','Contact PSA','Hybrid / Supported Learning','Contact PSA','Contact PSA','MSc Criminology is included in PSA''s current program catalogue. Contact PSA for current admission requirements, awarding institution, fees, intake and study route.','Active'
WHERE NOT EXISTS (SELECT 1 FROM programs WHERE title='MSc Criminology');

INSERT INTO programs (title,level,category,duration,study_mode,tuition,intake,description,status)
SELECT 'MSc Banking and Finance','Masters','Banking & Finance','Contact PSA','Hybrid / Supported Learning','Contact PSA','Contact PSA','MSc Banking and Finance is included in PSA''s current program catalogue. Contact PSA for current admission requirements, awarding institution, fees, intake and study route.','Active'
WHERE NOT EXISTS (SELECT 1 FROM programs WHERE title='MSc Banking and Finance');

INSERT INTO programs (title,level,category,duration,study_mode,tuition,intake,description,status)
SELECT 'MED Education Administration','Masters','Education','Contact PSA','Hybrid / Supported Learning','Contact PSA','Contact PSA','MED Education Administration is included in PSA''s current program catalogue. Contact PSA for current admission requirements, awarding institution, fees, intake and study route.','Active'
WHERE NOT EXISTS (SELECT 1 FROM programs WHERE title='MED Education Administration');

INSERT INTO programs (title,level,category,duration,study_mode,tuition,intake,description,status)
SELECT 'MPhil Law','Masters','Law','Contact PSA','Hybrid / Supported Learning','Contact PSA','Contact PSA','MPhil Law is included in PSA''s current program catalogue. Contact PSA for current admission requirements, awarding institution, fees, intake and study route.','Active'
WHERE NOT EXISTS (SELECT 1 FROM programs WHERE title='MPhil Law');

INSERT INTO programs (title,level,category,duration,study_mode,tuition,intake,description,status)
SELECT 'Msc Marketing','Masters','Marketing','Contact PSA','Hybrid / Supported Learning','Contact PSA','Contact PSA','Msc Marketing is included in PSA''s current program catalogue. Contact PSA for current admission requirements, awarding institution, fees, intake and study route.','Active'
WHERE NOT EXISTS (SELECT 1 FROM programs WHERE title='Msc Marketing');

INSERT INTO programs (title,level,category,duration,study_mode,tuition,intake,description,status)
SELECT 'MSc Agribusiness','Masters','Agribusiness','Contact PSA','Hybrid / Supported Learning','Contact PSA','Contact PSA','MSc Agribusiness is included in PSA''s current program catalogue. Contact PSA for current admission requirements, awarding institution, fees, intake and study route.','Active'
WHERE NOT EXISTS (SELECT 1 FROM programs WHERE title='MSc Agribusiness');

INSERT INTO programs (title,level,category,duration,study_mode,tuition,intake,description,status)
SELECT 'MA International Relations and Cultural Diplomacy','Masters','International Relations','Contact PSA','Hybrid / Supported Learning','Contact PSA','Contact PSA','MA International Relations and Cultural Diplomacy is included in PSA''s current program catalogue. Contact PSA for current admission requirements, awarding institution, fees, intake and study route.','Active'
WHERE NOT EXISTS (SELECT 1 FROM programs WHERE title='MA International Relations and Cultural Diplomacy');

INSERT INTO programs (title,level,category,duration,study_mode,tuition,intake,description,status)
SELECT 'LLB','Undergraduate','Law','Contact PSA','Hybrid / Supported Learning','Contact PSA','Contact PSA','LLB is included in PSA''s current program catalogue. Contact PSA for current admission requirements, awarding institution, fees, intake and study route.','Active'
WHERE NOT EXISTS (SELECT 1 FROM programs WHERE title='LLB');

INSERT INTO programs (title,level,category,duration,study_mode,tuition,intake,description,status)
SELECT 'BA Hospitality and Tourism Management','Undergraduate','Hospitality & Tourism','Contact PSA','Hybrid / Supported Learning','Contact PSA','Contact PSA','BA Hospitality and Tourism Management is included in PSA''s current program catalogue. Contact PSA for current admission requirements, awarding institution, fees, intake and study route.','Active'
WHERE NOT EXISTS (SELECT 1 FROM programs WHERE title='BA Hospitality and Tourism Management');

INSERT INTO programs (title,level,category,duration,study_mode,tuition,intake,description,status)
SELECT 'BA Marketing','Undergraduate','Marketing','Contact PSA','Hybrid / Supported Learning','Contact PSA','Contact PSA','BA Marketing is included in PSA''s current program catalogue. Contact PSA for current admission requirements, awarding institution, fees, intake and study route.','Active'
WHERE NOT EXISTS (SELECT 1 FROM programs WHERE title='BA Marketing');

INSERT INTO programs (title,level,category,duration,study_mode,tuition,intake,description,status)
SELECT 'BCA','Undergraduate','Computing','Contact PSA','Hybrid / Supported Learning','Contact PSA','Contact PSA','BCA is included in PSA''s current program catalogue. Contact PSA for current admission requirements, awarding institution, fees, intake and study route.','Active'
WHERE NOT EXISTS (SELECT 1 FROM programs WHERE title='BCA');

INSERT INTO programs (title,level,category,duration,study_mode,tuition,intake,description,status)
SELECT 'Bsc Human Resource Management','Undergraduate','Human Resource Management','Contact PSA','Hybrid / Supported Learning','Contact PSA','Contact PSA','Bsc Human Resource Management is included in PSA''s current program catalogue. Contact PSA for current admission requirements, awarding institution, fees, intake and study route.','Active'
WHERE NOT EXISTS (SELECT 1 FROM programs WHERE title='Bsc Human Resource Management');

INSERT INTO programs (title,level,category,duration,study_mode,tuition,intake,description,status)
SELECT 'Bsc Nursing','Undergraduate','Nursing','Contact PSA','Hybrid / Supported Learning','Contact PSA','Contact PSA','Bsc Nursing is included in PSA''s current program catalogue. Contact PSA for current admission requirements, awarding institution, fees, intake and study route.','Active'
WHERE NOT EXISTS (SELECT 1 FROM programs WHERE title='Bsc Nursing');

INSERT INTO programs (title,level,category,duration,study_mode,tuition,intake,description,status)
SELECT 'Bsc Finance','Undergraduate','Finance','Contact PSA','Hybrid / Supported Learning','Contact PSA','Contact PSA','Bsc Finance is included in PSA''s current program catalogue. Contact PSA for current admission requirements, awarding institution, fees, intake and study route.','Active'
WHERE NOT EXISTS (SELECT 1 FROM programs WHERE title='Bsc Finance');

INSERT INTO programs (title,level,category,duration,study_mode,tuition,intake,description,status)
SELECT 'Bsc Accounting','Undergraduate','Accounting','Contact PSA','Hybrid / Supported Learning','Contact PSA','Contact PSA','Bsc Accounting is included in PSA''s current program catalogue. Contact PSA for current admission requirements, awarding institution, fees, intake and study route.','Active'
WHERE NOT EXISTS (SELECT 1 FROM programs WHERE title='Bsc Accounting');

INSERT INTO programs (title,level,category,duration,study_mode,tuition,intake,description,status)
SELECT 'Bsc Economics','Undergraduate','Economics','Contact PSA','Hybrid / Supported Learning','Contact PSA','Contact PSA','Bsc Economics is included in PSA''s current program catalogue. Contact PSA for current admission requirements, awarding institution, fees, intake and study route.','Active'
WHERE NOT EXISTS (SELECT 1 FROM programs WHERE title='Bsc Economics');

INSERT INTO programs (title,level,category,duration,study_mode,tuition,intake,description,status)
SELECT 'Bsc Health Sciences','Undergraduate','Health Sciences','Contact PSA','Hybrid / Supported Learning','Contact PSA','Contact PSA','Bsc Health Sciences is included in PSA''s current program catalogue. Contact PSA for current admission requirements, awarding institution, fees, intake and study route.','Active'
WHERE NOT EXISTS (SELECT 1 FROM programs WHERE title='Bsc Health Sciences');

INSERT INTO programs (title,level,category,duration,study_mode,tuition,intake,description,status)
SELECT 'BBA','Undergraduate','Business Administration','Contact PSA','Hybrid / Supported Learning','Contact PSA','Contact PSA','BBA is included in PSA''s current program catalogue. Contact PSA for current admission requirements, awarding institution, fees, intake and study route.','Active'
WHERE NOT EXISTS (SELECT 1 FROM programs WHERE title='BBA');



-- PSA central public settings
INSERT INTO system_settings (setting_key, setting_value) VALUES
('institution_name','Postgraduate School of Administration'),
('website','https://psa.institute'),
('email','info@psa.institute'),
('phone_1','0555077777'),
('phone_2','0322194448'),
('whatsapp','+233555077777'),
('address','Ghana | Behind K. Poly / KsTU, Kumasi'),
('gps_address','AK-040-9257'),
('map_query','Behind K. Poly / KsTU, Kumasi, Ghana'),
('profile','Postgraduate School of Administration (PSA) provides academic guidance, admissions support, professional programmes, student services and digital application support in Ghana.')
ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value);

CREATE TABLE IF NOT EXISTS enquiries (
    id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(180) NOT NULL,
    email VARCHAR(180) NOT NULL,
    phone VARCHAR(60),
    interest VARCHAR(120),
    message TEXT NOT NULL,
    status ENUM('New','In Progress','Resolved','Archived') DEFAULT 'New',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
