-- PSA PRODUCTION RBAC / ADMINISTRATION UPGRADE
-- Run once against psaiaogy_db after a backup.
SET NAMES utf8mb4;

ALTER TABLE admins
  ADD COLUMN status VARCHAR(20) NOT NULL DEFAULT 'Active' AFTER role,
  ADD COLUMN last_login_at DATETIME NULL AFTER status,
  ADD COLUMN last_login_ip VARCHAR(45) NULL AFTER last_login_at;

CREATE TABLE IF NOT EXISTS admin_permissions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    admin_id INT NOT NULL,
    permission VARCHAR(120) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_admin_permission (admin_id, permission),
    INDEX idx_permission (permission),
    CONSTRAINT fk_admin_permissions_admin FOREIGN KEY (admin_id) REFERENCES admins(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS admin_activity_logs (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    admin_id INT NULL,
    action VARCHAR(150) NOT NULL,
    module VARCHAR(100) NULL,
    description TEXT NULL,
    ip_address VARCHAR(45) NULL,
    user_agent TEXT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_admin_activity_admin (admin_id),
    INDEX idx_admin_activity_created (created_at),
    CONSTRAINT fk_admin_activity_admin FOREIGN KEY (admin_id) REFERENCES admins(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS login_attempts (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(180) NOT NULL,
    ip_address VARCHAR(45) NULL,
    successful TINYINT(1) NOT NULL DEFAULT 0,
    attempted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_login_email_time (email, attempted_at),
    INDEX idx_login_ip_time (ip_address, attempted_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Default role permissions. Existing Super Admin remains unrestricted in PHP.
INSERT IGNORE INTO admin_permissions (admin_id, permission)
SELECT a.id, p.permission
FROM admins a
CROSS JOIN (
 SELECT 'applications.view' permission UNION ALL SELECT 'applications.create' UNION ALL SELECT 'applications.edit' UNION ALL
 SELECT 'applications.review' UNION ALL SELECT 'applications.approve' UNION ALL SELECT 'applications.reject' UNION ALL
 SELECT 'students.view' UNION ALL SELECT 'students.create' UNION ALL SELECT 'students.edit' UNION ALL SELECT 'students.delete' UNION ALL
 SELECT 'documents.view' UNION ALL SELECT 'documents.upload' UNION ALL SELECT 'documents.verify' UNION ALL SELECT 'documents.reject' UNION ALL
 SELECT 'messages.view' UNION ALL SELECT 'messages.send' UNION ALL
 SELECT 'programs.view' UNION ALL SELECT 'programs.create' UNION ALL SELECT 'programs.edit' UNION ALL SELECT 'programs.delete' UNION ALL
 SELECT 'professional_programs.view' UNION ALL SELECT 'professional_programs.create' UNION ALL SELECT 'professional_programs.edit' UNION ALL SELECT 'professional_programs.delete' UNION ALL
 SELECT 'partners.view' UNION ALL SELECT 'partners.create' UNION ALL SELECT 'partners.edit' UNION ALL SELECT 'partners.delete' UNION ALL
 SELECT 'notices.view' UNION ALL SELECT 'notices.create' UNION ALL SELECT 'notices.edit' UNION ALL SELECT 'notices.delete' UNION ALL
 SELECT 'lms.view' UNION ALL SELECT 'lms.create' UNION ALL SELECT 'lms.edit' UNION ALL SELECT 'lms.delete' UNION ALL
 SELECT 'reports.view' UNION ALL SELECT 'reports.export' UNION ALL
 SELECT 'admins.view' UNION ALL SELECT 'admins.create' UNION ALL SELECT 'admins.edit' UNION ALL SELECT 'admins.suspend' UNION ALL
 SELECT 'settings.manage' UNION ALL SELECT 'audit.view'
) p
WHERE a.role='Super Admin';

-- Role defaults for existing non-super admins.
INSERT IGNORE INTO admin_permissions (admin_id, permission)
SELECT a.id, p.permission
FROM admins a
JOIN (
 SELECT 'Admissions Officer' role, 'applications.view' permission UNION ALL
 SELECT 'Admissions Officer','applications.create' UNION ALL SELECT 'Admissions Officer','applications.edit' UNION ALL
 SELECT 'Admissions Officer','applications.review' UNION ALL SELECT 'Admissions Officer','applications.approve' UNION ALL
 SELECT 'Admissions Officer','documents.view' UNION ALL SELECT 'Admissions Officer','documents.verify' UNION ALL
 SELECT 'Admissions Officer','students.view' UNION ALL SELECT 'Admissions Officer','students.edit' UNION ALL
 SELECT 'Admissions Officer','messages.view' UNION ALL SELECT 'Admissions Officer','messages.send' UNION ALL
 SELECT 'Admissions Officer','reports.view' UNION ALL
 SELECT 'Student Advisor','students.view' UNION ALL SELECT 'Student Advisor','students.edit' UNION ALL
 SELECT 'Student Advisor','applications.view' UNION ALL SELECT 'Student Advisor','applications.review' UNION ALL
 SELECT 'Student Advisor','documents.view' UNION ALL SELECT 'Student Advisor','messages.view' UNION ALL SELECT 'Student Advisor','messages.send' UNION ALL
 SELECT 'Student Advisor','reports.view' UNION ALL
 SELECT 'Content Manager','programs.view' UNION ALL SELECT 'Content Manager','programs.create' UNION ALL SELECT 'Content Manager','programs.edit' UNION ALL
 SELECT 'Content Manager','programs.delete' UNION ALL SELECT 'Content Manager','professional_programs.view' UNION ALL
 SELECT 'Content Manager','professional_programs.create' UNION ALL SELECT 'Content Manager','professional_programs.edit' UNION ALL
 SELECT 'Content Manager','professional_programs.delete' UNION ALL SELECT 'Content Manager','partners.view' UNION ALL
 SELECT 'Content Manager','partners.create' UNION ALL SELECT 'Content Manager','partners.edit' UNION ALL SELECT 'Content Manager','notices.view' UNION ALL
 SELECT 'Content Manager','notices.create' UNION ALL SELECT 'Content Manager','notices.edit' UNION ALL SELECT 'Content Manager','notices.delete' UNION ALL
 SELECT 'Content Manager','lms.view' UNION ALL SELECT 'Content Manager','lms.create' UNION ALL SELECT 'Content Manager','lms.edit'
) p ON p.role=a.role
WHERE a.role <> 'Super Admin';

-- Normalize existing administrator.
UPDATE admins SET status='Active' WHERE status IS NULL OR status='';
