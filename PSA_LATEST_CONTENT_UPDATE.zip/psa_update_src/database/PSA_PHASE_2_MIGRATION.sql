-- PSA PHASE 2: CONNECTED MANAGEMENT PLATFORM
-- Run after PSA_PRODUCTION_UPGRADE.sql.
-- Backup psaiaogy_db first.

SET NAMES utf8mb4;

CREATE TABLE IF NOT EXISTS admissions_inquiries (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    inquiry_code VARCHAR(40) UNIQUE NOT NULL,
    full_name VARCHAR(180) NOT NULL,
    email VARCHAR(180) NULL,
    phone VARCHAR(60) NULL,
    country VARCHAR(100) NULL,
    interest_type VARCHAR(60) NULL,
    programme_id INT NULL,
    professional_program_id INT NULL,
    source VARCHAR(80) NULL,
    message TEXT NULL,
    status VARCHAR(40) NOT NULL DEFAULT 'New',
    assigned_to INT NULL,
    next_follow_up_at DATETIME NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_inquiry_status (status),
    INDEX idx_inquiry_followup (next_follow_up_at),
    INDEX idx_inquiry_email (email),
    CONSTRAINT fk_inquiry_admin FOREIGN KEY (assigned_to) REFERENCES admins(id) ON DELETE SET NULL,
    CONSTRAINT fk_inquiry_program FOREIGN KEY (programme_id) REFERENCES programs(id) ON DELETE SET NULL,
    CONSTRAINT fk_inquiry_professional_program FOREIGN KEY (professional_program_id) REFERENCES professional_programs(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS admission_stage_history (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    application_id INT NOT NULL,
    old_status VARCHAR(60) NULL,
    new_status VARCHAR(60) NOT NULL,
    note TEXT NULL,
    changed_by INT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_stage_application (application_id, created_at),
    CONSTRAINT fk_stage_application FOREIGN KEY (application_id) REFERENCES applications(id) ON DELETE CASCADE,
    CONSTRAINT fk_stage_admin FOREIGN KEY (changed_by) REFERENCES admins(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS application_checklist (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    application_id INT NOT NULL,
    item_key VARCHAR(80) NOT NULL,
    item_label VARCHAR(180) NOT NULL,
    required_flag TINYINT(1) NOT NULL DEFAULT 1,
    status VARCHAR(30) NOT NULL DEFAULT 'Pending',
    verified_by INT NULL,
    verified_at DATETIME NULL,
    note TEXT NULL,
    UNIQUE KEY uq_application_checklist (application_id,item_key),
    INDEX idx_checklist_status (status),
    CONSTRAINT fk_checklist_application FOREIGN KEY (application_id) REFERENCES applications(id) ON DELETE CASCADE,
    CONSTRAINT fk_checklist_admin FOREIGN KEY (verified_by) REFERENCES admins(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS student_notifications (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    title VARCHAR(180) NOT NULL,
    message TEXT NOT NULL,
    notification_type VARCHAR(40) NOT NULL DEFAULT 'Info',
    read_at DATETIME NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_student_notifications (student_id, created_at),
    CONSTRAINT fk_notification_student FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS lms_enrollments (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    course_id INT NOT NULL,
    enrollment_status VARCHAR(30) NOT NULL DEFAULT 'Enrolled',
    progress_percent DECIMAL(5,2) NOT NULL DEFAULT 0,
    enrolled_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_accessed_at DATETIME NULL,
    UNIQUE KEY uq_lms_enrollment (student_id,course_id),
    CONSTRAINT fk_lms_enrollment_student FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
    CONSTRAINT fk_lms_enrollment_course FOREIGN KEY (course_id) REFERENCES lms_courses(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS payment_records (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NULL,
    application_id INT NULL,
    reference_code VARCHAR(80) UNIQUE NOT NULL,
    payment_type VARCHAR(60) NOT NULL,
    amount DECIMAL(12,2) NOT NULL DEFAULT 0,
    currency VARCHAR(10) NOT NULL DEFAULT 'GHS',
    provider VARCHAR(60) NULL,
    provider_reference VARCHAR(120) NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'Pending',
    paid_at DATETIME NULL,
    notes TEXT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_payment_status (status),
    INDEX idx_payment_student (student_id),
    CONSTRAINT fk_payment_student FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE SET NULL,
    CONSTRAINT fk_payment_application FOREIGN KEY (application_id) REFERENCES applications(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Extend applications for a normalized admissions pipeline.
ALTER TABLE applications
    ADD COLUMN submitted_at DATETIME NULL,
    ADD COLUMN reviewed_at DATETIME NULL,
    ADD COLUMN interview_at DATETIME NULL,
    ADD COLUMN offer_at DATETIME NULL,
    ADD COLUMN enrolled_at DATETIME NULL,
    ADD COLUMN priority VARCHAR(20) NOT NULL DEFAULT 'Normal',
    ADD COLUMN source VARCHAR(80) NULL;

CREATE INDEX idx_app_priority ON applications(priority);
CREATE INDEX idx_app_status_created ON applications(application_status,created_at);

-- Seed checklists for existing applications without overwriting existing records.
INSERT IGNORE INTO application_checklist
(application_id,item_key,item_label,required_flag,status)
SELECT a.id,'identity','Valid identity / passport document',1,'Pending'
FROM applications a;

INSERT IGNORE INTO application_checklist
(application_id,item_key,item_label,required_flag,status)
SELECT a.id,'academic','Academic certificate / transcript',1,'Pending'
FROM applications a;

INSERT IGNORE INTO application_checklist
(application_id,item_key,item_label,required_flag,status)
SELECT a.id,'photo','Passport photograph',1,'Pending'
FROM applications a;

INSERT IGNORE INTO application_checklist
(application_id,item_key,item_label,required_flag,status)
SELECT a.id,'statement','Personal statement / motivation',1,'Pending'
FROM applications a;

-- Add Phase 2 permissions.
INSERT IGNORE INTO admin_permissions(admin_id,permission)
SELECT a.id,p.permission
FROM admins a
CROSS JOIN (
 SELECT 'inquiries.view' permission UNION ALL SELECT 'inquiries.create' UNION ALL SELECT 'inquiries.edit' UNION ALL
 SELECT 'admissions.pipeline' UNION ALL SELECT 'admissions.stage_update' UNION ALL
 SELECT 'checklist.view' UNION ALL SELECT 'checklist.verify' UNION ALL
 SELECT 'notifications.send' UNION ALL SELECT 'payments.view' UNION ALL SELECT 'payments.manage' UNION ALL
 SELECT 'lms.progress' UNION ALL SELECT 'reports.dashboard'
) p
WHERE a.role='Super Admin';

-- Useful initial notifications for students whose applications already exist.
INSERT INTO student_notifications(student_id,title,message,notification_type)
SELECT DISTINCT a.student_id,
       'PSA Student Portal',
       'Your PSA student portal is active. Use it to monitor applications, documents, messages and learning support.',
       'Info'
FROM applications a
WHERE NOT EXISTS (
    SELECT 1 FROM student_notifications n
    WHERE n.student_id=a.student_id AND n.title='PSA Student Portal'
);

-- Phase 2 role defaults for operational staff.
INSERT IGNORE INTO admin_permissions(admin_id,permission)
SELECT a.id,p.permission FROM admins a JOIN (
SELECT 'Admissions Officer' role,'inquiries.view' permission UNION ALL SELECT 'Admissions Officer','inquiries.create' UNION ALL SELECT 'Admissions Officer','inquiries.edit' UNION ALL SELECT 'Admissions Officer','admissions.pipeline' UNION ALL SELECT 'Admissions Officer','admissions.stage_update' UNION ALL SELECT 'Admissions Officer','checklist.view' UNION ALL SELECT 'Admissions Officer','checklist.verify' UNION ALL SELECT 'Admissions Officer','notifications.send' UNION ALL SELECT 'Admissions Officer','reports.dashboard' UNION ALL
SELECT 'Student Advisor','inquiries.view' UNION ALL SELECT 'Student Advisor','inquiries.edit' UNION ALL SELECT 'Student Advisor','admissions.pipeline' UNION ALL SELECT 'Student Advisor','admissions.stage_update' UNION ALL SELECT 'Student Advisor','checklist.view' UNION ALL SELECT 'Student Advisor','checklist.verify' UNION ALL SELECT 'Student Advisor','notifications.send' UNION ALL SELECT 'Student Advisor','reports.dashboard'
) p ON p.role=a.role WHERE a.role <> 'Super Admin';
