-- PSA LIVE DOMAIN / CONTACT SETTINGS UPDATE
-- Run this once in phpMyAdmin while psaiaogy_db is selected.

UPDATE system_settings
SET setting_value = 'https://psa.institute'
WHERE setting_key = 'website';

UPDATE system_settings
SET setting_value = 'info@psa.institute'
WHERE setting_key = 'email';

SELECT setting_key, setting_value
FROM system_settings
WHERE setting_key IN ('website','email');
