<?php
require_once __DIR__ . '/config.php';

$success = null;
$error = null;
$reference_code = null;
$student_id_code = null;
$application_code = null;
$programs = $pdo->query("SELECT * FROM programs WHERE status='Active' ORDER BY title ASC")->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        if (!verify_csrf()) {
            throw new RuntimeException('Your session security token expired. Please refresh the page and try again.');
        }

        $full_name = clean_input($_POST['full_name'] ?? '');
        $email = strtolower(clean_input($_POST['email'] ?? ''));
        $phone = clean_input($_POST['phone'] ?? '');
        $password = $_POST['password'] ?? '';

        if ($full_name === '' || !filter_var($email, FILTER_VALIDATE_EMAIL) || $phone === '') {
            throw new RuntimeException('Please provide a valid full name, email address and phone number.');
        }
        if (strlen($password) < 8) {
            throw new RuntimeException('Your portal password must be at least 8 characters.');
        }

        $existing = $pdo->prepare('SELECT id FROM students WHERE email=? LIMIT 1');
        $existing->execute([$email]);
        if ($existing->fetch()) {
            throw new RuntimeException('An applicant already exists with this email. Use Student Login or contact PSA admissions.');
        }

        $reference_code = generate_reference_code();
        $student_id_code = generate_student_id();
        $application_code = generate_application_code();

        $pdo->beginTransaction();

        $stmt = $pdo->prepare(
            "INSERT INTO students
            (student_id,reference_code,full_name,email,phone,gender,nationality,highest_qualification,password_hash)
            VALUES (?,?,?,?,?,?,?,?,?)"
        );
        $stmt->execute([
            $student_id_code,
            $reference_code,
            $full_name,
            $email,
            $phone,
            clean_input($_POST['gender'] ?? ''),
            clean_input($_POST['nationality'] ?? 'Ghanaian'),
            clean_input($_POST['highest_qualification'] ?? ''),
            password_hash($password, PASSWORD_DEFAULT)
        ]);
        $sid = (int)$pdo->lastInsertId();

        $programId = !empty($_POST['program_id']) ? (int)$_POST['program_id'] : null;
        $stmt = $pdo->prepare("INSERT INTO applications
            (application_code,student_id,program_id,preferred_program,study_level,study_mode,intake,previous_school,qualification,personal_statement)
            VALUES (?,?,?,?,?,?,?,?,?,?)");
        $stmt->execute([$application_code,$sid,$programId,
            clean_input($_POST['preferred_program'] ?? ''),clean_input($_POST['study_level'] ?? 'Postgraduate'),
            clean_input($_POST['study_mode'] ?? 'Hybrid'),clean_input($_POST['intake'] ?? ''),
            clean_input($_POST['previous_school'] ?? ''),clean_input($_POST['qualification'] ?? ''),
            clean_input($_POST['personal_statement'] ?? '')]);
        $aid = (int)$pdo->lastInsertId();

        $pdo->prepare("INSERT INTO tracking_logs (application_id,status,note) VALUES (?,?,?)")
            ->execute([$aid, 'Submitted', 'Application submitted successfully. PSA admissions team will review your information.']);

        $pdo->prepare("INSERT INTO messages (student_id,sender_type,subject,message) VALUES (?,'Admin',?,?)")
            ->execute([$sid, 'Application Received', 'Your application has been received. Keep your Student ID and Reference Code safe.']);

        $pdo->commit();
        $success = 'Application submitted successfully.';
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        error_log('PSA application error: ' . $e->getMessage());
        $error = $e instanceof RuntimeException ? $e->getMessage() : 'We could not complete your application. Please try again.';
    }
}
?>
<?php include 'includes/header.php'; ?>
<section class="module-hero">
  <div>
    <div class="eyebrow">PSA Online Application</div>
    <h1>Apply Online & Receive Your Student Credentials</h1>
    <p>Submit your application once. PSA will generate a Student ID, Reference Code and Application Code for tracking, communication and portal services.</p>
  </div>
</section>

<section class="section light">
  <div class="section-title"><div class="eyebrow">Admissions</div><h2>Start Your PSA Application</h2><p>Complete the required information carefully. You can continue using your credentials after submission.</p></div>

  <div class="form-card">
    <?php if ($success): ?>
      <div class="alert success"><i class="fa fa-check-circle"></i> <?= e($success) ?></div>
      <div class="reference-box">
        <p>Your Student ID</p><strong><?= e($student_id_code) ?></strong>
        <p>Your Reference Code</p><strong><?= e($reference_code) ?></strong>
        <p>Your Application Code</p><strong><?= e($application_code) ?></strong>
        <div class="hero-actions">
          <a class="btn btn-gold" href="track-application.php"><i class="fa fa-search"></i> Track Application</a>
          <a class="btn btn-outline" href="student-login.php"><i class="fa fa-sign-in"></i> Student Login</a>
        </div>
      </div>
    <?php endif; ?>

    <?php if ($error): ?><div class="alert error"><i class="fa fa-exclamation-circle"></i> <?= e($error) ?></div><?php endif; ?>

    <?php if (!$success): ?>
    <form method="post" novalidate>
      <?= csrf_field() ?>
      <div class="form-grid">
        <div class="form-section-title"><i class="fa fa-user"></i> Personal Information</div>
        <div class="form-group"><label>Full Name *</label><input name="full_name" required autocomplete="name"></div>
        <div class="form-group"><label>Email Address *</label><input type="email" name="email" required autocomplete="email"></div>
        <div class="form-group"><label>Phone Number *</label><input name="phone" required autocomplete="tel" placeholder="+233..."></div>
        <div class="form-group"><label>Gender</label><select name="gender"><option value="">Select</option><option>Male</option><option>Female</option><option>Other</option></select></div>
        <div class="form-group"><label>Nationality</label><input name="nationality" value="Ghanaian"></div>
        <div class="form-group"><label>Highest Qualification</label><input name="highest_qualification" placeholder="e.g. HND, BSc, MBA, WASSCE"></div>

        <div class="form-section-title"><i class="fa fa-graduation-cap"></i> Programme Selection</div>
<div class="form-group full"><label>Academic Programme</label><select name="program_id"><option value="">Select an academic programme</option><?php foreach($programs as $p):?><option value="<?=intval($p['id'])?>"><?=e($p['title'])?></option><?php endforeach;?></select></div>

<div class="form-group"><label>Preferred Programme if Not Listed</label><input name="preferred_program"></div>
        <div class="form-group"><label>Study Level</label><select name="study_level"><option>Postgraduate</option><option>Undergraduate</option></select></div>
        <div class="form-group"><label>Study Mode</label><select name="study_mode"><option>Hybrid</option><option>Online</option><option>On Campus</option></select></div>
        <div class="form-group"><label>Preferred Intake</label><input name="intake" placeholder="e.g. January 2027"></div>
        <div class="form-group"><label>Previous School</label><input name="previous_school"></div>
        <div class="form-group"><label>Qualification Obtained</label><input name="qualification"></div>

        <div class="form-section-title"><i class="fa fa-lock"></i> Student Portal Access</div>
        <div class="form-group full"><label>Create Portal Password *</label>
          <div class="password-wrap"><input id="applyPassword" type="password" name="password" minlength="8" required autocomplete="new-password"><button class="password-toggle" type="button" data-password-toggle="applyPassword" aria-label="Show password"><i class="fa fa-eye"></i></button></div>
          <span class="form-help">Use at least 8 characters. Keep this password secure.</span>
        </div>
        <div class="form-group full"><label>Personal Statement / Notes</label><textarea name="personal_statement" rows="5" maxlength="3000" placeholder="Tell PSA anything relevant to your application..."></textarea></div>
      </div>
      <div class="hero-actions" style="margin-top:22px">
        <button class="btn btn-gold" type="submit"><i class="fa fa-paper-plane"></i> Submit Application</button>
        <a class="btn btn-outline" href="student-login.php"><i class="fa fa-sign-in"></i> Already Applied? Login</a>
      </div>
    </form>
    <?php endif; ?>
  </div>
</section>
<?php include 'includes/footer.php'; ?>