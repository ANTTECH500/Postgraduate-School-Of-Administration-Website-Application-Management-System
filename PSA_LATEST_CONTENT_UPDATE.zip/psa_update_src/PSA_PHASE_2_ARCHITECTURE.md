# PSA Phase 2 Architecture

## End-to-end operating model

Website visitor
→ Contact / inquiry
→ CRM inquiry queue
→ Advisor assignment
→ Qualification
→ Application
→ Document checklist
→ Academic/professional programme selection
→ Review
→ Interview
→ Offer
→ Payment record
→ Enrollment
→ Student portal
→ LMS / notifications / communication
→ Management reporting

## Core entities

- admissions_inquiries
- students
- applications
- professional_programs
- programs
- documents
- application_checklist
- admission_stage_history
- messages
- student_notifications
- payment_records
- lms_courses
- lms_enrollments
- admins
- admin_permissions
- admin_activity_logs

## Design principles

1. Normalize important relationships rather than relying on free-text programme names.
2. Preserve historical records.
3. Enforce authorization server-side.
4. Record admissions stage transitions.
5. Keep student communications inside the portal.
6. Keep financial records separate from application status.
7. Make reporting queryable from operational tables.
8. Avoid destructive deletes for institutional records.
9. Keep external payment gateway credentials outside the database migration.
10. Maintain cPanel-compatible PHP/MySQL deployment.
