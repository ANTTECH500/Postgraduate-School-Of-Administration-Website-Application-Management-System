<?php
declare(strict_types=1);

/**
 * PSA - Postgraduate School of Administration
 * Central production configuration for cPanel / Namecheap.
 *
 * IMPORTANT:
 * Keep this file outside public web access where possible, or protect it
 * with the server's PHP configuration. Never display its contents.
 */

// ============================================================
// DATABASE
// ============================================================

define('DB_HOST', 'localhost');
define('DB_NAME', 'psaiaogy_db');
define('DB_USER', 'psaiaogy_info');
define('DB_PASS', 'Pxglm9zrnNrmkWLv');
define('DB_CHARSET', 'utf8mb4');

// ============================================================
// INSTITUTION
// ============================================================

define('SITE_NAME', 'Postgraduate School of Administration');
define('SITE_SHORT_NAME', 'PSA');
define('SITE_URL', 'https://psa.institute');
define('SITE_EMAIL', 'info@psa.institute');
define('SITE_PHONE', '+233322194448');
define('SITE_PHONE_DISPLAY', '+233322194448');
define('SITE_PHONE_ALT', '');
define('SITE_WHATSAPP', '+233242684348');
define('SITE_ADDRESS', 'Ghana | Behind K. Poly / KsTU, Kumasi');
define('SITE_GPS', 'AK-040-9257');
define('SITE_MAP_QUERY', 'Behind K. Poly / KsTU, Kumasi, Ghana');
define('SITE_DESCRIPTION', 'Postgraduate School of Administration (PSA) provides academic guidance, admissions support, academic programmes, student services and digital application support in Ghana.');

// ============================================================
// DATABASE CONNECTION
// ============================================================

try {
    if (!extension_loaded('pdo')) {
        throw new RuntimeException('PHP PDO extension is not enabled.');
    }

    if (!extension_loaded('pdo_mysql')) {
        throw new RuntimeException('PHP PDO MySQL extension is not enabled.');
    }

    $dsn = sprintf(
        'mysql:host=%s;dbname=%s;charset=%s',
        DB_HOST,
        DB_NAME,
        DB_CHARSET
    );

    $pdo = new PDO($dsn, DB_USER, DB_PASS, [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
        PDO::ATTR_TIMEOUT            => 8,
    ]);

    // Verify the connection actually works.
    $pdo->query('SELECT 1');

} catch (Throwable $e) {
    // Never expose database credentials or raw connection errors publicly.
    error_log('[PSA] Database connection failed: ' . $e->getMessage());

    http_response_code(500);
    exit('The application is temporarily unavailable. Please try again later.');
}

// ============================================================
// SESSION
// ============================================================

if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_start();
}

// ============================================================
// HELPERS
// ============================================================

function clean_input(?string $value): string
{
    return trim((string)($value ?? ''));
}

function e($value): string
{
    return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8');
}

function generate_reference_code(): string
{
    return 'PSA-' . date('Y') . '-' . strtoupper(bin2hex(random_bytes(4)));
}

function generate_student_id(): string
{
    return 'STU-' . date('Y') . '-' . strtoupper(bin2hex(random_bytes(3)));
}

function generate_application_code(): string
{
    return 'APP-' . date('Y') . '-' . strtoupper(bin2hex(random_bytes(3)));
}

function csrf_token(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }

    return $_SESSION['csrf_token'];
}

function csrf_field(): string
{
    return '<input type="hidden" name="csrf_token" value="' . e(csrf_token()) . '">';
}

function verify_csrf(): bool
{
    $token = $_POST['csrf_token'] ?? '';

    return is_string($token)
        && $token !== ''
        && hash_equals($_SESSION['csrf_token'] ?? '', $token);
}

function redirect_to(string $url): never
{
    header('Location: ' . $url);
    exit;
}
