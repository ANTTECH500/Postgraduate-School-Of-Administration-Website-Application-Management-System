# PSA Latest Website Content & Module Update

## Applied management changes

- Public Professional Programmes module unloaded from navigation, sitemap, public category and new application selection.
- Existing `professional_programs` database records are preserved for historical/audit purposes; no database records are deleted by this package.
- Added a dedicated `services.php` page containing:
  - Program Guidance
  - Admission Support
  - Partner University Access
  - Scholarship Guidance
  - Student Portal
  - Consultation & Advisory
- Added the requested About PSA statement about obtaining foreign-university credentials while living in the home country and reducing overseas living, employment, airfare and related variable costs.
- Partner university pages now retain only Charisma University.
- Removed Shri Atmanand Jain Institute of Management and Technology from public partner/accreditation content.
- Removed Abia State University from public partner/accreditation content.
- Removed the 0555077777 telephone number from public content.
- WhatsApp is now +233 242 684 348.
- Main telephone is +233 32 219 4448.
- Public email is `info@psa.institute`.
- Removed the old `info@psa.institute.com` typo.
- Updated contact, admissions, scholarship, student-login and location-related calls-to-action.
- Added Services to the main navigation and footer.
- Updated the dynamic sitemap to include Services and exclude the unloaded Professional Programmes page.
- Updated Google-oriented structured navigation data through the existing header implementation.
- Kept the application and admissions database compatible with historical professional-programme records while preventing new public selection.

## Deployment

Upload the contents of this repository to the PSA web root. Do not upload SQL migration files into a publicly accessible location unless they are protected; the included `.htaccess` denies direct access to SQL/config files.

Back up the production site and database before replacing files.
