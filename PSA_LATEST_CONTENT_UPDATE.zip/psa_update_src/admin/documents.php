<?php require_admin_permission('documents.view');

include 'admin-header.php';
if(isset($_GET['verify'])){
    if(!admin_can('documents.verify')) { http_response_code(403); exit('Access denied.'); }
    $id=intval($_GET['verify']); $status=$_GET['status']==='Rejected'?'Rejected':'Verified';
    $stmt=$pdo->prepare("UPDATE documents SET verification_status=? WHERE id=?"); $stmt->execute([$status,$id]);
}
$docs=$pdo->query("SELECT d.*, a.application_code, s.full_name, s.student_id FROM documents d JOIN applications a ON d.application_id=a.id JOIN students s ON a.student_id=s.id ORDER BY d.uploaded_at DESC")->fetchAll();
?>
<div class="admin-content">
<div class="admin-card"><h2>Document Review</h2><p>Review, verify or reject uploaded student documents.</p></div>
<div class="admin-table-wrap"><table class="admin-table"><thead><tr><th>Student</th><th>Application</th><th>Document</th><th>Status</th><th>Uploaded</th><th>Action</th></tr></thead><tbody>
<?php foreach($docs as $d): ?><tr><td><?= safe($d['full_name']) ?><br><small><?= safe($d['student_id']) ?></small></td><td><?= safe($d['application_code']) ?></td><td><a href="../<?= safe($d['file_path']) ?>" target="_blank"><?= safe($d['document_type']) ?></a></td><td><span class="badge-status <?= safe($d['verification_status']) ?>"><?= safe($d['verification_status']) ?></span></td><td><?= safe($d['uploaded_at']) ?></td><td class="admin-actions"><a class="admin-btn gold" href="?verify=<?= $d['id'] ?>&status=Verified">Verify</a><a class="admin-btn red" href="?verify=<?= $d['id'] ?>&status=Rejected">Reject</a></td></tr><?php endforeach; ?>
</tbody></table></div>
</div>
<?php include 'admin-footer.php'; ?>