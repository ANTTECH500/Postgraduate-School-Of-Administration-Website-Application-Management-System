<?php
declare(strict_types=1);
require_once __DIR__ . '/auth.php';
require_admin_permission('inquiries.view');

$notice=$error=null;
if($_SERVER['REQUEST_METHOD']==='POST'){
 try{
  if(!admin_can('inquiries.edit')) throw new RuntimeException('Inquiry edit permission required.');
  if(!verify_csrf()) throw new RuntimeException('Security token expired.');
  $id=(int)($_POST['id']??0);$status=clean_input($_POST['status']??'New');
  $assigned=(int)($_POST['assigned_to']??0) ?: null;$follow=clean_input($_POST['next_follow_up_at']??'') ?: null;
  if(!in_array($status,['New','Contacted','Qualified','Application Started','Converted','Closed'],true)) throw new RuntimeException('Invalid inquiry status.');
  $s=$pdo->prepare("UPDATE admissions_inquiries SET status=?,assigned_to=?,next_follow_up_at=? WHERE id=?");$s->execute([$status,$assigned,$follow,$id]);
  log_admin_activity('Inquiry updated','inquiries',"Inquiry #$id → $status");$notice='Inquiry updated.';
 }catch(Throwable $e){$error=$e instanceof RuntimeException?$e->getMessage():'Unable to update inquiry.';}
}
$q=clean_input($_GET['q']??'');$status=clean_input($_GET['status']??'');
$where=['1=1'];$params=[];
if($q!==''){$where[]='(full_name LIKE ? OR email LIKE ? OR phone LIKE ? OR inquiry_code LIKE ?)';$like="%$q%";$params=[$like,$like,$like,$like];}
if($status!==''){$where[]='status=?';$params[]=$status;}
$s=$pdo->prepare("SELECT i.*,a.full_name assigned_name FROM admissions_inquiries i LEFT JOIN admins a ON a.id=i.assigned_to WHERE ".implode(' AND ',$where)." ORDER BY COALESCE(i.next_follow_up_at,i.created_at) ASC LIMIT 500");$s->execute($params);$rows=$s->fetchAll();
$staff=$pdo->query("SELECT id,full_name FROM admins WHERE status='Active' ORDER BY full_name")->fetchAll();
include 'admin-header.php';
?>
<div class="admin-content">
<div class="admin-page-actions"><div><h1>Admissions Inquiries</h1><p>Central CRM queue for prospects before they become applicants.</p></div></div>
<?php if($notice):?><div class="alert-admin success"><?=safe($notice)?></div><?php endif;?><?php if($error):?><div class="alert-admin error"><?=safe($error)?></div><?php endif;?>
<div class="admin-card"><form method="get" class="admin-search"><input name="q" value="<?=safe($q)?>" placeholder="Name, email, phone or inquiry code"><select name="status"><option value="">All statuses</option><?php foreach(['New','Contacted','Qualified','Application Started','Converted','Closed'] as $x):?><option <?=$status===$x?'selected':''?>><?=$x?></option><?php endforeach;?></select><button class="admin-btn gold"><i class="fa fa-search"></i> Search</button></form></div>
<div class="admin-card"><div class="admin-table-wrap"><table class="admin-table"><thead><tr><th>Inquiry</th><th>Contact</th><th>Interest</th><th>Status</th><th>Assigned</th><th>Follow-up</th><th>Action</th></tr></thead><tbody>
<?php foreach($rows as $r):?><tr>
<td><strong><?=safe($r['inquiry_code'])?></strong><br><small><?=safe($r['created_at'])?></small></td>
<td><?=safe($r['full_name'])?><br><small><?=safe($r['email'])?> <?=safe($r['phone'])?></small></td>
<td><?=safe($r['interest_type'])?></td><td><span class="badge-status"><?=safe($r['status'])?></span></td><td><?=safe($r['assigned_name']??'Unassigned')?></td><td><?=safe($r['next_follow_up_at']??'—')?></td>
<td><?php if(admin_can('inquiries.edit')):?><details><summary class="admin-btn blue">Manage</summary><form method="post" class="admin-form compact"><?=csrf_field()?><input type="hidden" name="id" value="<?=$r['id']?>"><label>Status</label><select name="status"><?php foreach(['New','Contacted','Qualified','Application Started','Converted','Closed'] as $x):?><option <?=$r['status']===$x?'selected':''?>><?=$x?></option><?php endforeach;?></select><label>Assigned</label><select name="assigned_to"><option value="">Unassigned</option><?php foreach($staff as $a):?><option value="<?=$a['id']?>" <?=$r['assigned_to']==$a['id']?'selected':''?>><?=safe($a['full_name'])?></option><?php endforeach;?></select><label>Next follow-up</label><input type="datetime-local" name="next_follow_up_at" value="<?= $r['next_follow_up_at'] ? date('Y-m-d\TH:i',strtotime($r['next_follow_up_at'])) : '' ?>"><button class="admin-btn gold">Save</button></form></details><?php endif;?></td>
</tr><?php endforeach;?>
<?php if(!$rows):?><tr><td colspan="7">No inquiries found.</td></tr><?php endif;?>
</tbody></table></div></div></div>
<?php include 'admin-footer.php';?>