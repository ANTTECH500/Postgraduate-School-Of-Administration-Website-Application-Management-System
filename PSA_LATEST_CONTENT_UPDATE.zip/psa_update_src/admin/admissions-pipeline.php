<?php
declare(strict_types=1);
require_once __DIR__ . '/auth.php';
require_admin_permission('admissions.pipeline');

$stages=['Submitted','Under Review','Pending Documents','Interview Scheduled','Offer Issued','Enrolled','Rejected'];
if($_SERVER['REQUEST_METHOD']==='POST'){
 if(!admin_can('admissions.stage_update')){http_response_code(403);exit('Access denied.');}
 if(!verify_csrf()){http_response_code(419);exit('Security token expired.');}
 $id=(int)$_POST['id'];$new=clean_input($_POST['new_status']??'');$note=clean_input($_POST['note']??'');
 if(in_array($new,$stages,true)){
  $s=$pdo->prepare("SELECT application_status,student_id,application_code FROM applications WHERE id=?");$s->execute([$id]);$app=$s->fetch();
  if($app){
   $old=$app['application_status'];
   $pdo->prepare("UPDATE applications SET application_status=?,submitted_at=COALESCE(submitted_at,IF(?='Submitted',NOW(),submitted_at)),reviewed_at=IF(?='Under Review',NOW(),reviewed_at),interview_at=IF(?='Interview Scheduled',NOW(),interview_at),offer_at=IF(?='Offer Issued',NOW(),offer_at),enrolled_at=IF(?='Enrolled',NOW(),enrolled_at) WHERE id=?")->execute([$new,$new,$new,$new,$new,$new,$id]);
   $pdo->prepare("INSERT INTO admission_stage_history(application_id,old_status,new_status,note,changed_by) VALUES(?,?,?,?,?)")->execute([$id,$old,$new,$note,(int)$_SESSION['admin_id']]);
   if($app['student_id']){
    $pdo->prepare("INSERT INTO student_notifications(student_id,title,message,notification_type) VALUES(?,?,?,'Application')")->execute([$app['student_id'],'Application Status Updated',"Application {$app['application_code']} is now: {$new}. ".($note?:'')]);
   }
   log_admin_activity('Application stage updated','admissions',$app['application_code']." → ".$new);
  }
 }
}
$apps=$pdo->query("SELECT a.id,a.application_code,a.application_status,a.priority,a.created_at,s.full_name,s.student_id,p.title program_title FROM applications a JOIN students s ON s.id=a.student_id LEFT JOIN programs p ON p.id=a.program_id ORDER BY FIELD(a.application_status,'Submitted','Under Review','Pending Documents','Interview Scheduled','Offer Issued','Enrolled','Rejected'),a.created_at ASC LIMIT 300")->fetchAll();
$group=[];foreach($stages as $s)$group[$s]=[];foreach($apps as $a){$group[$a['application_status']][]=$a;}
include 'admin-header.php';
?>
<div class="admin-content">
<div class="admin-page-actions"><div><h1>Admissions Pipeline</h1><p>Move applicants through the complete admissions lifecycle while preserving stage history.</p></div></div>
<div class="pipeline-board">
<?php foreach($stages as $stage):?><section class="pipeline-column"><header><h3><?=safe($stage)?></h3><span><?=count($group[$stage])?></span></header>
<?php foreach($group[$stage] as $a):?><article class="pipeline-card"><strong><?=safe($a['application_code'])?></strong><h4><?=safe($a['full_name'])?></h4><p><?=safe($a['program_title']?:'Programme not selected')?></p><small><?=safe($a['student_id'])?> · <?=safe($a['priority'])?></small>
<?php if(admin_can('admissions.stage_update')):?><details><summary>Update stage</summary><form method="post"><?=csrf_field()?><input type="hidden" name="id" value="<?=$a['id']?>"><select name="new_status"><?php foreach($stages as $x):?><option <?=$a['application_status']===$x?'selected':''?>><?=$x?></option><?php endforeach;?></select><textarea name="note" placeholder="Stage note"></textarea><button class="admin-btn gold">Update</button></form></details><?php endif;?></article><?php endforeach;?>
<?php if(!$group[$stage]):?><div class="pipeline-empty">No applicants</div><?php endif;?></section><?php endforeach;?>
</div></div>
<?php include 'admin-footer.php';?>