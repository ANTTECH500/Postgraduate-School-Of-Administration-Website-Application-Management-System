<?php require_admin_permission('lms.view');

include 'admin-header.php';
$success=null;
if($_SERVER['REQUEST_METHOD']==='POST'){
    if(!admin_can('lms.create')) { http_response_code(403); exit('Access denied.'); }
    if(!verify_csrf()) { http_response_code(419); exit('Security token expired.'); }
    $stmt=$pdo->prepare("INSERT INTO lms_courses (title,category,description,course_url,status) VALUES (?,?,?,?,?)");
    $stmt->execute([clean_input($_POST['title']),clean_input($_POST['category']),clean_input($_POST['description']),clean_input($_POST['course_url']),clean_input($_POST['status'])]);
    $success="LMS course added.";
}
$courses=$pdo->query("SELECT * FROM lms_courses ORDER BY created_at DESC")->fetchAll();
?>
<div class="admin-content">
<?php if($success): ?><div class="alert-admin success"><?= safe($success) ?></div><?php endif; ?>
<div class="admin-card"><h2>LMS Course Management</h2><form method="post" class="admin-form"><?= csrf_field() ?><div><label>Course Title</label><input name="title" required></div><div><label>Category</label><input name="category"></div><div><label>Course URL</label><input name="course_url" placeholder="Video/file/course link"></div><div><label>Status</label><select name="status"><option>Active</option><option>Inactive</option></select></div><div class="full"><label>Description</label><textarea name="description" rows="4"></textarea></div><div class="full"><button class="admin-btn gold">Add Course</button></div></form></div>
<div class="admin-table-wrap"><table class="admin-table"><thead><tr><th>Title</th><th>Category</th><th>Description</th><th>URL</th><th>Status</th></tr></thead><tbody><?php foreach($courses as $c): ?><tr><td><?= safe($c['title']) ?></td><td><?= safe($c['category']) ?></td><td><?= safe($c['description']) ?></td><td><?= safe($c['course_url']) ?></td><td><?= safe($c['status']) ?></td></tr><?php endforeach; ?></tbody></table></div>
</div>
<?php include 'admin-footer.php'; ?>