<?php require_admin_permission('messages.view');

include 'admin-header.php';
$success=null; $students=$pdo->query("SELECT id, full_name, student_id FROM students ORDER BY full_name")->fetchAll();
if($_SERVER['REQUEST_METHOD']==='POST'){
    if(!admin_can('messages.send')) { http_response_code(403); exit('Access denied.'); }
    if(!verify_csrf()) { http_response_code(419); exit('Security token expired.'); }
    $sid=intval($_POST['student_id']); $subject=clean_input($_POST['subject']); $message=clean_input($_POST['message']);
    $stmt=$pdo->prepare("INSERT INTO messages (student_id,sender_type,subject,message) VALUES (?,'Admin',?,?)");
    $stmt->execute([$sid,$subject,$message]); $success="Message sent successfully.";
}
$messages=$pdo->query("SELECT m.*, s.full_name, s.student_id FROM messages m JOIN students s ON m.student_id=s.id ORDER BY m.created_at DESC LIMIT 100")->fetchAll();
?>
<div class="admin-content">
<?php if($success): ?><div class="alert-admin success"><?= safe($success) ?></div><?php endif; ?>
<div class="admin-card"><h2>Communication Management</h2><form method="post" class="admin-form"><?= csrf_field() ?><div><label>Student</label><select name="student_id"><?php foreach($students as $s): ?><option value="<?= $s['id'] ?>"><?= safe($s['full_name']) ?> - <?= safe($s['student_id']) ?></option><?php endforeach; ?></select></div><div><label>Subject</label><input name="subject" required></div><div class="full"><label>Message</label><textarea name="message" rows="5" required></textarea></div><div class="full"><button class="admin-btn gold"><i class="fa fa-send"></i> Send Message</button></div></form></div>
<div class="admin-table-wrap"><table class="admin-table"><thead><tr><th>Student</th><th>Sender</th><th>Subject</th><th>Message</th><th>Date</th></tr></thead><tbody><?php foreach($messages as $m): ?><tr><td><?= safe($m['full_name']) ?><br><small><?= safe($m['student_id']) ?></small></td><td><?= safe($m['sender_type']) ?></td><td><?= safe($m['subject']) ?></td><td><?= safe($m['message']) ?></td><td><?= safe($m['created_at']) ?></td></tr><?php endforeach; ?></tbody></table></div>
</div>
<?php include 'admin-footer.php'; ?>