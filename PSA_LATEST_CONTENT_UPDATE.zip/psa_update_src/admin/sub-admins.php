<?php
declare(strict_types=1);
require_once __DIR__ . '/auth.php';
require_admin_permission('admins.view');

$roles = ['Admissions Officer','Student Advisor','Content Manager'];
$allPermissions = [
 'applications.view','applications.create','applications.edit','applications.review','applications.approve','applications.reject',
 'students.view','students.create','students.edit','students.delete',
 'documents.view','documents.upload','documents.verify','documents.reject',
 'messages.view','messages.send',
 'programs.view','programs.create','programs.edit','programs.delete',
 'partners.view','partners.create','partners.edit','partners.delete',
 'notices.view','notices.create','notices.edit','notices.delete',
 'lms.view','lms.create','lms.edit','lms.delete','reports.view','reports.export'
];
$defaults = [
 'Admissions Officer'=>['applications.view','applications.create','applications.edit','applications.review','applications.approve','documents.view','documents.verify','students.view','students.edit','messages.view','messages.send','reports.view'],
 'Student Advisor'=>['students.view','students.edit','applications.view','applications.review','documents.view','messages.view','messages.send','reports.view'],
 'Content Manager'=>['programs.view','programs.create','programs.edit','programs.delete','partners.view','partners.create','partners.edit','notices.view','notices.create','notices.edit','notices.delete','lms.view','lms.create','lms.edit','reports.view']
];

$notice=$error=null;
if ($_SERVER['REQUEST_METHOD']==='POST') {
 try {
  if(!verify_csrf()) throw new RuntimeException('Security token expired. Refresh the page.');
  $action=clean_input($_POST['action']??'');
  if($action==='save'){
   $id=(int)($_POST['id']??0);
   if($id && !admin_can('admins.edit')) throw new RuntimeException('You cannot edit administrators.');
   if(!$id && !admin_can('admins.create')) throw new RuntimeException('You cannot create administrators.');
   $name=clean_input($_POST['full_name']??''); $email=strtolower(clean_input($_POST['email']??''));
   $role=clean_input($_POST['role']??''); $status=clean_input($_POST['status']??'Active');
   $password=(string)($_POST['password']??'');
   if($name===''||!filter_var($email,FILTER_VALIDATE_EMAIL)||!in_array($role,$roles,true)) throw new RuntimeException('Provide a valid name, email and staff role.');
   if(!in_array($status,['Active','Suspended','Inactive'],true)) $status='Active';
   if($id){
    $stmt=$pdo->prepare("SELECT role FROM admins WHERE id=? LIMIT 1");$stmt->execute([$id]);$oldRole=$stmt->fetchColumn();
    if($oldRole==='Super Admin') throw new RuntimeException('The Super Admin account cannot be edited here.');
    if($password!==''){
     if(strlen($password)<12) throw new RuntimeException('Password must contain at least 12 characters.');
     $stmt=$pdo->prepare("UPDATE admins SET full_name=?,email=?,role=?,status=?,password_hash=? WHERE id=?");
     $stmt->execute([$name,$email,$role,$status,password_hash($password,PASSWORD_DEFAULT),$id]);
    } else {
     $stmt=$pdo->prepare("UPDATE admins SET full_name=?,email=?,role=?,status=? WHERE id=?");
     $stmt->execute([$name,$email,$role,$status,$id]);
    }
    $pdo->prepare("DELETE FROM admin_permissions WHERE admin_id=?")->execute([$id]);
    $chosen=$_POST['permissions']??[];
    foreach($chosen as $perm){ if(in_array($perm,$allPermissions,true)) $pdo->prepare("INSERT IGNORE INTO admin_permissions(admin_id,permission) VALUES(?,?)")->execute([$id,$perm]); }
    log_admin_activity('Administrator updated','admins',$name.' ('.$email.')');
    $notice='Administrator updated successfully.';
   } else {
    if(strlen($password)<12) throw new RuntimeException('Password must contain at least 12 characters.');
    $stmt=$pdo->prepare("INSERT INTO admins(full_name,email,password_hash,role,status) VALUES(?,?,?,?,?)");
    $stmt->execute([$name,$email,password_hash($password,PASSWORD_DEFAULT),$role,$status]); $newId=(int)$pdo->lastInsertId();
    $chosen=$_POST['permissions']??($defaults[$role]??[]);
    foreach($chosen as $perm){ if(in_array($perm,$allPermissions,true)) $pdo->prepare("INSERT IGNORE INTO admin_permissions(admin_id,permission) VALUES(?,?)")->execute([$newId,$perm]); }
    log_admin_activity('Administrator created','admins',$name.' ('.$email.')');
    $notice='Administrator created successfully.';
   }
  } elseif($action==='status'){
   if(!admin_can('admins.suspend')) throw new RuntimeException('You cannot change administrator status.');
   $id=(int)($_POST['id']??0); $new=clean_input($_POST['status']??'');
   $stmt=$pdo->prepare("SELECT full_name,role FROM admins WHERE id=? LIMIT 1");$stmt->execute([$id]);$target=$stmt->fetch();
   if(!$target || $target['role']==='Super Admin') throw new RuntimeException('The Super Admin account cannot be suspended.');
   if(!in_array($new,['Active','Suspended','Inactive'],true)) throw new RuntimeException('Invalid status.');
   $pdo->prepare("UPDATE admins SET status=? WHERE id=?")->execute([$new,$id]);
   log_admin_activity('Administrator status changed','admins',$target['full_name'].' → '.$new);
   $notice='Administrator status updated.';
  }
 } catch(Throwable $e){ error_log('[PSA] Sub-admin error: '.$e->getMessage()); $error=$e instanceof RuntimeException?$e->getMessage():'Unable to complete request.'; }
}

$edit=null;
if(isset($_GET['edit'])){
 $stmt=$pdo->prepare("SELECT * FROM admins WHERE id=? LIMIT 1");$stmt->execute([(int)$_GET['edit']]);$edit=$stmt->fetch()?:null;
 if($edit && $edit['role']==='Super Admin') $edit=null;
}
$selected=[];
if($edit){$stmt=$pdo->prepare("SELECT permission FROM admin_permissions WHERE admin_id=?");$stmt->execute([(int)$edit['id']]);$selected=$stmt->fetchAll(PDO::FETCH_COLUMN);}
$admins=$pdo->query("SELECT id,full_name,email,role,status,created_at,last_login_at,last_login_ip FROM admins ORDER BY role='Super Admin' DESC, full_name ASC")->fetchAll();

function permission_groups(array $permissions): array {
 $groups=[]; foreach($permissions as $p){$parts=explode('.',$p);$groups[$parts[0]][]=$p;} return $groups;
}
$groups=permission_groups($allPermissions);
include 'admin-header.php';
?>
<div class="admin-content">
<div class="admin-page-actions"><div><h1>Sub-Admin Management</h1><p>Create, secure and manage PSA staff administrators with role-based permissions.</p></div><?php if(admin_can('admins.create')):?><a class="admin-btn gold" href="?new=1#editor"><i class="fa fa-plus"></i> Add Sub-Admin</a><?php endif;?></div>
<?php if($notice):?><div class="alert-admin success"><?=safe($notice)?></div><?php endif;?>
<?php if($error):?><div class="alert-admin error"><?=safe($error)?></div><?php endif;?>

<?php if($edit || isset($_GET['new'])):?>
<div class="admin-card" id="editor"><h2><?= $edit?'Edit Sub-Admin':'Create Sub-Admin' ?></h2>
<form method="post" class="admin-form"><input type="hidden" name="action" value="save"><input type="hidden" name="id" value="<?= (int)($edit['id']??0) ?>"><?=csrf_field()?>
<div class="admin-grid two">
<div><label>Full Name</label><input name="full_name" required value="<?=safe($edit['full_name']??'')?>"></div>
<div><label>Email</label><input type="email" name="email" required value="<?=safe($edit['email']??'')?>"></div>
<div><label>Role</label><select name="role" id="adminRole"><?php foreach($roles as $r):?><option <?=($edit['role']??'')===$r?'selected':''?>><?=safe($r)?></option><?php endforeach;?></select></div>
<div><label>Status</label><select name="status"><?php foreach(['Active','Suspended','Inactive'] as $s):?><option <?=($edit['status']??'Active')===$s?'selected':''?>><?=$s?></option><?php endforeach;?></select></div>
<div class="full"><label>Password <?= $edit?'(leave blank to keep current)':'' ?></label><input type="password" name="password" minlength="12" <?= $edit?'':'required' ?> autocomplete="new-password"></div>
</div>
<h3 class="mt-4">Permissions</h3>
<div class="permission-grid">
<?php foreach($groups as $group=>$perms):?><div class="permission-group"><h4><?=safe(ucwords(str_replace('_',' ',$group)))?></h4><?php foreach($perms as $perm):?><label><input type="checkbox" name="permissions[]" value="<?=safe($perm)?>" class="permission-check" <?=in_array($perm,$selected,true)?'checked':''?>> <?=safe($perm)?></label><?php endforeach;?></div><?php endforeach;?>
</div>
<div class="admin-actions mt-4"><button class="admin-btn gold" type="submit"><i class="fa fa-save"></i> Save Administrator</button><a class="admin-btn" href="sub-admins.php">Cancel</a></div>
</form></div>
<?php endif;?>

<div class="admin-card"><div class="admin-table-wrap"><table class="admin-table"><thead><tr><th>Name</th><th>Email</th><th>Role</th><th>Status</th><th>Last Login</th><th>Actions</th></tr></thead><tbody>
<?php foreach($admins as $a): ?>
<?php $adminStatus=$a['status']??'Active'; $toggleStatus=$adminStatus==='Active'?'Suspended':'Active'; ?>
<tr>
<td><strong><?=safe($a['full_name'])?></strong></td>
<td><?=safe($a['email'])?></td>
<td><?=safe($a['role'])?></td>
<td><span class="badge-status"><?=safe($adminStatus)?></span></td>
<td><?=safe($a['last_login_at']??'Never')?></td>
<td>
<?php if($a['role']!=='Super Admin' && admin_can('admins.edit')): ?>
<a class="admin-btn blue" href="?edit=<?=intval($a['id'])?>#editor"><i class="fa fa-pencil"></i> Edit</a>
<?php endif; ?>
<?php if($a['role']!=='Super Admin' && admin_can('admins.suspend')): ?>
<form method="post" style="display:inline"><input type="hidden" name="action" value="status"><input type="hidden" name="id" value="<?=intval($a['id'])?>"><?=csrf_field()?><input type="hidden" name="status" value="<?=safe($toggleStatus)?>"><button class="admin-btn" type="submit"><?=safe($adminStatus==='Active'?'Suspend':'Activate')?></button></form>
<?php endif; ?>
</td>
</tr>
<?php endforeach;?>
</tbody></table></div></div>
</div>
<script>
const defaults=<?=json_encode($defaults)?>;
const role=document.getElementById('adminRole');
if(role) role.addEventListener('change',function(){
 const chosen=defaults[this.value]||[];
 document.querySelectorAll('.permission-check').forEach(c=>c.checked=chosen.includes(c.value));
});
</script>
<?php include 'admin-footer.php'; ?>