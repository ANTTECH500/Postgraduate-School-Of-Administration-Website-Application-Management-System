<?php require_admin_permission('programs.view');

include 'admin-header.php';
$success=null;
if($_SERVER['REQUEST_METHOD']==='POST'){
    if(!admin_can('programs.create')) { http_response_code(403); exit('Access denied.'); }
    if(!verify_csrf()) { http_response_code(419); exit('Security token expired.'); }
    $stmt=$pdo->prepare("INSERT INTO programs (title,level,category,duration,study_mode,tuition,intake,description,status) VALUES (?,?,?,?,?,?,?,?,?)");
    $stmt->execute([clean_input($_POST['title']),clean_input($_POST['level']),clean_input($_POST['category']),clean_input($_POST['duration']),clean_input($_POST['study_mode']),clean_input($_POST['tuition']),clean_input($_POST['intake']),clean_input($_POST['description']),clean_input($_POST['status'])]);
    $success="Program added successfully.";
}
$programs=$pdo->query("SELECT * FROM programs ORDER BY created_at DESC")->fetchAll();
?>
<div class="admin-content">
<?php if($success): ?><div class="alert-admin success"><?= safe($success) ?></div><?php endif; ?>
<div class="admin-card"><h2>Program Management</h2><form method="post" class="admin-form"><?= csrf_field() ?>
<div><label>Program Title</label><input name="title" required></div><div><label>Level</label><select name="level"><option>Undergraduate</option><option>Postgraduate</option><option>Online Learning</option></select></div>
<div><label>Category</label><input name="category"></div><div><label>Duration</label><input name="duration"></div><div><label>Study Mode</label><input name="study_mode"></div><div><label>Tuition</label><input name="tuition"></div><div><label>Intake</label><input name="intake"></div><div><label>Status</label><select name="status"><option>Active</option><option>Inactive</option></select></div>
<div class="full"><label>Description</label><textarea name="description" rows="4"></textarea></div><div class="full"><button class="admin-btn gold"><i class="fa fa-plus"></i> Add Program</button></div></form></div>
<div class="admin-table-wrap"><table class="admin-table"><thead><tr><th>Title</th><th>Level</th><th>Category</th><th>Duration</th><th>Mode</th><th>Status</th></tr></thead><tbody><?php foreach($programs as $p): ?><tr><td><?= safe($p['title']) ?></td><td><?= safe($p['level']) ?></td><td><?= safe($p['category']) ?></td><td><?= safe($p['duration']) ?></td><td><?= safe($p['study_mode']) ?></td><td><?= safe($p['status']) ?></td></tr><?php endforeach; ?></tbody></table></div>
</div>
<?php include 'admin-footer.php'; ?>