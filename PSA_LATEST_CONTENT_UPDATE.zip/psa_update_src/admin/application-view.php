<?php require_admin_permission('applications.view');

include 'admin-header.php';
$id = intval($_GET['id'] ?? 0);
$success = null; $error = null;

if($_SERVER['REQUEST_METHOD']==='POST'){
    if(!admin_can('applications.edit')) { http_response_code(403); exit('Access denied.'); }
    if(!verify_csrf()) { http_response_code(419); exit('Security token expired.'); }
    try{
        $newStatus = clean_input($_POST['application_status']);
        $advisor = clean_input($_POST['assigned_advisor']);
        $note = clean_input($_POST['note']);

        $stmt=$pdo->prepare("UPDATE applications SET application_status=?, assigned_advisor=?, admin_notes=? WHERE id=?");
        $stmt->execute([$newStatus,$advisor,$note,$id]);

        $stmt=$pdo->prepare("INSERT INTO tracking_logs (application_id,status,note) VALUES (?,?,?)");
        $stmt->execute([$id,$newStatus,$note ?: "Application status updated by admin."]);

        $stmt=$pdo->prepare("SELECT student_id FROM applications WHERE id=?");
        $stmt->execute([$id]);
        $sid=$stmt->fetch()['student_id'] ?? null;

        if($sid){
            $stmt=$pdo->prepare("INSERT INTO messages (student_id,sender_type,subject,message) VALUES (?,'Admin',?,?)");
            $stmt->execute([$sid,"Application Status Updated","Your application status is now: ".$newStatus.". ".$note]);
        }

        $success="Application updated successfully.";
    }catch(Exception $e){ $error=$e->getMessage(); }
}


if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['checklist_id'])){
    if(!admin_can('checklist.verify')){http_response_code(403);exit('Access denied.');}
    if(!verify_csrf()){http_response_code(419);exit('Security token expired.');}
    $cid=(int)$_POST['checklist_id'];$status=clean_input($_POST['checklist_status']??'Pending');$note=clean_input($_POST['checklist_note']??'');
    if(in_array($status,['Pending','Verified','Rejected','Not Applicable'],true)){
        $stmt=$pdo->prepare("UPDATE application_checklist SET status=?,verified_by=?,verified_at=IF(?='Verified',NOW(),NULL),note=? WHERE id=? AND application_id=?");
        $stmt->execute([$status,(int)$_SESSION['admin_id'],$status,$note,$cid,$id]);
        log_admin_activity('Application checklist updated','applications',"Application #$id checklist #$cid → $status");
    }
}

$stmt=$pdo->prepare("SELECT a.*, s.*, a.id app_id, a.created_at app_created, p.title program_title FROM applications a JOIN students s ON a.student_id=s.id LEFT JOIN programs p ON a.program_id=p.id WHERE a.id=?");
$stmt->execute([$id]);
$app=$stmt->fetch();

$stmt=$pdo->prepare("SELECT * FROM documents WHERE application_id=? ORDER BY uploaded_at DESC");
$stmt->execute([$id]);
$docs=$stmt->fetchAll();

$stmt=$pdo->prepare("SELECT * FROM tracking_logs WHERE application_id=? ORDER BY created_at DESC");
$stmt->execute([$id]);
$logs=$stmt->fetchAll();
$checklist=[];$stageHistory=[];
try{
 $stmt=$pdo->prepare("SELECT c.*,a.full_name verifier FROM application_checklist c LEFT JOIN admins a ON a.id=c.verified_by WHERE c.application_id=? ORDER BY c.required_flag DESC,c.id");$stmt->execute([$id]);$checklist=$stmt->fetchAll();
 $stmt=$pdo->prepare("SELECT h.*,a.full_name changed_by_name FROM admission_stage_history h LEFT JOIN admins a ON a.id=h.changed_by WHERE h.application_id=? ORDER BY h.created_at DESC");$stmt->execute([$id]);$stageHistory=$stmt->fetchAll();
}catch(Throwable $e){error_log('[PSA] Application checklist/history: '.$e->getMessage());}
?>
<div class="admin-content">
<?php if($success): ?><div class="alert-admin success"><?= safe($success) ?></div><?php endif; ?>
<?php if($error): ?><div class="alert-admin error"><?= safe($error) ?></div><?php endif; ?>

<?php if(!$app): ?>
<div class="admin-card"><h2>Application not found</h2></div>
<?php else: ?>
<div class="admin-grid two">
    <div class="admin-card">
        <h2><?= safe($app['full_name']) ?></h2>
        <p><strong>Student ID:</strong> <?= safe($app['student_id']) ?></p>
        <p><strong>Reference Code:</strong> <?= safe($app['reference_code']) ?></p>
        <p><strong>Application Code:</strong> <?= safe($app['application_code']) ?></p>
        <p><strong>Email:</strong> <?= safe($app['email']) ?></p>
        <p><strong>Phone:</strong> <?= safe($app['phone']) ?></p>
        <p><strong>Program:</strong> <?= safe($app['program_title'] ?: $app['preferred_program']) ?></p>
        <p><strong>Statement:</strong> <?= safe($app['personal_statement']) ?></p>
    </div>

    <div class="admin-card">
        <h2>Update Application</h2>
        <form method="post" class="admin-form"><?= csrf_field() ?>
            <div class="full"><label>Status</label><select name="application_status">
                <?php foreach(['Submitted','Under Review','Pending Documents','Interview Scheduled','Offer Issued','Enrolled','Rejected'] as $s): ?>
                    <option <?= $app['application_status']===$s?'selected':'' ?>><?= $s ?></option>
                <?php endforeach; ?>
            </select></div>
            <div class="full"><label>Assigned Advisor</label><input name="assigned_advisor" value="<?= safe($app['assigned_advisor']) ?>" placeholder="Advisor name"></div>
            <div class="full"><label>Admin Note / Student Message</label><textarea name="note" rows="5"><?= safe($app['admin_notes']) ?></textarea></div>
            <div class="full"><button class="admin-btn gold"><i class="fa fa-save"></i> Save Update</button></div>
        </form>
    </div>
</div>


<div class="admin-grid two">
<div class="admin-card"><h2>Document / Admission Checklist</h2>
<?php foreach($checklist as $c):?><form method="post" class="checklist-row"><?=csrf_field()?><input type="hidden" name="checklist_id" value="<?=$c['id']?>"><div><strong><?=safe($c['item_label'])?></strong><small><?= $c['required_flag']?'Required':'Optional' ?></small></div><select name="checklist_status"><option <?=$c['status']==='Pending'?'selected':''?>>Pending</option><option <?=$c['status']==='Verified'?'selected':''?>>Verified</option><option <?=$c['status']==='Rejected'?'selected':''?>>Rejected</option><option <?=$c['status']==='Not Applicable'?'selected':''?>>Not Applicable</option></select><input name="checklist_note" value="<?=safe($c['note'])?>" placeholder="Verification note"><?php if(admin_can('checklist.verify')):?><button class="admin-btn gold">Save</button><?php endif;?></form><?php endforeach;?>
<?php if(!$checklist):?><p>No checklist records yet. Run the Phase 2 migration.</p><?php endif;?></div>
<div class="admin-card"><h2>Admissions Stage History</h2>
<?php foreach($stageHistory as $h):?><div class="timeline-item"><strong><?=safe($h['new_status'])?></strong><p><?=safe($h['note'])?></p><small><?=safe($h['created_at'])?> · <?=safe($h['changed_by_name']??'System')?></small></div><?php endforeach;?>
<?php if(!$stageHistory):?><p>No stage history recorded yet.</p><?php endif;?></div>
</div>

<div class="admin-grid two">
    <div class="admin-card">
        <h2>Documents</h2>
        <?php foreach($docs as $d): ?>
            <p><a href="../<?= safe($d['file_path']) ?>" target="_blank"><?= safe($d['document_type']) ?></a> — <span class="badge-status <?= safe($d['verification_status']) ?>"><?= safe($d['verification_status']) ?></span></p>
        <?php endforeach; ?>
    </div>
    <div class="admin-card">
        <h2>Tracking Timeline</h2>
        <?php foreach($logs as $l): ?>
            <div class="notice-box"><strong><?= safe($l['status']) ?></strong><p><?= safe($l['note']) ?></p><small><?= safe($l['created_at']) ?></small></div><br>
        <?php endforeach; ?>
    </div>
</div>
<?php endif; ?>
</div>
<?php include 'admin-footer.php'; ?>