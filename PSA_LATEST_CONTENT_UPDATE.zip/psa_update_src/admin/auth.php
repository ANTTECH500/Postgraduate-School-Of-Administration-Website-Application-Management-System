<?php
declare(strict_types=1);

require_once __DIR__ . '/../config.php';

function require_admin_login(): void
{
    if (empty($_SESSION['admin_id'])) {
        header('Location: login.php');
        exit;
    }

    $admin = current_admin();
    if (!$admin || (($admin['status'] ?? 'Active') !== 'Active')) {
        unset($_SESSION['admin_id'], $_SESSION['admin_role'], $_SESSION['admin_name']);
        header('Location: login.php?disabled=1');
        exit;
    }
}

function current_admin(): ?array
{
    global $pdo;
    if (empty($_SESSION['admin_id'])) return null;

    $stmt = $pdo->prepare(
        'SELECT id, full_name, email, password_hash, role, status, created_at, last_login_at, last_login_ip
         FROM admins WHERE id=? LIMIT 1'
    );
    $stmt->execute([(int)$_SESSION['admin_id']]);
    $admin = $stmt->fetch();

    return $admin ?: null;
}

function admin_role_can(array $roles = []): bool
{
    $admin = current_admin();
    if (!$admin || (($admin['status'] ?? 'Active') !== 'Active')) return false;
    if ($admin['role'] === 'Super Admin') return true;
    return in_array($admin['role'], $roles, true);
}

function admin_can(string $permission): bool
{
    $admin = current_admin();
    if (!$admin || (($admin['status'] ?? 'Active') !== 'Active')) return false;
    if ($admin['role'] === 'Super Admin') return true;

    global $pdo;
    try {
        $stmt = $pdo->prepare('SELECT 1 FROM admin_permissions WHERE admin_id=? AND permission=? LIMIT 1');
        $stmt->execute([(int)$admin['id'], $permission]);
        return (bool)$stmt->fetchColumn();
    } catch (Throwable $e) {
        return false;
    }
}

function require_admin_permission(string $permission): void
{
    require_admin_login();
    if (!admin_can($permission)) {
        http_response_code(403);
        exit('Access denied.');
    }
}

function log_admin_activity(string $action, ?string $module = null, ?string $description = null): void
{
    global $pdo;
    $admin = current_admin();
    if (!$admin) return;

    try {
        $stmt = $pdo->prepare(
            'INSERT INTO admin_activity_logs
             (admin_id,action,module,description,ip_address,user_agent)
             VALUES (?,?,?,?,?,?)'
        );
        $stmt->execute([
            (int)$admin['id'],
            $action,
            $module,
            $description,
            $_SERVER['REMOTE_ADDR'] ?? null,
            substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 1000)
        ]);
    } catch (Throwable $e) {
        error_log('[PSA] Activity log failed: '.$e->getMessage());
    }
}

function safe($value): string
{
    return htmlspecialchars((string)($value ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}
