
    </main>
</div>

<script src="../assets/js/admin.js?v=20260813.2"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
