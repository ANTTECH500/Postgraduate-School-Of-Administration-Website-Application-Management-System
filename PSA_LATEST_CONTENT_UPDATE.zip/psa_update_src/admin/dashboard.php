<?php include 'admin-header.php';

$totalStudents = $pdo->query("SELECT COUNT(*) c FROM students")->fetch()['c'] ?? 0;
$totalApps = $pdo->query("SELECT COUNT(*) c FROM applications")->fetch()['c'] ?? 0;
$pendingDocs = $pdo->query("SELECT COUNT(*) c FROM documents WHERE verification_status='Pending'")->fetch()['c'] ?? 0;
$totalMessages = $pdo->query("SELECT COUNT(*) c FROM messages")->fetch()['c'] ?? 0;
$inquiryCount=0;$followupCount=0;$enrolledCount=0;$offersCount=0;
try{
 $inquiryCount=(int)$pdo->query("SELECT COUNT(*) FROM admissions_inquiries WHERE status NOT IN ('Closed','Converted')")->fetchColumn();
 $followupCount=(int)$pdo->query("SELECT COUNT(*) FROM admissions_inquiries WHERE next_follow_up_at IS NOT NULL AND next_follow_up_at<=NOW() AND status NOT IN ('Closed','Converted')")->fetchColumn();
 $enrolledCount=(int)$pdo->query("SELECT COUNT(*) FROM applications WHERE application_status='Enrolled'")->fetchColumn();
 $offersCount=(int)$pdo->query("SELECT COUNT(*) FROM applications WHERE application_status='Offer Issued'")->fetchColumn();
}catch(Throwable $e){ }

$recentApps = $pdo->query("SELECT a.*, s.full_name, s.student_id, p.title program_title FROM applications a JOIN students s ON a.student_id=s.id LEFT JOIN programs p ON a.program_id=p.id ORDER BY a.created_at DESC LIMIT 8")->fetchAll();
$statusRows = $pdo->query("SELECT application_status, COUNT(*) total FROM applications GROUP BY application_status")->fetchAll();
?>
<div class="admin-content">
    <div class="admin-dashboard-graphic"><div><h2>PSA Administrative Control Centre</h2><p>Connected PSA management platform: CRM inquiries, admissions pipeline, applications, documents, student communication, LMS, notifications and management reporting.</p><p><strong>Office:</strong> Behind K. Poly / KsTU, Kumasi | <strong>Phone:</strong> +233 32 219 4448 | WhatsApp +233 242 684 348</p></div><img src="../assets/images/psa.jpeg" alt="PSA"></div><br><div class="admin-kpis">
        <div class="admin-kpi"><span>Total Students</span><strong><?= $totalStudents ?></strong></div>
        <div class="admin-kpi"><span>Applications</span><strong><?= $totalApps ?></strong></div>
        <div class="admin-kpi"><span>Pending Docs</span><strong><?= $pendingDocs ?></strong></div>
        <div class="admin-kpi"><span>Messages</span><strong><?= $totalMessages ?></strong></div><div class="admin-kpi"><span>Open Inquiries</span><strong><?= $inquiryCount ?></strong></div><div class="admin-kpi"><span>Follow-ups Due</span><strong><?= $followupCount ?></strong></div><div class="admin-kpi"><span>Offers</span><strong><?= $offersCount ?></strong></div><div class="admin-kpi"><span>Enrolled</span><strong><?= $enrolledCount ?></strong></div>
    </div>

    <div class="notice-box">
        <h3>Institutional Notice Management</h3>
        <p>This admin system includes a notices module for publishing student protection updates, partnership changes, transfer guidance, operational announcements and academic review information.</p>
        <a class="admin-btn gold" href="notices.php"><i class="fa fa-bullhorn"></i> Manage Notices</a>
    </div>

    <br>

    <div class="admin-grid two">
        <div class="admin-card">
            <h2>Recent Applications</h2>
            <div class="admin-table-wrap">
                <table class="admin-table">
                    <thead><tr><th>Code</th><th>Student</th><th>Program</th><th>Status</th><th>Action</th></tr></thead>
                    <tbody>
                    <?php foreach($recentApps as $a): ?>
                        <tr>
                            <td><?= safe($a['application_code']) ?></td>
                            <td><?= safe($a['full_name']) ?><br><small><?= safe($a['student_id']) ?></small></td>
                            <td><?= safe($a['program_title'] ?: $a['preferred_program']) ?></td>
                            <td><span class="badge-status <?= strtok($a['application_status'], ' ') ?>"><?= safe($a['application_status']) ?></span></td>
                            <td><a class="admin-btn blue" href="application-view.php?id=<?= $a['id'] ?>">View</a></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <div class="admin-card">
            <h2>Application Status Summary</h2>
            <?php foreach($statusRows as $s): ?>
                <p><strong><?= safe($s['application_status']) ?>:</strong> <?= intval($s['total']) ?></p>
            <?php endforeach; ?>
        </div>
    </div>
</div>
<?php include 'admin-footer.php'; ?>