<?php
require_once __DIR__ . '/auth.php';
require_admin_permission('settings.manage');
require_once __DIR__ . '/auth.php';
require_admin_permission('settings.manage');
$adminUser = current_admin();

$success = null;
$error = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf()) {
        $error = 'Your session expired. Please refresh and try again.';
    } else {
        $action = $_POST['action'] ?? 'settings';

        if ($action === 'settings') {
            foreach (($_POST['settings'] ?? []) as $key => $value) {
                $stmt = $pdo->prepare("INSERT INTO system_settings (setting_key,setting_value) VALUES (?,?) ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value)");
                $stmt->execute([clean_input($key), clean_input($value)]);
            }
            $success = 'Institution settings updated successfully.';
        }

        if ($action === 'password') {
            $current = $_POST['current_password'] ?? '';
            $new = $_POST['new_password'] ?? '';
            $confirm = $_POST['confirm_password'] ?? '';

            if (!password_verify($current, $adminUser['password_hash'])) {
                $error = 'Current password is incorrect.';
            } elseif (strlen($new) < 8) {
                $error = 'New password must contain at least 8 characters.';
            } elseif ($new !== $confirm) {
                $error = 'New password confirmation does not match.';
            } else {
                $stmt = $pdo->prepare('UPDATE admins SET password_hash=? WHERE id=?');
                $stmt->execute([password_hash($new, PASSWORD_DEFAULT), $adminUser['id']]);
                session_regenerate_id(true);
                $success = 'Administrator password changed successfully.';
            }
        }
    }
}

$settings = [];
foreach ($pdo->query("SELECT * FROM system_settings")->fetchAll() as $s) {
    $settings[$s['setting_key']] = $s['setting_value'];
}
function setting($key, $default='') {
    global $settings;
    return safe($settings[$key] ?? $default);
}
?>
<div class="admin-content">
  <?php if ($success): ?><div class="alert-admin success"><?= safe($success) ?></div><?php endif; ?>
  <?php if ($error): ?><div class="alert-admin error"><?= safe($error) ?></div><?php endif; ?>

  <div class="admin-page-actions">
    <div><h1>System Settings</h1><p>Manage PSA institutional information and administrator security.</p></div>
  </div>

  <div class="admin-grid two">
    <div class="admin-card">
      <div class="admin-card-header"><h2>Institution Settings</h2><i class="fa fa-building"></i></div>
      <form method="post" class="admin-form">
        <?= csrf_field() ?><input type="hidden" name="action" value="settings">
        <div><label>Institution Name</label><input name="settings[institution_name]" value="<?= setting('institution_name','Postgraduate School of Administration') ?>"></div>
        <div><label>Official Website</label><input name="settings[website]" value="<?= setting('website','https://psa.institute') ?>"></div>
        <div><label>Office Address</label><input name="settings[address]" value="<?= setting('address','Ghana | Behind K. Poly / KsTU, Kumasi') ?>"></div>
        <div><label>GPS Address</label><input name="settings[gps_address]" value="<?= setting('gps_address','AK-040-9257') ?>"></div>
        <div><label>Phone 1</label><input name="settings[phone_1]" value="<?= setting('phone_1','+233322194448') ?>"></div>
        <div><label>Phone 2</label><input name="settings[phone_2]" value="<?= setting('phone_2','') ?>"></div>
        <div><label>Official Email</label><input type="email" name="settings[email]" value="<?= setting('email','info@psa.institute') ?>"></div>
        <div><label>WhatsApp Number</label><input name="settings[whatsapp]" value="<?= setting('whatsapp','+233555077777') ?>"></div>
        <div><label>Google Maps Query</label><input name="settings[map_query]" value="<?= setting('map_query','Behind K. Poly / KsTU, Kumasi, Ghana') ?>"></div>
        <div><label>GPS Address</label><input name="settings[gps_address]" value="<?= setting('gps_address','AK-040-9257') ?>"></div>
        <div class="full"><label>Institution Profile</label><textarea name="settings[profile]" rows="6"><?= setting('profile','PSA is an educational and recruitment center in Kumasi, Ghana, supporting higher education programs and student admissions guidance.') ?></textarea></div>
        <div class="full"><button class="admin-btn gold" type="submit"><i class="fa fa-save"></i> Save Settings</button></div>
      </form>
    </div>

    <div class="admin-card">
      <div class="admin-card-header"><h2>Change Password</h2><i class="fa fa-lock"></i></div>
      <form method="post" class="admin-form">
        <?= csrf_field() ?><input type="hidden" name="action" value="password">
        <div class="full"><label>Current Password</label><input type="password" name="current_password" required></div>
        <div class="full"><label>New Password</label><input type="password" name="new_password" minlength="8" required></div>
        <div class="full"><label>Confirm New Password</label><input type="password" name="confirm_password" minlength="8" required></div>
        <div class="full"><button class="admin-btn blue" type="submit"><i class="fa fa-key"></i> Change Password</button></div>
      </form>
    </div>
  </div>
</div>
<?php include 'admin-footer.php'; ?>