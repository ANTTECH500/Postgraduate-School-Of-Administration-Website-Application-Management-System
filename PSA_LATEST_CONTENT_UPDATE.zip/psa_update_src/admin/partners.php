<?php require_admin_permission('partners.view');

include 'admin-header.php';
$success=null;
if($_SERVER['REQUEST_METHOD']==='POST'){
    if(!admin_can('partners.create')) { http_response_code(403); exit('Access denied.'); }
    if(!verify_csrf()) { http_response_code(419); exit('Security token expired.'); }
    $stmt=$pdo->prepare("INSERT INTO partners (name,country,website,status,notes) VALUES (?,?,?,?,?)");
    $stmt->execute([clean_input($_POST['name']),clean_input($_POST['country']),clean_input($_POST['website']),clean_input($_POST['status']),clean_input($_POST['notes'])]);
    $success="Partner record added.";
}
$partners=$pdo->query("SELECT * FROM partners ORDER BY created_at DESC")->fetchAll();
?>
<div class="admin-content">
<?php if($success): ?><div class="alert-admin success"><?= safe($success) ?></div><?php endif; ?>
<div class="admin-card"><h2>Partner University / Institution Management</h2><form method="post" class="admin-form"><?= csrf_field() ?>
<div><label>Institution Name</label><input name="name" required></div><div><label>Country</label><input name="country"></div><div><label>Website</label><input name="website"></div><div><label>Status</label><select name="status"><option>Active</option><option>Suspended</option><option>Terminated</option><option>Under Review</option></select></div><div class="full"><label>Notes</label><textarea name="notes" rows="5"></textarea></div><div class="full"><button class="admin-btn gold">Save Partner</button></div></form></div>
<div class="admin-table-wrap"><table class="admin-table"><thead><tr><th>Name</th><th>Country</th><th>Website</th><th>Status</th><th>Notes</th></tr></thead><tbody><?php foreach($partners as $p): ?><tr><td><?= safe($p['name']) ?></td><td><?= safe($p['country']) ?></td><td><?= safe($p['website']) ?></td><td><span class="badge-status"><?= safe($p['status']) ?></span></td><td><?= safe($p['notes']) ?></td></tr><?php endforeach; ?></tbody></table></div>
</div>
<?php include 'admin-footer.php'; ?>