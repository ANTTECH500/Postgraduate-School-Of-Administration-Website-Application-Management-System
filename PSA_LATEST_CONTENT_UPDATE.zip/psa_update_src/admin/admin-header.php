<?php
require_once __DIR__ . '/auth.php';
require_admin_login();
$adminUser = current_admin();
$currentAdminPage = basename($_SERVER['PHP_SELF']);
function adminActive($page){
    global $currentAdminPage;
    return $currentAdminPage === $page ? 'active' : '';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>PSA Admin Management System</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/png" href="../assets/images/psa-logo.png">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@600;700;800;900&family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">  
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="../assets/css/psa-modern.css?v=20260815.4">
    <link rel="stylesheet" href="../assets/css/student.css?v=20260815.4">
    <link rel="stylesheet" href="../assets/css/admin.css?v=20260815.4">
</head>
<body class="admin-body">
<div class="admin-overlay" id="adminOverlay"></div>

<div class="admin-layout">
    <aside class="admin-sidebar" id="adminSidebar">
        <div class="admin-brand">
            <img src="../assets/images/psa.jpeg" alt="PSA">
            <div>
                <strong>PSA</strong>
                <span>Admin System</span>
            </div>
        </div>

        <nav class="admin-nav">
            <a class="<?= adminActive('dashboard.php') ?>" href="dashboard.php"><i class="fa fa-dashboard"></i> Dashboard</a>
            <?php if (admin_can('applications.view')): ?><a class="<?= adminActive('applications.php') ?>" href="applications.php"><i class="fa fa-file-text"></i> Applications</a><?php endif; ?>
            <?php if (admin_can('inquiries.view')): ?><a class="<?= adminActive('inquiries.php') ?>" href="inquiries.php"><i class="fa fa-comments"></i> Inquiries</a><?php endif; ?>
            <?php if (admin_can('admissions.pipeline')): ?><a class="<?= adminActive('admissions-pipeline.php') ?>" href="admissions-pipeline.php"><i class="fa fa-tasks"></i> Admissions Pipeline</a><?php endif; ?>
            <?php if (admin_can('students.view')): ?><a class="<?= adminActive('students.php') ?>" href="students.php"><i class="fa fa-users"></i> Students</a><?php endif; ?>
            <?php if (admin_can('documents.view')): ?><a class="<?= adminActive('documents.php') ?>" href="documents.php"><i class="fa fa-folder-open"></i> Documents</a><?php endif; ?>
            <?php if (admin_can('messages.view')): ?><a class="<?= adminActive('messages.php') ?>" href="messages.php"><i class="fa fa-envelope"></i> Messages</a><?php endif; ?>
            <?php if (admin_can('programs.view')): ?><a class="<?= adminActive('programs.php') ?>" href="programs.php"><i class="fa fa-graduation-cap"></i> Academic Programmes</a><?php endif; ?>
            <?php if (admin_can('partners.view')): ?><a class="<?= adminActive('partners.php') ?>" href="partners.php"><i class="fa fa-university"></i> Partners</a><?php endif; ?>
            <?php if (admin_can('notices.view')): ?><a class="<?= adminActive('notices.php') ?>" href="notices.php"><i class="fa fa-bullhorn"></i> Notices</a><?php endif; ?>
            <?php if (admin_can('lms.view')): ?><a class="<?= adminActive('lms.php') ?>" href="lms.php"><i class="fa fa-book"></i> LMS</a><?php endif; ?>
            <?php if (admin_can('reports.view')): ?><a class="<?= adminActive('reports.php') ?>" href="reports.php"><i class="fa fa-bar-chart"></i> Reports</a><?php endif; ?><?php if (admin_can('payments.view')): ?><a class="<?= adminActive('payments.php') ?>" href="payments.php"><i class="fa fa-credit-card"></i> Payments</a><?php endif; ?>
            <?php if (admin_can('admins.view')): ?><a class="<?= adminActive('sub-admins.php') ?>" href="sub-admins.php"><i class="fa fa-user-plus"></i> Sub-Admins</a><?php endif; ?>
            <?php if (admin_can('audit.view')): ?><a class="<?= adminActive('activity-log.php') ?>" href="activity-log.php"><i class="fa fa-history"></i> Audit Log</a><?php endif; ?>
            <?php if (admin_can('settings.manage')): ?><a class="<?= adminActive('settings.php') ?>" href="settings.php"><i class="fa fa-cog"></i> Settings</a><?php endif; ?>
            <a href="logout.php"><i class="fa fa-sign-out"></i> Logout</a>
        </nav>
    </aside>

    <main class="admin-main">
        <header class="admin-top">
            <button class="admin-toggle" id="adminToggle"><i class="fa fa-bars"></i></button>
            <div>
                <h1>PSA Management System</h1>
                <p>Admissions, CRM, student tracking, communications, LMS and reports</p>
            </div>
            <div class="admin-user">
                <span><?= safe($adminUser['full_name']) ?></span>
                <small><?= safe($adminUser['role']) ?></small>
            </div>
        </header>
