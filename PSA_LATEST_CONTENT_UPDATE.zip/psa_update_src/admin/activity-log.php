<?php
declare(strict_types=1);
require_once __DIR__ . '/auth.php';
require_admin_permission('audit.view');

$page=(int)($_GET['page']??1); $page=max(1,$page); $limit=50; $offset=($page-1)*$limit;
$q=clean_input($_GET['q']??'');
$where='1=1';$params=[];
if($q!==''){ $where='(a.full_name LIKE ? OR l.action LIKE ? OR l.module LIKE ? OR l.description LIKE ?)'; $like="%$q%";$params=[$like,$like,$like,$like];}
$stmt=$pdo->prepare("SELECT l.*,a.full_name,a.email FROM admin_activity_logs l LEFT JOIN admins a ON a.id=l.admin_id WHERE $where ORDER BY l.created_at DESC LIMIT $limit OFFSET $offset");
$stmt->execute($params);$logs=$stmt->fetchAll();
include 'admin-header.php';
?>
<div class="admin-content">
<div class="admin-page-actions"><div><h1>Administrator Audit Log</h1><p>Security and accountability trail for administrative actions.</p></div></div>
<div class="admin-card"><form method="get" class="admin-search"><input name="q" value="<?=safe($q)?>" placeholder="Search administrator, action or module"><button class="admin-btn gold"><i class="fa fa-search"></i> Search</button></form></div>
<div class="admin-card"><div class="admin-table-wrap"><table class="admin-table"><thead><tr><th>Date</th><th>Administrator</th><th>Action</th><th>Module</th><th>Description</th><th>IP</th></tr></thead><tbody>
<?php foreach($logs as $l):?><tr><td><?=safe($l['created_at'])?></td><td><?=safe($l['full_name']??'System')?></td><td><?=safe($l['action'])?></td><td><?=safe($l['module'])?></td><td><?=safe($l['description'])?></td><td><?=safe($l['ip_address'])?></td></tr><?php endforeach;?>
<?php if(!$logs):?><tr><td colspan="6">No audit records found.</td></tr><?php endif;?>
</tbody></table></div></div>
</div>
<?php include 'admin-footer.php'; ?>