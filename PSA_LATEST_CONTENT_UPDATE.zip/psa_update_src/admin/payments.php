<?php
declare(strict_types=1);
require_once __DIR__ . '/auth.php';
require_admin_permission('payments.view');
$notice=$error=null;
if($_SERVER['REQUEST_METHOD']==='POST'){
 try{
  if(!admin_can('payments.manage'))throw new RuntimeException('Payment management permission required.');
  if(!verify_csrf())throw new RuntimeException('Security token expired.');
  $sid=(int)($_POST['student_id']??0)?:null;$aid=(int)($_POST['application_id']??0)?:null;$type=clean_input($_POST['payment_type']??'');$amount=(float)($_POST['amount']??0);$currency=clean_input($_POST['currency']??'GHS');$status=clean_input($_POST['status']??'Pending');$provider=clean_input($_POST['provider']??'');$pref=clean_input($_POST['provider_reference']??'');$notes=clean_input($_POST['notes']??'');
  if($type===''||$amount<0)throw new RuntimeException('Payment type and valid amount are required.');
  $ref='PAY-'.date('Ymd').'-'.strtoupper(bin2hex(random_bytes(4)));
  $paid=in_array($status,['Paid','Verified'],true)?date('Y-m-d H:i:s'):null;
  $s=$pdo->prepare("INSERT INTO payment_records(student_id,application_id,reference_code,payment_type,amount,currency,provider,provider_reference,status,paid_at,notes) VALUES(?,?,?,?,?,?,?,?,?,?,?)");
  $s->execute([$sid,$aid,$ref,$type,$amount,$currency,$provider,$pref,$status,$paid,$notes]);$notice="Payment record {$ref} created.";
  if($sid){$pdo->prepare("INSERT INTO student_notifications(student_id,title,message,notification_type) VALUES(?,?,?,'Finance')")->execute([$sid,'Payment Record Created',"Payment reference {$ref} has been recorded as {$status}."]);}log_admin_activity('Payment record created','payments',$ref);
 }catch(Throwable $e){$error=$e instanceof RuntimeException?$e->getMessage():'Unable to create payment record.';}
}
$students=$pdo->query("SELECT id,full_name,student_id FROM students ORDER BY full_name")->fetchAll();
$rows=$pdo->query("SELECT p.*,s.full_name,s.student_id FROM payment_records p LEFT JOIN students s ON s.id=p.student_id ORDER BY p.created_at DESC LIMIT 300")->fetchAll();
include 'admin-header.php';
?>
<div class="admin-content"><div class="admin-page-actions"><div><h1>Payment Records</h1><p>Central fee/payment ledger. Gateway integration can be connected later without changing the student or application data model.</p></div></div>
<?php if($notice):?><div class="alert-admin success"><?=safe($notice)?></div><?php endif;?><?php if($error):?><div class="alert-admin error"><?=safe($error)?></div><?php endif;?>
<div class="admin-card"><h2>Record Payment</h2><form method="post" class="admin-form"><?=csrf_field()?><div><label>Student</label><select name="student_id"><option value="">Not linked</option><?php foreach($students as $s):?><option value="<?=$s['id']?>"><?=safe($s['full_name'])?> — <?=safe($s['student_id'])?></option><?php endforeach;?></select></div><div><label>Payment Type</label><input name="payment_type" placeholder="Application / Tuition / Certification" required></div><div><label>Amount</label><input name="amount" type="number" min="0" step="0.01" required></div><div><label>Currency</label><input name="currency" value="GHS"></div><div><label>Provider</label><input name="provider" placeholder="Manual / MoMo / Bank"></div><div><label>Provider Reference</label><input name="provider_reference"></div><div><label>Status</label><select name="status"><option>Pending</option><option>Paid</option><option>Verified</option><option>Failed</option><option>Refunded</option></select></div><div class="full"><label>Notes</label><textarea name="notes"></textarea></div><div class="full"><button class="admin-btn gold">Create Payment Record</button></div></form></div>
<div class="admin-card"><div class="admin-table-wrap"><table class="admin-table"><thead><tr><th>Reference</th><th>Student</th><th>Type</th><th>Amount</th><th>Provider</th><th>Status</th><th>Date</th></tr></thead><tbody><?php foreach($rows as $r):?><tr><td><?=safe($r['reference_code'])?></td><td><?=safe($r['full_name']??'—')?> <small><?=safe($r['student_id']??'')?></small></td><td><?=safe($r['payment_type'])?></td><td><?=safe($r['currency'])?> <?=number_format((float)$r['amount'],2)?></td><td><?=safe($r['provider'])?></td><td><?=safe($r['status'])?></td><td><?=safe($r['created_at'])?></td></tr><?php endforeach;?></tbody></table></div></div></div>
<?php include 'admin-footer.php';?>