<?php require_admin_permission('notices.view');

include 'admin-header.php';
$success=null;
if($_SERVER['REQUEST_METHOD']==='POST'){
    if(!admin_can('notices.create')) { http_response_code(403); exit('Access denied.'); }
    if(!verify_csrf()) { http_response_code(419); exit('Security token expired.'); }
    $stmt=$pdo->prepare("INSERT INTO notices (title,notice_type,content,status) VALUES (?,?,?,?)");
    $stmt->execute([clean_input($_POST['title']),clean_input($_POST['notice_type']),clean_input($_POST['content']),clean_input($_POST['status'])]);
    $success="Notice saved successfully.";
}
$notices=$pdo->query("SELECT * FROM notices ORDER BY created_at DESC")->fetchAll();
?>
<div class="admin-content">
<?php if($success): ?><div class="alert-admin success"><?= safe($success) ?></div><?php endif; ?>
<div class="notice-box">
<h3>Student Protection & Partnership Notice Module</h3>
<p>Use this page to manage official student notices, transfer guidance, partnership changes, academic review updates and operational announcements. The current content should be confirmed by PSA management before publishing publicly.</p>
</div><br>
<div class="admin-card"><h2>Create Notice</h2><form method="post" class="admin-form"><?= csrf_field() ?>
<div><label>Title</label><input name="title" required></div><div><label>Notice Type</label><select name="notice_type"><option>General</option><option>Partnership Update</option><option>Student Protection</option><option>Transfer Guidance</option><option>Academic Review</option></select></div>
<div><label>Status</label><select name="status"><option>Draft</option><option>Published</option><option>Archived</option></select></div>
<div class="full"><label>Content</label><textarea name="content" rows="8" required></textarea></div><div class="full"><button class="admin-btn gold"><i class="fa fa-save"></i> Save Notice</button></div></form></div>
<div class="admin-table-wrap"><table class="admin-table"><thead><tr><th>Title</th><th>Type</th><th>Status</th><th>Content</th><th>Date</th></tr></thead><tbody><?php foreach($notices as $n): ?><tr><td><?= safe($n['title']) ?></td><td><?= safe($n['notice_type']) ?></td><td><span class="badge-status"><?= safe($n['status']) ?></span></td><td><?= nl2br(safe($n['content'])) ?></td><td><?= safe($n['created_at']) ?></td></tr><?php endforeach; ?></tbody></table></div>
</div>
<?php include 'admin-footer.php'; ?>