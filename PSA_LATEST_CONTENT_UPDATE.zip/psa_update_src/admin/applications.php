<?php require_admin_permission('applications.view');

include 'admin-header.php';
$status = $_GET['status'] ?? '';
$q = $_GET['q'] ?? '';

$sql = "SELECT a.*, s.full_name, s.student_id, s.reference_code, s.email, p.title program_title FROM applications a JOIN students s ON a.student_id=s.id LEFT JOIN programs p ON a.program_id=p.id WHERE 1=1";
$params = [];
if($status){ $sql .= " AND a.application_status=?"; $params[] = $status; }
if($q){ $sql .= " AND (s.full_name LIKE ? OR s.student_id LIKE ? OR s.reference_code LIKE ? OR a.application_code LIKE ?)"; $like="%$q%"; $params=array_merge($params,[$like,$like,$like,$like]); }
$sql .= " ORDER BY a.created_at DESC";
$stmt=$pdo->prepare($sql); $stmt->execute($params); $apps=$stmt->fetchAll();
?>
<div class="admin-content">
    <div class="admin-card">
        <h2>Application Management</h2>
        <form method="get" class="admin-form">
            <div><label>Search</label><input name="q" value="<?= safe($q) ?>" placeholder="Name, Student ID, Reference Code"></div>
            <div><label>Status</label><select name="status">
                <option value="">All Statuses</option>
                <?php foreach(['Submitted','Under Review','Pending Documents','Interview Scheduled','Offer Issued','Enrolled','Rejected'] as $s): ?>
                    <option <?= $status===$s?'selected':'' ?>><?= $s ?></option>
                <?php endforeach; ?>
            </select></div>
            <div class="full"><button class="admin-btn gold"><i class="fa fa-search"></i> Filter</button><a class="admin-btn gray" href="applications.php">Reset</a></div>
        </form>
    </div>
    <div class="admin-table-wrap">
        <table class="admin-table">
            <thead><tr><th>Application</th><th>Student</th><th>Program</th><th>Status</th><th>Advisor</th><th>Date</th><th>Action</th></tr></thead>
            <tbody>
            <?php foreach($apps as $a): ?>
            <tr>
                <td><?= safe($a['application_code']) ?><br><small><?= safe($a['reference_code']) ?></small></td>
                <td><?= safe($a['full_name']) ?><br><small><?= safe($a['email']) ?></small></td>
                <td><?= safe($a['program_title'] ?: $a['preferred_program']) ?></td>
                <td><span class="badge-status <?= strtok($a['application_status'], ' ') ?>"><?= safe($a['application_status']) ?></span></td>
                <td><?= safe($a['assigned_advisor'] ?: 'Unassigned') ?></td>
                <td><?= safe($a['created_at']) ?></td>
                <td><a class="admin-btn blue" href="application-view.php?id=<?= $a['id'] ?>"><i class="fa fa-eye"></i> View</a></td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php include 'admin-footer.php'; ?>