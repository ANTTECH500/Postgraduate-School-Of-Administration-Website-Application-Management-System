<?php require_admin_permission('students.view');

include 'admin-header.php';
$q=$_GET['q'] ?? '';
$sql="SELECT * FROM students WHERE 1=1"; $params=[];
if($q){$sql.=" AND (full_name LIKE ? OR email LIKE ? OR student_id LIKE ? OR reference_code LIKE ?)"; $like="%$q%"; $params=[$like,$like,$like,$like];}
$sql.=" ORDER BY created_at DESC";
$stmt=$pdo->prepare($sql); $stmt->execute($params); $students=$stmt->fetchAll();
?>
<div class="admin-content">
<div class="admin-card">
<h2>Student Management</h2>
<form method="get" class="admin-form"><div><label>Search Student</label><input name="q" value="<?= safe($q) ?>"></div><div style="align-self:end"><button class="admin-btn gold"><i class="fa fa-search"></i> Search</button></div></form>
</div>
<div class="admin-table-wrap"><table class="admin-table"><thead><tr><th>Student ID</th><th>Name</th><th>Contact</th><th>Reference</th><th>Status</th><th>Created</th></tr></thead><tbody>
<?php foreach($students as $s): ?><tr><td><?= safe($s['student_id']) ?></td><td><?= safe($s['full_name']) ?></td><td><?= safe($s['email']) ?><br><?= safe($s['phone']) ?></td><td><?= safe($s['reference_code']) ?></td><td><span class="badge-status <?= safe($s['status']) ?>"><?= safe($s['status']) ?></span></td><td><?= safe($s['created_at']) ?></td></tr><?php endforeach; ?>
</tbody></table></div>
</div>
<?php include 'admin-footer.php'; ?>