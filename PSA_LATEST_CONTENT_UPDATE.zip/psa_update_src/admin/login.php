<?php
declare(strict_types=1);
require_once __DIR__ . '/../config.php';

if (!empty($_SESSION['admin_id'])) {
    header('Location: dashboard.php');
    exit;
}

$error = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf()) {
        $error = 'Your session expired. Please refresh and try again.';
    } else {
        $email = strtolower(clean_input($_POST['email'] ?? ''));
        $password = (string)($_POST['password'] ?? '');
        $ip = $_SERVER['REMOTE_ADDR'] ?? '';

        try {
            $stmt = $pdo->prepare('SELECT * FROM admins WHERE email=? LIMIT 1');
            $stmt->execute([$email]);
            $admin = $stmt->fetch();

            $valid = $admin && password_verify($password, $admin['password_hash']);
            $active = $admin && (($admin['status'] ?? 'Active') === 'Active');

            $log = $pdo->prepare('INSERT INTO login_attempts (email,ip_address,successful) VALUES (?,?,?)');
            $log->execute([$email,$ip,($valid && $active) ? 1 : 0]);

            if ($valid && $active) {
                session_regenerate_id(true);
                $_SESSION['admin_id'] = (int)$admin['id'];
                $_SESSION['admin_name'] = $admin['full_name'];
                $_SESSION['admin_role'] = $admin['role'];

                $stmt = $pdo->prepare('UPDATE admins SET last_login_at=NOW(), last_login_ip=? WHERE id=?');
                $stmt->execute([$ip,(int)$admin['id']]);

                header('Location: dashboard.php');
                exit;
            }

            $error = ($valid && !$active)
                ? 'Your administrator account is not active. Contact the Super Admin.'
                : 'Invalid administrator email or password.';
        } catch (Throwable $e) {
            error_log('[PSA] Admin login error: '.$e->getMessage());
            $error = 'The administrator service is temporarily unavailable.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>PSA Admin Login</title>
<link rel="icon" href="../assets/images/psa-logo.png">
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@600;700;800;900&family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="../assets/css/admin.css?v=20260815.4">
<style>
.login-wrap{min-height:100vh;display:grid;place-items:center;padding:24px;background:radial-gradient(circle at 80% 15%,rgba(212,175,55,.22),transparent 32%),linear-gradient(135deg,#08182d,#143b68)}
.login-card{width:min(480px,100%);background:#fff;border-radius:24px;padding:clamp(26px,5vw,44px);box-shadow:0 25px 70px rgba(0,0,0,.24)}
.login-card img{width:92px;height:92px;object-fit:contain;margin:0 auto 14px}.login-card h1{font-family:Montserrat;color:#0B1F3A;font-weight:900}
.login-card .form-group{margin-bottom:16px}.login-card label{font-weight:700}.login-card input{width:100%;padding:13px 14px;border:1px solid #d9dee7;border-radius:12px}
</style>
</head>
<body>
<div class="login-wrap">
<div class="login-card">
<img src="../assets/images/psa-logo.png" alt="Postgraduate School of Administration">
<div class="text-center">
<div class="eyebrow">PSA Administration</div>
<h1>Management Control Centre</h1>
<p class="text-muted">Secure access for authorised PSA administrators.</p>
</div>
<?php if ($error): ?><div class="alert alert-danger"><?= htmlspecialchars($error,ENT_QUOTES,'UTF-8') ?></div><?php endif; ?>
<form method="post" novalidate>
<?= csrf_field() ?>
<div class="form-group"><label for="email">Email Address</label><input id="email" name="email" type="email" required autocomplete="username"></div>
<div class="form-group"><label for="password">Password</label><div class="input-group"><input id="password" name="password" type="password" required autocomplete="current-password"><button class="btn btn-outline-secondary" type="button" data-password-toggle="#password" aria-label="Show password"><i class="fa fa-eye"></i></button></div></div>
<button class="btn btn-lg w-100" style="background:#D4AF37;color:#0B1F3A;font-weight:800" type="submit"><i class="fa fa-sign-in"></i> Sign In</button>
</form>
</div></div>
<script>
document.querySelectorAll('[data-password-toggle]').forEach(function(btn){
 btn.addEventListener('click',function(){
  const input=document.querySelector(btn.dataset.passwordToggle); if(!input)return;
  input.type=input.type==='password'?'text':'password';
  btn.innerHTML=input.type==='password'?'<i class="fa fa-eye"></i>':'<i class="fa fa-eye-slash"></i>';
 });
});
</script>
</body>
</html>