<?php
declare(strict_types=1);
require_once __DIR__ . '/auth.php';
require_admin_permission('reports.view');

if(isset($_GET['export']) && $_GET['export']==='applications'){
 if(!admin_can('reports.export')){http_response_code(403);exit('Export permission required.');}
 header('Content-Type:text/csv; charset=utf-8');header('Content-Disposition:attachment; filename=psa-applications-'.date('Y-m-d').'.csv');
 $out=fopen('php://output','w');fputcsv($out,['Application Code','Student ID','Applicant','Email','Programme','Type','Status','Priority','Created At']);
 $q=$pdo->query("SELECT a.application_code,s.student_id,s.full_name,s.email,p.title academic_program,a.application_status,a.priority,a.created_at FROM applications a JOIN students s ON s.id=a.student_id LEFT JOIN programs p ON p.id=a.program_id ORDER BY a.created_at DESC");
 while($r=$q->fetch(PDO::FETCH_ASSOC)){fputcsv($out,[$r['application_code'],$r['student_id'],$r['full_name'],$r['email'],$r['academic_program'],'Academic',$r['application_status'],$r['priority'],$r['created_at']]);}
 fclose($out);log_admin_activity('Applications exported','reports','CSV export');exit;
}
$kpi=[];
$kpi['students']=(int)$pdo->query("SELECT COUNT(*) FROM students")->fetchColumn();
$kpi['applications']=(int)$pdo->query("SELECT COUNT(*) FROM applications")->fetchColumn();
$kpi['open_inquiries']=0;$kpi['pending_docs']=(int)$pdo->query("SELECT COUNT(*) FROM documents WHERE verification_status='Pending'")->fetchColumn();$kpi['enrolled']=(int)$pdo->query("SELECT COUNT(*) FROM applications WHERE application_status='Enrolled'")->fetchColumn();$kpi['offers']=(int)$pdo->query("SELECT COUNT(*) FROM applications WHERE application_status='Offer Issued'")->fetchColumn();
try{$kpi['open_inquiries']=(int)$pdo->query("SELECT COUNT(*) FROM admissions_inquiries WHERE status NOT IN ('Closed','Converted')")->fetchColumn();}catch(Throwable $e){}
$byStatus=$pdo->query("SELECT application_status,COUNT(*) total FROM applications GROUP BY application_status ORDER BY total DESC")->fetchAll();
$byProgram=$pdo->query("SELECT COALESCE(p.title,a.preferred_program,'Unspecified') program,COUNT(*) total FROM applications a LEFT JOIN programs p ON p.id=a.program_id GROUP BY program ORDER BY total DESC LIMIT 20")->fetchAll();
$inquiries=[];try{$inquiries=$pdo->query("SELECT status,COUNT(*) total FROM admissions_inquiries GROUP BY status")->fetchAll();}catch(Throwable $e){}
include 'admin-header.php';
?>
<div class="admin-content"><div class="admin-page-actions"><div><h1>Management Dashboard &amp; Reports</h1><p>Operational KPIs across students, admissions, CRM and document verification.</p></div><a class="admin-btn gold" href="?export=applications"><i class="fa fa-download"></i> Export Applications CSV</a></div>
<div class="admin-kpis"><div class="admin-kpi"><span>Students</span><strong><?=$kpi['students']?></strong></div><div class="admin-kpi"><span>Applications</span><strong><?=$kpi['applications']?></strong></div><div class="admin-kpi"><span>Open Inquiries</span><strong><?=$kpi['open_inquiries']?></strong></div><div class="admin-kpi"><span>Pending Documents</span><strong><?=$kpi['pending_docs']?></strong></div><div class="admin-kpi"><span>Offers</span><strong><?=$kpi['offers']?></strong></div><div class="admin-kpi"><span>Enrolled</span><strong><?=$kpi['enrolled']?></strong></div></div>
<div class="admin-grid two"><div class="admin-card"><h2>Applications by Stage</h2><?php foreach($byStatus as $r):?><p><strong><?=safe($r['application_status'])?></strong> <span class="badge-status"><?=intval($r['total'])?></span></p><?php endforeach;?></div><div class="admin-card"><h2>CRM Inquiry Funnel</h2><?php foreach($inquiries as $r):?><p><strong><?=safe($r['status'])?></strong> <span class="badge-status"><?=intval($r['total'])?></span></p><?php endforeach;?></div></div>
<div class="admin-card"><h2>Top Programmes by Applications</h2><div class="admin-table-wrap"><table class="admin-table"><thead><tr><th>Programme</th><th>Applications</th></tr></thead><tbody><?php foreach($byProgram as $r):?><tr><td><?=safe($r['program'])?></td><td><?=intval($r['total'])?></td></tr><?php endforeach;?></tbody></table></div></div>
</div>
<?php include 'admin-footer.php';?>