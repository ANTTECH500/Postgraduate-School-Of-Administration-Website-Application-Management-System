<?php
declare(strict_types=1);
require_once __DIR__ . '/auth.php';
if (!empty($_SESSION['admin_id'])) {
    log_admin_activity('Administrator logout','authentication','Administrator signed out.');
}
$_SESSION=[];
if(ini_get('session.use_cookies')){
 $params=session_get_cookie_params();
 setcookie(session_name(),'',['expires'=>time()-42000,'path'=>$params['path']??'/','domain'=>$params['domain']??'','secure'=>(bool)($params['secure']??false),'httponly'=>(bool)($params['httponly']??true),'samesite'=>$params['samesite']??'Lax']);
}
session_destroy();
header('Location: login.php');
exit;
