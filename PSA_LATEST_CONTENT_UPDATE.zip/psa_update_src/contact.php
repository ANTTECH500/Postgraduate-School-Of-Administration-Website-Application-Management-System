<?php
declare(strict_types=1);
require_once __DIR__ . '/config.php';
$notice=$error=null;
if($_SERVER['REQUEST_METHOD']==='POST'){
 if(!verify_csrf()){$error='Your session expired. Please refresh and try again.';}
 else{
  try{
   $name=clean_input($_POST['name']??'');$email=strtolower(clean_input($_POST['email']??''));$phone=clean_input($_POST['phone']??'');
   $interest=clean_input($_POST['interest']??'Other Inquiry');$message=clean_input($_POST['message']??'');
   if($name===''||!filter_var($email,FILTER_VALIDATE_EMAIL))throw new RuntimeException('Please provide your full name and a valid email address.');
   $code='INQ-'.date('Ymd').'-'.strtoupper(bin2hex(random_bytes(3)));
   $stmt=$pdo->prepare("INSERT INTO admissions_inquiries(inquiry_code,full_name,email,phone,interest_type,message,source,status) VALUES(?,?,?,?,?,?, 'Website','New')");
   $stmt->execute([$code,$name,$email,$phone,$interest,$message]);
   $notice="Thank you. Your enquiry reference is {$code}. A PSA advisor will follow up.";
  }catch(Throwable $e){error_log('[PSA] Contact inquiry: '.$e->getMessage());$error=$e instanceof RuntimeException?$e->getMessage():'We could not submit your enquiry. Please try again.';}
 }
}
include 'includes/header.php';
?>
<section class="hero-slider swiper" style="height:500px"><div class="swiper-wrapper"><div class="swiper-slide" style="background-image:url('assets/images/hero-meeting.jpg')"><div class="hero-content"><div class="eyebrow">Contact PSA</div><h1>Let’s Help You Take the Next Step</h1><p>Contact PSA for programme guidance, admissions support, scholarship information and consultation booking.</p><div class="hero-actions"><a class="btn btn-outline" href="location.php"><i class="fa fa-map-marker"></i> Location</a><a class="btn btn-gold" href="#contact-form"><i class="fa fa-envelope"></i> Send Message</a><a class="btn btn-white" href="tel:+233322194448"><i class="fa fa-phone"></i> Call Now</a></div></div></div></div></section>
<section class="section light" id="contact-form"><div class="grid grid-2"><div><div class="eyebrow">Contact Information</div><h2 style="color:var(--dark-blue);font-size:40px">Speak with a PSA Advisor</h2><p>Whether you are exploring educational opportunities, seeking admissions support or looking for scholarship guidance, our team is ready to assist.</p><div class="card"><h3><i class="fa fa-phone"></i> Phone</h3><p>+233 32 219 4448 / </p></div><div class="card"><h3><i class="fa fa-envelope"></i> Email</h3><p>info@psa.institute</p></div><div class="card"><h3><i class="fa fa-clock-o"></i> Working Hours</h3><p>Monday – Friday, 8:00 AM – 5:00 PM</p></div></div><div class="card"><h3>Send Us a Message</h3><?php if($notice):?><div class="alert success"><?=e($notice)?></div><?php endif;?><?php if($error):?><div class="alert error"><?=e($error)?></div><?php endif;?><form method="post"><?=csrf_field()?><input class="form-control" type="text" name="name" placeholder="Full Name" required><br><br><input class="form-control" type="email" name="email" placeholder="Email Address" required><br><br><input class="form-control" type="tel" name="phone" placeholder="Phone Number"><br><br><select class="form-control" name="interest"><option>Program Guidance</option><option>Admissions Support</option><option>Scholarships</option><option>Student Portal</option><option>Other Inquiry</option></select><br><br><textarea class="form-control" name="message" rows="6" placeholder="How can we help you?" required></textarea><br><br><button class="btn btn-gold" type="submit"><i class="fa fa-paper-plane"></i> Submit Inquiry</button></form></div></div></section>
<?php include 'includes/footer.php';?>