<?php include 'includes/header.php'; ?>
<section class="hero-slider swiper" style="height:560px"><div class="swiper-wrapper">
<div class="swiper-slide" style="background-image:url('assets/images/amuzu1-768x347.jpg')"><div class="hero-content">
<div class="eyebrow">PSA Programs</div><h1>Doctorate, Masters, Bachelor and Academic Programs</h1>
<p>Explore PSA’s legitimate program catalogue across law, health sciences, psychology, theology, business, accounting, cyber security, nursing, education, public administration, finance and more.</p>
<div class="hero-actions"><a class="btn btn-gold" href="#program-list"><i class="fa fa-search"></i> Search Programs</a><a class="btn btn-white" href="apply.php"><i class="fa fa-paper-plane"></i> Apply Now</a></div>
</div></div></div></section>

<section class="section light" id="program-list">
<div class="section-title"><div class="eyebrow">Program Directory</div><h2>Find a Program That Matches Your Career Goal</h2>
<p>Use the filters below to explore PSA programs. Contact PSA for current entry requirements, tuition, intake and partner route information.</p></div>

<div class="program-filter">
<input type="text" id="programSearch" placeholder="Search e.g. PhD Law, MBA, Nursing, Cyber Security">
<select id="levelFilter"><option value="all">All Study Levels</option><option value="doctorate">Doctorate / PhD</option><option value="masters">Masters / MPhil</option><option value="undergraduate">Undergraduate</option></select>
<select id="areaFilter"><option value="all">All Subject Areas</option><option value="business">Business / Management</option><option value="law">Law</option><option value="health">Health / Nursing / Psychology</option><option value="technology">Technology / Cyber Security</option><option value="finance">Finance / Accounting / Economics</option><option value="education">Education</option></select>
<select id="modeFilter"><option value="all">All Study Modes</option><option value="hybrid">Hybrid / Supported Learning</option></select>
</div>

<div class="program-badge-grid">
<div class="program-mini"><strong>Doctorate / PhD</strong><span>Law, health sciences, psychology, theology, business, cyber security, nursing and education.</span></div>
<div class="program-mini"><strong>Masters</strong><span>MBA, EMBA, LLM, MPA, MPH, MSc, MA and MPhil pathways.</span></div>
<div class="program-mini"><strong>Undergraduate</strong><span>LLB, BBA, BSc, BA and BCA options.</span></div>
<div class="program-mini"><strong>Professional Growth</strong><span>Business, HSE, finance, administration and leadership fields.</span></div>
</div><br>

<div class="grid grid-3"><div class="card program-card" data-level="doctorate" data-area="law" data-mode="hybrid">
<div class="program-img" style="background-image:url('assets/images/COOOO1.jpg')"></div>
<div class="program-content"><span class="tag">Doctorate</span><h3>PhD Law</h3>
<p>PhD Law is available through PSA guidance and partner/affiliated academic pathways. Contact PSA for admission requirements, fees and intake details.</p>
<div class="meta"><div><strong>Category:</strong> Law</div><div><strong>Mode:</strong> Hybrid / Supported Learning</div><div><strong>Intake:</strong> Contact PSA</div></div>
<div class="card-actions"><a class="details" href="contact.php"><i class="fa fa-comments"></i> Ask</a><a class="apply" href="apply.php"><i class="fa fa-paper-plane"></i> Apply</a></div></div></div>
<div class="card program-card" data-level="doctorate" data-area="health" data-mode="hybrid">
<div class="program-img" style="background-image:url('assets/images/amuzu1-768x347.jpg')"></div>
<div class="program-content"><span class="tag">Doctorate</span><h3>PhD Health Sciences</h3>
<p>PhD Health Sciences is available through PSA guidance and partner/affiliated academic pathways. Contact PSA for admission requirements, fees and intake details.</p>
<div class="meta"><div><strong>Category:</strong> Health Sciences</div><div><strong>Mode:</strong> Hybrid / Supported Learning</div><div><strong>Intake:</strong> Contact PSA</div></div>
<div class="card-actions"><a class="details" href="contact.php"><i class="fa fa-comments"></i> Ask</a><a class="apply" href="apply.php"><i class="fa fa-paper-plane"></i> Apply</a></div></div></div>
<div class="card program-card" data-level="doctorate" data-area="health" data-mode="hybrid">
<div class="program-img" style="background-image:url('assets/images/11.jpg')"></div>
<div class="program-content"><span class="tag">Doctorate</span><h3>PhD Psychology</h3>
<p>PhD Psychology is available through PSA guidance and partner/affiliated academic pathways. Contact PSA for admission requirements, fees and intake details.</p>
<div class="meta"><div><strong>Category:</strong> Psychology</div><div><strong>Mode:</strong> Hybrid / Supported Learning</div><div><strong>Intake:</strong> Contact PSA</div></div>
<div class="card-actions"><a class="details" href="contact.php"><i class="fa fa-comments"></i> Ask</a><a class="apply" href="apply.php"><i class="fa fa-paper-plane"></i> Apply</a></div></div></div>
<div class="card program-card" data-level="doctorate" data-area="business" data-mode="hybrid">
<div class="program-img" style="background-image:url('assets/images/COS-697x1024.jpg')"></div>
<div class="program-content"><span class="tag">Doctorate</span><h3>PhD Theology</h3>
<p>PhD Theology is available through PSA guidance and partner/affiliated academic pathways. Contact PSA for admission requirements, fees and intake details.</p>
<div class="meta"><div><strong>Category:</strong> Business and Management</div><div><strong>Mode:</strong> Hybrid / Supported Learning</div><div><strong>Intake:</strong> Contact PSA</div></div>
<div class="card-actions"><a class="details" href="contact.php"><i class="fa fa-comments"></i> Ask</a><a class="apply" href="apply.php"><i class="fa fa-paper-plane"></i> Apply</a></div></div></div>
<div class="card program-card" data-level="doctorate" data-area="finance" data-mode="hybrid">
<div class="program-img" style="background-image:url('assets/images/ozult3aw-300x300.png')"></div>
<div class="program-content"><span class="tag">Doctorate</span><h3>PhD Forensic Accounting and Audit</h3>
<p>PhD Forensic Accounting and Audit is available through PSA guidance and partner/affiliated academic pathways. Contact PSA for admission requirements, fees and intake details.</p>
<div class="meta"><div><strong>Category:</strong> Finance and Accounting</div><div><strong>Mode:</strong> Hybrid / Supported Learning</div><div><strong>Intake:</strong> Contact PSA</div></div>
<div class="card-actions"><a class="details" href="contact.php"><i class="fa fa-comments"></i> Ask</a><a class="apply" href="apply.php"><i class="fa fa-paper-plane"></i> Apply</a></div></div></div>
<div class="card program-card" data-level="doctorate" data-area="technology" data-mode="hybrid">
<div class="program-img" style="background-image:url('assets/images/1-1-11.jpg')"></div>
<div class="program-content"><span class="tag">Doctorate</span><h3>PhD Cyber Security Administration</h3>
<p>PhD Cyber Security Administration is available through PSA guidance and partner/affiliated academic pathways. Contact PSA for admission requirements, fees and intake details.</p>
<div class="meta"><div><strong>Category:</strong> Technology</div><div><strong>Mode:</strong> Hybrid / Supported Learning</div><div><strong>Intake:</strong> Contact PSA</div></div>
<div class="card-actions"><a class="details" href="contact.php"><i class="fa fa-comments"></i> Ask</a><a class="apply" href="apply.php"><i class="fa fa-paper-plane"></i> Apply</a></div></div></div>
<div class="card program-card" data-level="doctorate" data-area="business" data-mode="hybrid">
<div class="program-img" style="background-image:url('assets/images/COOOO1.jpg')"></div>
<div class="program-content"><span class="tag">Doctorate</span><h3>PhD Business Administration</h3>
<p>PhD Business Administration is available through PSA guidance and partner/affiliated academic pathways. Contact PSA for admission requirements, fees and intake details.</p>
<div class="meta"><div><strong>Category:</strong> Business and Management</div><div><strong>Mode:</strong> Hybrid / Supported Learning</div><div><strong>Intake:</strong> Contact PSA</div></div>
<div class="card-actions"><a class="details" href="contact.php"><i class="fa fa-comments"></i> Ask</a><a class="apply" href="apply.php"><i class="fa fa-paper-plane"></i> Apply</a></div></div></div>
<div class="card program-card" data-level="doctorate" data-area="health" data-mode="hybrid">
<div class="program-img" style="background-image:url('assets/images/amuzu1-768x347.jpg')"></div>
<div class="program-content"><span class="tag">Doctorate</span><h3>Doctor of Nursing Practice</h3>
<p>Doctor of Nursing Practice is available through PSA guidance and partner/affiliated academic pathways. Contact PSA for admission requirements, fees and intake details.</p>
<div class="meta"><div><strong>Category:</strong> Health Sciences</div><div><strong>Mode:</strong> Hybrid / Supported Learning</div><div><strong>Intake:</strong> Contact PSA</div></div>
<div class="card-actions"><a class="details" href="contact.php"><i class="fa fa-comments"></i> Ask</a><a class="apply" href="apply.php"><i class="fa fa-paper-plane"></i> Apply</a></div></div></div>
<div class="card program-card" data-level="doctorate" data-area="education" data-mode="hybrid">
<div class="program-img" style="background-image:url('assets/images/11.jpg')"></div>
<div class="program-content"><span class="tag">Doctorate</span><h3>Doctor of Education</h3>
<p>Doctor of Education is available through PSA guidance and partner/affiliated academic pathways. Contact PSA for admission requirements, fees and intake details.</p>
<div class="meta"><div><strong>Category:</strong> Education</div><div><strong>Mode:</strong> Hybrid / Supported Learning</div><div><strong>Intake:</strong> Contact PSA</div></div>
<div class="card-actions"><a class="details" href="contact.php"><i class="fa fa-comments"></i> Ask</a><a class="apply" href="apply.php"><i class="fa fa-paper-plane"></i> Apply</a></div></div></div>
<div class="card program-card" data-level="doctorate" data-area="health" data-mode="hybrid">
<div class="program-img" style="background-image:url('assets/images/COS-697x1024.jpg')"></div>
<div class="program-content"><span class="tag">Doctorate</span><h3>Doctor of Psychology</h3>
<p>Doctor of Psychology is available through PSA guidance and partner/affiliated academic pathways. Contact PSA for admission requirements, fees and intake details.</p>
<div class="meta"><div><strong>Category:</strong> Psychology</div><div><strong>Mode:</strong> Hybrid / Supported Learning</div><div><strong>Intake:</strong> Contact PSA</div></div>
<div class="card-actions"><a class="details" href="contact.php"><i class="fa fa-comments"></i> Ask</a><a class="apply" href="apply.php"><i class="fa fa-paper-plane"></i> Apply</a></div></div></div>
<div class="card program-card" data-level="masters" data-area="health" data-mode="hybrid">
<div class="program-img" style="background-image:url('assets/images/ozult3aw-300x300.png')"></div>
<div class="program-content"><span class="tag">Masters</span><h3>MSc Nursing (Clinical Track)</h3>
<p>MSc Nursing (Clinical Track) is available through PSA guidance and partner/affiliated academic pathways. Contact PSA for admission requirements, fees and intake details.</p>
<div class="meta"><div><strong>Category:</strong> Health Sciences</div><div><strong>Mode:</strong> Hybrid / Supported Learning</div><div><strong>Intake:</strong> Contact PSA</div></div>
<div class="card-actions"><a class="details" href="contact.php"><i class="fa fa-comments"></i> Ask</a><a class="apply" href="apply.php"><i class="fa fa-paper-plane"></i> Apply</a></div></div></div>
<div class="card program-card" data-level="masters" data-area="health" data-mode="hybrid">
<div class="program-img" style="background-image:url('assets/images/1-1-11.jpg')"></div>
<div class="program-content"><span class="tag">Masters</span><h3>MSc Nursing (Leadership and Management)</h3>
<p>MSc Nursing (Leadership and Management) is available through PSA guidance and partner/affiliated academic pathways. Contact PSA for admission requirements, fees and intake details.</p>
<div class="meta"><div><strong>Category:</strong> Health Sciences</div><div><strong>Mode:</strong> Hybrid / Supported Learning</div><div><strong>Intake:</strong> Contact PSA</div></div>
<div class="card-actions"><a class="details" href="contact.php"><i class="fa fa-comments"></i> Ask</a><a class="apply" href="apply.php"><i class="fa fa-paper-plane"></i> Apply</a></div></div></div>
<div class="card program-card" data-level="masters" data-area="health" data-mode="hybrid">
<div class="program-img" style="background-image:url('assets/images/COOOO1.jpg')"></div>
<div class="program-content"><span class="tag">Masters</span><h3>MSc Psychology</h3>
<p>MSc Psychology is available through PSA guidance and partner/affiliated academic pathways. Contact PSA for admission requirements, fees and intake details.</p>
<div class="meta"><div><strong>Category:</strong> Psychology</div><div><strong>Mode:</strong> Hybrid / Supported Learning</div><div><strong>Intake:</strong> Contact PSA</div></div>
<div class="card-actions"><a class="details" href="contact.php"><i class="fa fa-comments"></i> Ask</a><a class="apply" href="apply.php"><i class="fa fa-paper-plane"></i> Apply</a></div></div></div>
<div class="card program-card" data-level="masters" data-area="education" data-mode="hybrid">
<div class="program-img" style="background-image:url('assets/images/amuzu1-768x347.jpg')"></div>
<div class="program-content"><span class="tag">Masters</span><h3>MA Education</h3>
<p>MA Education is available through PSA guidance and partner/affiliated academic pathways. Contact PSA for admission requirements, fees and intake details.</p>
<div class="meta"><div><strong>Category:</strong> Education</div><div><strong>Mode:</strong> Hybrid / Supported Learning</div><div><strong>Intake:</strong> Contact PSA</div></div>
<div class="card-actions"><a class="details" href="contact.php"><i class="fa fa-comments"></i> Ask</a><a class="apply" href="apply.php"><i class="fa fa-paper-plane"></i> Apply</a></div></div></div>
<div class="card program-card" data-level="masters" data-area="business" data-mode="hybrid">
<div class="program-img" style="background-image:url('assets/images/11.jpg')"></div>
<div class="program-content"><span class="tag">Masters</span><h3>MA Philosophy</h3>
<p>MA Philosophy is available through PSA guidance and partner/affiliated academic pathways. Contact PSA for admission requirements, fees and intake details.</p>
<div class="meta"><div><strong>Category:</strong> Business and Management</div><div><strong>Mode:</strong> Hybrid / Supported Learning</div><div><strong>Intake:</strong> Contact PSA</div></div>
<div class="card-actions"><a class="details" href="contact.php"><i class="fa fa-comments"></i> Ask</a><a class="apply" href="apply.php"><i class="fa fa-paper-plane"></i> Apply</a></div></div></div>
<div class="card program-card" data-level="masters" data-area="health" data-mode="hybrid">
<div class="program-img" style="background-image:url('assets/images/COS-697x1024.jpg')"></div>
<div class="program-content"><span class="tag">Masters</span><h3>Master of Public Health</h3>
<p>Master of Public Health is available through PSA guidance and partner/affiliated academic pathways. Contact PSA for admission requirements, fees and intake details.</p>
<div class="meta"><div><strong>Category:</strong> Health Sciences</div><div><strong>Mode:</strong> Hybrid / Supported Learning</div><div><strong>Intake:</strong> Contact PSA</div></div>
<div class="card-actions"><a class="details" href="contact.php"><i class="fa fa-comments"></i> Ask</a><a class="apply" href="apply.php"><i class="fa fa-paper-plane"></i> Apply</a></div></div></div>
<div class="card program-card" data-level="masters" data-area="business" data-mode="hybrid">
<div class="program-img" style="background-image:url('assets/images/ozult3aw-300x300.png')"></div>
<div class="program-content"><span class="tag">Masters</span><h3>MSc Human Resource Management</h3>
<p>MSc Human Resource Management is available through PSA guidance and partner/affiliated academic pathways. Contact PSA for admission requirements, fees and intake details.</p>
<div class="meta"><div><strong>Category:</strong> Business and Management</div><div><strong>Mode:</strong> Hybrid / Supported Learning</div><div><strong>Intake:</strong> Contact PSA</div></div>
<div class="card-actions"><a class="details" href="contact.php"><i class="fa fa-comments"></i> Ask</a><a class="apply" href="apply.php"><i class="fa fa-paper-plane"></i> Apply</a></div></div></div>
<div class="card program-card" data-level="masters" data-area="finance" data-mode="hybrid">
<div class="program-img" style="background-image:url('assets/images/1-1-11.jpg')"></div>
<div class="program-content"><span class="tag">Masters</span><h3>MSc Accounting</h3>
<p>MSc Accounting is available through PSA guidance and partner/affiliated academic pathways. Contact PSA for admission requirements, fees and intake details.</p>
<div class="meta"><div><strong>Category:</strong> Finance and Accounting</div><div><strong>Mode:</strong> Hybrid / Supported Learning</div><div><strong>Intake:</strong> Contact PSA</div></div>
<div class="card-actions"><a class="details" href="contact.php"><i class="fa fa-comments"></i> Ask</a><a class="apply" href="apply.php"><i class="fa fa-paper-plane"></i> Apply</a></div></div></div>
<div class="card program-card" data-level="masters" data-area="finance" data-mode="hybrid">
<div class="program-img" style="background-image:url('assets/images/COOOO1.jpg')"></div>
<div class="program-content"><span class="tag">Masters</span><h3>MSc Finance</h3>
<p>MSc Finance is available through PSA guidance and partner/affiliated academic pathways. Contact PSA for admission requirements, fees and intake details.</p>
<div class="meta"><div><strong>Category:</strong> Finance and Accounting</div><div><strong>Mode:</strong> Hybrid / Supported Learning</div><div><strong>Intake:</strong> Contact PSA</div></div>
<div class="card-actions"><a class="details" href="contact.php"><i class="fa fa-comments"></i> Ask</a><a class="apply" href="apply.php"><i class="fa fa-paper-plane"></i> Apply</a></div></div></div>
<div class="card program-card" data-level="masters" data-area="finance" data-mode="hybrid">
<div class="program-img" style="background-image:url('assets/images/amuzu1-768x347.jpg')"></div>
<div class="program-content"><span class="tag">Masters</span><h3>MSc Economics</h3>
<p>MSc Economics is available through PSA guidance and partner/affiliated academic pathways. Contact PSA for admission requirements, fees and intake details.</p>
<div class="meta"><div><strong>Category:</strong> Finance and Accounting</div><div><strong>Mode:</strong> Hybrid / Supported Learning</div><div><strong>Intake:</strong> Contact PSA</div></div>
<div class="card-actions"><a class="details" href="contact.php"><i class="fa fa-comments"></i> Ask</a><a class="apply" href="apply.php"><i class="fa fa-paper-plane"></i> Apply</a></div></div></div>
<div class="card program-card" data-level="masters" data-area="technology" data-mode="hybrid">
<div class="program-img" style="background-image:url('assets/images/11.jpg')"></div>
<div class="program-content"><span class="tag">Masters</span><h3>MCA</h3>
<p>MCA is available through PSA guidance and partner/affiliated academic pathways. Contact PSA for admission requirements, fees and intake details.</p>
<div class="meta"><div><strong>Category:</strong> Technology</div><div><strong>Mode:</strong> Hybrid / Supported Learning</div><div><strong>Intake:</strong> Contact PSA</div></div>
<div class="card-actions"><a class="details" href="contact.php"><i class="fa fa-comments"></i> Ask</a><a class="apply" href="apply.php"><i class="fa fa-paper-plane"></i> Apply</a></div></div></div>
<div class="card program-card" data-level="masters" data-area="law" data-mode="hybrid">
<div class="program-img" style="background-image:url('assets/images/COS-697x1024.jpg')"></div>
<div class="program-content"><span class="tag">Masters</span><h3>LLM</h3>
<p>LLM is available through PSA guidance and partner/affiliated academic pathways. Contact PSA for admission requirements, fees and intake details.</p>
<div class="meta"><div><strong>Category:</strong> Law</div><div><strong>Mode:</strong> Hybrid / Supported Learning</div><div><strong>Intake:</strong> Contact PSA</div></div>
<div class="card-actions"><a class="details" href="contact.php"><i class="fa fa-comments"></i> Ask</a><a class="apply" href="apply.php"><i class="fa fa-paper-plane"></i> Apply</a></div></div></div>
<div class="card program-card" data-level="masters" data-area="business" data-mode="hybrid">
<div class="program-img" style="background-image:url('assets/images/ozult3aw-300x300.png')"></div>
<div class="program-content"><span class="tag">Masters</span><h3>MBA</h3>
<p>MBA is available through PSA guidance and partner/affiliated academic pathways. Contact PSA for admission requirements, fees and intake details.</p>
<div class="meta"><div><strong>Category:</strong> Business and Management</div><div><strong>Mode:</strong> Hybrid / Supported Learning</div><div><strong>Intake:</strong> Contact PSA</div></div>
<div class="card-actions"><a class="details" href="contact.php"><i class="fa fa-comments"></i> Ask</a><a class="apply" href="apply.php"><i class="fa fa-paper-plane"></i> Apply</a></div></div></div>
<div class="card program-card" data-level="masters" data-area="business" data-mode="hybrid">
<div class="program-img" style="background-image:url('assets/images/1-1-11.jpg')"></div>
<div class="program-content"><span class="tag">Masters</span><h3>EMBA</h3>
<p>EMBA is available through PSA guidance and partner/affiliated academic pathways. Contact PSA for admission requirements, fees and intake details.</p>
<div class="meta"><div><strong>Category:</strong> Business and Management</div><div><strong>Mode:</strong> Hybrid / Supported Learning</div><div><strong>Intake:</strong> Contact PSA</div></div>
<div class="card-actions"><a class="details" href="contact.php"><i class="fa fa-comments"></i> Ask</a><a class="apply" href="apply.php"><i class="fa fa-paper-plane"></i> Apply</a></div></div></div>
<div class="card program-card" data-level="masters" data-area="education" data-mode="hybrid">
<div class="program-img" style="background-image:url('assets/images/COOOO1.jpg')"></div>
<div class="program-content"><span class="tag">Masters</span><h3>MEd Curriculum and Instruction</h3>
<p>MEd Curriculum and Instruction is available through PSA guidance and partner/affiliated academic pathways. Contact PSA for admission requirements, fees and intake details.</p>
<div class="meta"><div><strong>Category:</strong> Education</div><div><strong>Mode:</strong> Hybrid / Supported Learning</div><div><strong>Intake:</strong> Contact PSA</div></div>
<div class="card-actions"><a class="details" href="contact.php"><i class="fa fa-comments"></i> Ask</a><a class="apply" href="apply.php"><i class="fa fa-paper-plane"></i> Apply</a></div></div></div>
<div class="card program-card" data-level="masters" data-area="business" data-mode="hybrid">
<div class="program-img" style="background-image:url('assets/images/amuzu1-768x347.jpg')"></div>
<div class="program-content"><span class="tag">Masters</span><h3>MSc Mass Communication</h3>
<p>MSc Mass Communication is available through PSA guidance and partner/affiliated academic pathways. Contact PSA for admission requirements, fees and intake details.</p>
<div class="meta"><div><strong>Category:</strong> Business and Management</div><div><strong>Mode:</strong> Hybrid / Supported Learning</div><div><strong>Intake:</strong> Contact PSA</div></div>
<div class="card-actions"><a class="details" href="contact.php"><i class="fa fa-comments"></i> Ask</a><a class="apply" href="apply.php"><i class="fa fa-paper-plane"></i> Apply</a></div></div></div>
<div class="card program-card" data-level="masters" data-area="health" data-mode="hybrid">
<div class="program-img" style="background-image:url('assets/images/11.jpg')"></div>
<div class="program-content"><span class="tag">Masters</span><h3>MSc Health, Safety and Environment</h3>
<p>MSc Health, Safety and Environment is available through PSA guidance and partner/affiliated academic pathways. Contact PSA for admission requirements, fees and intake details.</p>
<div class="meta"><div><strong>Category:</strong> Health Sciences</div><div><strong>Mode:</strong> Hybrid / Supported Learning</div><div><strong>Intake:</strong> Contact PSA</div></div>
<div class="card-actions"><a class="details" href="contact.php"><i class="fa fa-comments"></i> Ask</a><a class="apply" href="apply.php"><i class="fa fa-paper-plane"></i> Apply</a></div></div></div>
<div class="card program-card" data-level="masters" data-area="business" data-mode="hybrid">
<div class="program-img" style="background-image:url('assets/images/COS-697x1024.jpg')"></div>
<div class="program-content"><span class="tag">Masters</span><h3>MPhil Public Administration</h3>
<p>MPhil Public Administration is available through PSA guidance and partner/affiliated academic pathways. Contact PSA for admission requirements, fees and intake details.</p>
<div class="meta"><div><strong>Category:</strong> Public Administration</div><div><strong>Mode:</strong> Hybrid / Supported Learning</div><div><strong>Intake:</strong> Contact PSA</div></div>
<div class="card-actions"><a class="details" href="contact.php"><i class="fa fa-comments"></i> Ask</a><a class="apply" href="apply.php"><i class="fa fa-paper-plane"></i> Apply</a></div></div></div>
<div class="card program-card" data-level="masters" data-area="business" data-mode="hybrid">
<div class="program-img" style="background-image:url('assets/images/ozult3aw-300x300.png')"></div>
<div class="program-content"><span class="tag">Masters</span><h3>MSc Public Administration</h3>
<p>MSc Public Administration is available through PSA guidance and partner/affiliated academic pathways. Contact PSA for admission requirements, fees and intake details.</p>
<div class="meta"><div><strong>Category:</strong> Public Administration</div><div><strong>Mode:</strong> Hybrid / Supported Learning</div><div><strong>Intake:</strong> Contact PSA</div></div>
<div class="card-actions"><a class="details" href="contact.php"><i class="fa fa-comments"></i> Ask</a><a class="apply" href="apply.php"><i class="fa fa-paper-plane"></i> Apply</a></div></div></div>
<div class="card program-card" data-level="masters" data-area="business" data-mode="hybrid">
<div class="program-img" style="background-image:url('assets/images/1-1-11.jpg')"></div>
<div class="program-content"><span class="tag">Masters</span><h3>MPA</h3>
<p>MPA is available through PSA guidance and partner/affiliated academic pathways. Contact PSA for admission requirements, fees and intake details.</p>
<div class="meta"><div><strong>Category:</strong> Public Administration</div><div><strong>Mode:</strong> Hybrid / Supported Learning</div><div><strong>Intake:</strong> Contact PSA</div></div>
<div class="card-actions"><a class="details" href="contact.php"><i class="fa fa-comments"></i> Ask</a><a class="apply" href="apply.php"><i class="fa fa-paper-plane"></i> Apply</a></div></div></div>
<div class="card program-card" data-level="masters" data-area="business" data-mode="hybrid">
<div class="program-img" style="background-image:url('assets/images/COOOO1.jpg')"></div>
<div class="program-content"><span class="tag">Masters</span><h3>MSc Criminology</h3>
<p>MSc Criminology is available through PSA guidance and partner/affiliated academic pathways. Contact PSA for admission requirements, fees and intake details.</p>
<div class="meta"><div><strong>Category:</strong> Business and Management</div><div><strong>Mode:</strong> Hybrid / Supported Learning</div><div><strong>Intake:</strong> Contact PSA</div></div>
<div class="card-actions"><a class="details" href="contact.php"><i class="fa fa-comments"></i> Ask</a><a class="apply" href="apply.php"><i class="fa fa-paper-plane"></i> Apply</a></div></div></div>
<div class="card program-card" data-level="masters" data-area="finance" data-mode="hybrid">
<div class="program-img" style="background-image:url('assets/images/amuzu1-768x347.jpg')"></div>
<div class="program-content"><span class="tag">Masters</span><h3>MSc Banking and Finance</h3>
<p>MSc Banking and Finance is available through PSA guidance and partner/affiliated academic pathways. Contact PSA for admission requirements, fees and intake details.</p>
<div class="meta"><div><strong>Category:</strong> Finance and Accounting</div><div><strong>Mode:</strong> Hybrid / Supported Learning</div><div><strong>Intake:</strong> Contact PSA</div></div>
<div class="card-actions"><a class="details" href="contact.php"><i class="fa fa-comments"></i> Ask</a><a class="apply" href="apply.php"><i class="fa fa-paper-plane"></i> Apply</a></div></div></div>
<div class="card program-card" data-level="masters" data-area="education" data-mode="hybrid">
<div class="program-img" style="background-image:url('assets/images/11.jpg')"></div>
<div class="program-content"><span class="tag">Masters</span><h3>MEd Education Administration</h3>
<p>MEd Education Administration is available through PSA guidance and partner/affiliated academic pathways. Contact PSA for admission requirements, fees and intake details.</p>
<div class="meta"><div><strong>Category:</strong> Education</div><div><strong>Mode:</strong> Hybrid / Supported Learning</div><div><strong>Intake:</strong> Contact PSA</div></div>
<div class="card-actions"><a class="details" href="contact.php"><i class="fa fa-comments"></i> Ask</a><a class="apply" href="apply.php"><i class="fa fa-paper-plane"></i> Apply</a></div></div></div>
<div class="card program-card" data-level="masters" data-area="law" data-mode="hybrid">
<div class="program-img" style="background-image:url('assets/images/COS-697x1024.jpg')"></div>
<div class="program-content"><span class="tag">Masters</span><h3>MPhil Law</h3>
<p>MPhil Law is available through PSA guidance and partner/affiliated academic pathways. Contact PSA for admission requirements, fees and intake details.</p>
<div class="meta"><div><strong>Category:</strong> Law</div><div><strong>Mode:</strong> Hybrid / Supported Learning</div><div><strong>Intake:</strong> Contact PSA</div></div>
<div class="card-actions"><a class="details" href="contact.php"><i class="fa fa-comments"></i> Ask</a><a class="apply" href="apply.php"><i class="fa fa-paper-plane"></i> Apply</a></div></div></div>
<div class="card program-card" data-level="masters" data-area="business" data-mode="hybrid">
<div class="program-img" style="background-image:url('assets/images/ozult3aw-300x300.png')"></div>
<div class="program-content"><span class="tag">Masters</span><h3>MSc Marketing</h3>
<p>MSc Marketing is available through PSA guidance and partner/affiliated academic pathways. Contact PSA for admission requirements, fees and intake details.</p>
<div class="meta"><div><strong>Category:</strong> Business and Management</div><div><strong>Mode:</strong> Hybrid / Supported Learning</div><div><strong>Intake:</strong> Contact PSA</div></div>
<div class="card-actions"><a class="details" href="contact.php"><i class="fa fa-comments"></i> Ask</a><a class="apply" href="apply.php"><i class="fa fa-paper-plane"></i> Apply</a></div></div></div>
<div class="card program-card" data-level="masters" data-area="business" data-mode="hybrid">
<div class="program-img" style="background-image:url('assets/images/1-1-11.jpg')"></div>
<div class="program-content"><span class="tag">Masters</span><h3>MSc Agribusiness</h3>
<p>MSc Agribusiness is available through PSA guidance and partner/affiliated academic pathways. Contact PSA for admission requirements, fees and intake details.</p>
<div class="meta"><div><strong>Category:</strong> Business and Management</div><div><strong>Mode:</strong> Hybrid / Supported Learning</div><div><strong>Intake:</strong> Contact PSA</div></div>
<div class="card-actions"><a class="details" href="contact.php"><i class="fa fa-comments"></i> Ask</a><a class="apply" href="apply.php"><i class="fa fa-paper-plane"></i> Apply</a></div></div></div>
<div class="card program-card" data-level="masters" data-area="business" data-mode="hybrid">
<div class="program-img" style="background-image:url('assets/images/COOOO1.jpg')"></div>
<div class="program-content"><span class="tag">Masters</span><h3>MA International Relations and Cultural Diplomacy</h3>
<p>MA International Relations and Cultural Diplomacy is available through PSA guidance and partner/affiliated academic pathways. Contact PSA for admission requirements, fees and intake details.</p>
<div class="meta"><div><strong>Category:</strong> Business and Management</div><div><strong>Mode:</strong> Hybrid / Supported Learning</div><div><strong>Intake:</strong> Contact PSA</div></div>
<div class="card-actions"><a class="details" href="contact.php"><i class="fa fa-comments"></i> Ask</a><a class="apply" href="apply.php"><i class="fa fa-paper-plane"></i> Apply</a></div></div></div>
<div class="card program-card" data-level="undergraduate" data-area="law" data-mode="hybrid">
<div class="program-img" style="background-image:url('assets/images/amuzu1-768x347.jpg')"></div>
<div class="program-content"><span class="tag">Undergraduate</span><h3>LLB</h3>
<p>LLB is available through PSA guidance and partner/affiliated academic pathways. Contact PSA for admission requirements, fees and intake details.</p>
<div class="meta"><div><strong>Category:</strong> Law</div><div><strong>Mode:</strong> Hybrid / Supported Learning</div><div><strong>Intake:</strong> Contact PSA</div></div>
<div class="card-actions"><a class="details" href="contact.php"><i class="fa fa-comments"></i> Ask</a><a class="apply" href="apply.php"><i class="fa fa-paper-plane"></i> Apply</a></div></div></div>
<div class="card program-card" data-level="undergraduate" data-area="business" data-mode="hybrid">
<div class="program-img" style="background-image:url('assets/images/11.jpg')"></div>
<div class="program-content"><span class="tag">Undergraduate</span><h3>BA Hospitality and Tourism Management</h3>
<p>BA Hospitality and Tourism Management is available through PSA guidance and partner/affiliated academic pathways. Contact PSA for admission requirements, fees and intake details.</p>
<div class="meta"><div><strong>Category:</strong> Business and Management</div><div><strong>Mode:</strong> Hybrid / Supported Learning</div><div><strong>Intake:</strong> Contact PSA</div></div>
<div class="card-actions"><a class="details" href="contact.php"><i class="fa fa-comments"></i> Ask</a><a class="apply" href="apply.php"><i class="fa fa-paper-plane"></i> Apply</a></div></div></div>
<div class="card program-card" data-level="undergraduate" data-area="business" data-mode="hybrid">
<div class="program-img" style="background-image:url('assets/images/COS-697x1024.jpg')"></div>
<div class="program-content"><span class="tag">Undergraduate</span><h3>BA Marketing</h3>
<p>BA Marketing is available through PSA guidance and partner/affiliated academic pathways. Contact PSA for admission requirements, fees and intake details.</p>
<div class="meta"><div><strong>Category:</strong> Business and Management</div><div><strong>Mode:</strong> Hybrid / Supported Learning</div><div><strong>Intake:</strong> Contact PSA</div></div>
<div class="card-actions"><a class="details" href="contact.php"><i class="fa fa-comments"></i> Ask</a><a class="apply" href="apply.php"><i class="fa fa-paper-plane"></i> Apply</a></div></div></div>
<div class="card program-card" data-level="undergraduate" data-area="technology" data-mode="hybrid">
<div class="program-img" style="background-image:url('assets/images/ozult3aw-300x300.png')"></div>
<div class="program-content"><span class="tag">Undergraduate</span><h3>BCA</h3>
<p>BCA is available through PSA guidance and partner/affiliated academic pathways. Contact PSA for admission requirements, fees and intake details.</p>
<div class="meta"><div><strong>Category:</strong> Technology</div><div><strong>Mode:</strong> Hybrid / Supported Learning</div><div><strong>Intake:</strong> Contact PSA</div></div>
<div class="card-actions"><a class="details" href="contact.php"><i class="fa fa-comments"></i> Ask</a><a class="apply" href="apply.php"><i class="fa fa-paper-plane"></i> Apply</a></div></div></div>
<div class="card program-card" data-level="undergraduate" data-area="business" data-mode="hybrid">
<div class="program-img" style="background-image:url('assets/images/1-1-11.jpg')"></div>
<div class="program-content"><span class="tag">Undergraduate</span><h3>BSc Human Resource Management</h3>
<p>BSc Human Resource Management is available through PSA guidance and partner/affiliated academic pathways. Contact PSA for admission requirements, fees and intake details.</p>
<div class="meta"><div><strong>Category:</strong> Business and Management</div><div><strong>Mode:</strong> Hybrid / Supported Learning</div><div><strong>Intake:</strong> Contact PSA</div></div>
<div class="card-actions"><a class="details" href="contact.php"><i class="fa fa-comments"></i> Ask</a><a class="apply" href="apply.php"><i class="fa fa-paper-plane"></i> Apply</a></div></div></div>
<div class="card program-card" data-level="undergraduate" data-area="health" data-mode="hybrid">
<div class="program-img" style="background-image:url('assets/images/COOOO1.jpg')"></div>
<div class="program-content"><span class="tag">Undergraduate</span><h3>BSc Nursing</h3>
<p>BSc Nursing is available through PSA guidance and partner/affiliated academic pathways. Contact PSA for admission requirements, fees and intake details.</p>
<div class="meta"><div><strong>Category:</strong> Health Sciences</div><div><strong>Mode:</strong> Hybrid / Supported Learning</div><div><strong>Intake:</strong> Contact PSA</div></div>
<div class="card-actions"><a class="details" href="contact.php"><i class="fa fa-comments"></i> Ask</a><a class="apply" href="apply.php"><i class="fa fa-paper-plane"></i> Apply</a></div></div></div>
<div class="card program-card" data-level="undergraduate" data-area="finance" data-mode="hybrid">
<div class="program-img" style="background-image:url('assets/images/amuzu1-768x347.jpg')"></div>
<div class="program-content"><span class="tag">Undergraduate</span><h3>BSc Finance</h3>
<p>BSc Finance is available through PSA guidance and partner/affiliated academic pathways. Contact PSA for admission requirements, fees and intake details.</p>
<div class="meta"><div><strong>Category:</strong> Finance and Accounting</div><div><strong>Mode:</strong> Hybrid / Supported Learning</div><div><strong>Intake:</strong> Contact PSA</div></div>
<div class="card-actions"><a class="details" href="contact.php"><i class="fa fa-comments"></i> Ask</a><a class="apply" href="apply.php"><i class="fa fa-paper-plane"></i> Apply</a></div></div></div>
<div class="card program-card" data-level="undergraduate" data-area="finance" data-mode="hybrid">
<div class="program-img" style="background-image:url('assets/images/11.jpg')"></div>
<div class="program-content"><span class="tag">Undergraduate</span><h3>BSc Accounting</h3>
<p>BSc Accounting is available through PSA guidance and partner/affiliated academic pathways. Contact PSA for admission requirements, fees and intake details.</p>
<div class="meta"><div><strong>Category:</strong> Finance and Accounting</div><div><strong>Mode:</strong> Hybrid / Supported Learning</div><div><strong>Intake:</strong> Contact PSA</div></div>
<div class="card-actions"><a class="details" href="contact.php"><i class="fa fa-comments"></i> Ask</a><a class="apply" href="apply.php"><i class="fa fa-paper-plane"></i> Apply</a></div></div></div>
<div class="card program-card" data-level="undergraduate" data-area="finance" data-mode="hybrid">
<div class="program-img" style="background-image:url('assets/images/COS-697x1024.jpg')"></div>
<div class="program-content"><span class="tag">Undergraduate</span><h3>BSc Economics</h3>
<p>BSc Economics is available through PSA guidance and partner/affiliated academic pathways. Contact PSA for admission requirements, fees and intake details.</p>
<div class="meta"><div><strong>Category:</strong> Finance and Accounting</div><div><strong>Mode:</strong> Hybrid / Supported Learning</div><div><strong>Intake:</strong> Contact PSA</div></div>
<div class="card-actions"><a class="details" href="contact.php"><i class="fa fa-comments"></i> Ask</a><a class="apply" href="apply.php"><i class="fa fa-paper-plane"></i> Apply</a></div></div></div>
<div class="card program-card" data-level="undergraduate" data-area="health" data-mode="hybrid">
<div class="program-img" style="background-image:url('assets/images/ozult3aw-300x300.png')"></div>
<div class="program-content"><span class="tag">Undergraduate</span><h3>BSc Health Sciences</h3>
<p>BSc Health Sciences is available through PSA guidance and partner/affiliated academic pathways. Contact PSA for admission requirements, fees and intake details.</p>
<div class="meta"><div><strong>Category:</strong> Health Sciences</div><div><strong>Mode:</strong> Hybrid / Supported Learning</div><div><strong>Intake:</strong> Contact PSA</div></div>
<div class="card-actions"><a class="details" href="contact.php"><i class="fa fa-comments"></i> Ask</a><a class="apply" href="apply.php"><i class="fa fa-paper-plane"></i> Apply</a></div></div></div>
<div class="card program-card" data-level="undergraduate" data-area="business" data-mode="hybrid">
<div class="program-img" style="background-image:url('assets/images/1-1-11.jpg')"></div>
<div class="program-content"><span class="tag">Undergraduate</span><h3>BBA</h3>
<p>BBA is available through PSA guidance and partner/affiliated academic pathways. Contact PSA for admission requirements, fees and intake details.</p>
<div class="meta"><div><strong>Category:</strong> Business and Management</div><div><strong>Mode:</strong> Hybrid / Supported Learning</div><div><strong>Intake:</strong> Contact PSA</div></div>
<div class="card-actions"><a class="details" href="contact.php"><i class="fa fa-comments"></i> Ask</a><a class="apply" href="apply.php"><i class="fa fa-paper-plane"></i> Apply</a></div></div></div></div><div class="no-result" id="noResult">No program found. Try another search or contact PSA for guidance.</div>
</section>

<section class="section"><div class="section-title"><div class="eyebrow">Partner / Affiliated Institutions</div><h2>Partner Universities and Recognized Academic Pathways</h2>
<p>Students should verify the exact program route, awarding institution and accreditation status before enrollment.</p></div>
<div class="grid grid-3">
<div class="card"><div class="icon-box"><i class="fa fa-university"></i></div><h3>Charisma University</h3><p>Accreditation references include Turks and Caicos Islands Ministry, CHEA, ACBSP, TRACS, IAU and related quality assurance bodies.</p></div>
</div></section>

<div class="partner-logo-strip">
<img src="assets/images/01.jpg"><img src="assets/images/ozult3aw-300x300.png"><img src="assets/images/ozult3aw-300x300.png"><img src="assets/images/01.jpg"><img src="assets/images/25-150x150-1-100x1001.jpg"><img src="assets/images/ppp_1_optimized_8-2-150x150.jpg">
</div>

<section class="cta"><h2>Need Help Choosing the Right PSA Program?</h2><p>Call +233 32 219 4448, or visit PSA behind K. Poly / KsTU, Kumasi.</p>
<div class="hero-actions" style="justify-content:center"><a class="btn btn-gold" href="apply.php"><i class="fa fa-paper-plane"></i> Apply Now</a><a class="btn btn-white" href="contact.php"><i class="fa fa-phone"></i> Contact PSA</a></div></section>
<?php include 'includes/footer.php'; ?>