# PSA Full PHP Application Deployment Guide

This package combines the modernized PSA public website with the Student Application, Reference Code, Tracking, Communication and LMS-ready module.

## Included Public Pages

- index.php
- about.php
- programs.php
- admissions.php
- partner-universities.php
- scholarships.php
- events.php
- blog.php
- contact.php

## Included Student Module

- apply.php
- track-application.php
- student-login.php
- student/dashboard.php
- student/application.php
- student/documents.php
- student/messages.php
- student/lms.php
- student/logout.php

## Database File

- database.sql

## Deployment Steps

### 1. Backup Existing Site
In cPanel File Manager, go to public_html, select all files, compress them as a backup, and download the backup.

### 2. Upload This Package
Upload PSA_full_combined_application.zip into public_html.

### 3. Extract
Right-click the ZIP and choose Extract. If it extracts into a folder, open that folder and move all contents directly into public_html.

Your public_html should directly contain index.php, apply.php, config.php, database.sql, assets/, includes/, student/, admin/, and uploads/.

### 4. Create MySQL Database
In cPanel MySQL Databases, create a database, create a user, assign the user to the database, and give ALL PRIVILEGES.

### 5. Import Database
In phpMyAdmin, select your database, click Import, choose database.sql, and click Go.

### 6. Edit config.php
Update the database credentials:

define('DB_NAME', 'your_database_name');
define('DB_USER', 'your_database_user');
define('DB_PASS', 'your_database_password');

### 7. Test Main Pages
Open:

- https://yourdomain.com/index.php
- https://yourdomain.com/apply.php
- https://yourdomain.com/track-application.php
- https://yourdomain.com/student-login.php

### 8. File Permissions
Use folders 0755 and files 0644. Ensure uploads/ and uploads/documents/ are writable.

### 9. If You Get 500 Error
Check PHP version, config.php database details, file permissions, cPanel Error Log, and .htaccess rules.

### 10. Next Phase
The next phase is the Admin Application to manage students, applications, statuses, documents, messages, LMS courses, programs, scholarships, and reports.
