<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/site.php';
include 'includes/header.php';
$mapQuery = psa_setting('map_query', SITE_MAP_QUERY);
$mapSrc = 'https://www.google.com/maps?q=' . rawurlencode($mapQuery) . '&output=embed';
?>
<section class="module-hero">
<div>
<div class="eyebrow">PSA Location</div>
<h1>Visit the Postgraduate School of Administration</h1>
<p>Ghana | Behind K. Poly / KsTU, Kumasi. Use the map or directions link below to find the PSA office.</p>
<div class="hero-actions">
<a class="btn btn-gold" href="https://www.google.com/maps/search/?api=1&query=<?= rawurlencode($mapQuery) ?>" target="_blank" rel="noopener"><i class="fa fa-map-marker"></i> Open in Google Maps</a>
<a class="btn btn-white" href="<?= e(psa_whatsapp_url('Hello PSA, I need directions to your Kumasi office.')) ?>" target="_blank" rel="noopener"><i class="fa fa-whatsapp"></i> Ask for Directions</a>
</div>
</div>
</section>

<section class="section light">
<div class="grid grid-2" style="align-items:stretch">
<div class="card">
<h2>Office Information</h2>
<p><strong>Address:</strong><br><?= e(psa_setting('address', SITE_ADDRESS)) ?></p>
<p><strong>GPS:</strong><br><?= e(psa_setting('gps_address', SITE_GPS)) ?></p>
<p><strong>Telephone:</strong><br><?= e(psa_setting('phone_1', SITE_PHONE_ALT)) ?> / <?= e(psa_setting('phone_2', SITE_PHONE_DISPLAY)) ?></p>
<p><strong>Email:</strong><br><a href="mailto:<?= e(psa_setting('email', SITE_EMAIL)) ?>"><?= e(psa_setting('email', SITE_EMAIL)) ?></a></p>
<div class="hero-actions">
<a class="btn btn-gold" href="contact.php"><i class="fa fa-envelope"></i> Contact Us</a>
<a class="btn btn-outline" href="apply.php"><i class="fa fa-paper-plane"></i> Apply Now</a>
</div>
</div>
<div class="card" style="padding:0;overflow:hidden;min-height:460px">
<iframe title="PSA location map" src="<?= e($mapSrc) ?>" width="100%" height="100%" style="border:0;min-height:460px" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
</div>
</div>
</section>
<?php include 'includes/footer.php'; ?>