// Legacy compatibility wrapper. Use assets/js/psa-modern.js.
