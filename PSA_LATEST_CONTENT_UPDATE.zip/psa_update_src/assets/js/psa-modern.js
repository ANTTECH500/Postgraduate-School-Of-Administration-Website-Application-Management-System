/**
 * PSA — Postgraduate School of Administration
 * Modern Interaction Layer
 *
 * Responsibilities:
 * - Responsive public navigation
 * - Accessible mobile menu
 * - Swiper hero carousel
 * - Scroll progress / back-to-top
 * - FAQ accordions
 * - Program filters
 * - Professional-program filters
 * - Password visibility
 * - Form UX and client-side validation
 * - Bootstrap tooltips/popovers
 * - Smooth internal navigation
 * - Prevent duplicate form submissions
 */
(function (window, document) {
    'use strict';

    const $ = window.jQuery;

    function ready(callback) {
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', callback, { once: true });
        } else {
            callback();
        }
    }

    function qs(selector, scope) {
        return (scope || document).querySelector(selector);
    }

    function qsa(selector, scope) {
        return Array.from((scope || document).querySelectorAll(selector));
    }

    function setExpanded(element, expanded) {
        if (element) element.setAttribute('aria-expanded', expanded ? 'true' : 'false');
    }

    ready(function () {

        /* ---------------------------------------------------------
           RESPONSIVE PUBLIC NAVIGATION
        --------------------------------------------------------- */
        const menuToggle = qs('#menuToggle');
        const menu = qs('#PSAMenu');
        const header = qs('#siteHeader');

        function closeMenu() {
            if (!menu) return;
            menu.classList.remove('show');
            setExpanded(menuToggle, false);
            if (menuToggle) {
                menuToggle.innerHTML = '<i class="fa fa-bars" aria-hidden="true"></i>';
            }
            qsa('.psa-menu .open, .psa-menu .open-menu').forEach(function (item) {
                item.classList.remove('open', 'open-menu');
            });
        }

        function openMenu() {
            if (!menu) return;
            menu.classList.add('show');
            setExpanded(menuToggle, true);
            if (menuToggle) {
                menuToggle.innerHTML = '<i class="fa fa-times" aria-hidden="true"></i>';
            }
        }

        if (menuToggle && menu) {
            menuToggle.addEventListener('click', function (event) {
                event.stopPropagation();
                menu.classList.contains('show') ? closeMenu() : openMenu();
            });

            // Close when a normal navigation link is selected.
            qsa('a', menu).forEach(function (link) {
                link.addEventListener('click', function () {
                    if (window.innerWidth <= 1180 && !link.closest('.has-dropdown, .has-mega')) {
                        closeMenu();
                    }
                });
            });
        }

        // Mobile dropdown/mega-menu controls. The current PSA header has
        // no dropdowns, but this supports future navigation additions.
        qsa('.has-dropdown > a, .has-mega > a').forEach(function (link) {
            link.addEventListener('click', function (event) {
                if (window.innerWidth > 1180) return;
                const parent = link.parentElement;
                if (!parent) return;
                event.preventDefault();
                parent.classList.toggle('open');
            });
        });

        document.addEventListener('click', function (event) {
            if (!menu || !menu.classList.contains('show')) return;
            if (menu.contains(event.target) || menuToggle?.contains(event.target)) return;
            closeMenu();
        });

        window.addEventListener('resize', function () {
            if (window.innerWidth > 1180) {
                closeMenu();
            }
        }, { passive: true });

        /* ---------------------------------------------------------
           STICKY HEADER STATE
        --------------------------------------------------------- */
        function updateHeader() {
            if (header) header.classList.toggle('scrolled', window.scrollY > 12);
        }
        window.addEventListener('scroll', updateHeader, { passive: true });
        updateHeader();

        /* ---------------------------------------------------------
           SCROLL PROGRESS + BACK TO TOP
        --------------------------------------------------------- */
        const progress = qs('#scrollProgress');
        const backTop = qs('#backToTop') || qs('#scrollTop');

        function updateScrollUI() {
            const doc = document.documentElement;
            const max = Math.max(0, doc.scrollHeight - window.innerHeight);
            const percent = max ? Math.min(100, (window.scrollY / max) * 100) : 0;

            if (progress) progress.style.width = percent + '%';

            if (backTop) {
                backTop.classList.toggle('show', window.scrollY > 450);
                backTop.style.display = window.scrollY > 450 ? 'grid' : 'none';
            }
        }

        window.addEventListener('scroll', updateScrollUI, { passive: true });
        window.addEventListener('resize', updateScrollUI, { passive: true });
        updateScrollUI();

        if (backTop) {
            backTop.addEventListener('click', function () {
                window.scrollTo({ top: 0, behavior: 'smooth' });
            });
        }

        /* ---------------------------------------------------------
           SWIPER
        --------------------------------------------------------- */
        if (window.Swiper) {
            qsa('.hero-slider.swiper, .hero-slider').forEach(function (slider) {
                if (slider.dataset.swiperInitialized === 'true') return;
                if (!slider.querySelector('.swiper-wrapper')) return;

                try {
                    new window.Swiper(slider, {
                        loop: slider.querySelectorAll('.swiper-slide').length > 1,
                        speed: 700,
                        effect: 'fade',
                        fadeEffect: { crossFade: true },
                        autoplay: {
                            delay: 5200,
                            disableOnInteraction: false,
                            pauseOnMouseEnter: true
                        },
                        pagination: {
                            el: slider.querySelector('.swiper-pagination'),
                            clickable: true
                        },
                        navigation: {
                            nextEl: slider.querySelector('.swiper-button-next'),
                            prevEl: slider.querySelector('.swiper-button-prev')
                        },
                        keyboard: { enabled: true },
                        a11y: { enabled: true },
                        observer: true,
                        observeParents: true
                    });
                    slider.dataset.swiperInitialized = 'true';
                } catch (error) {
                    console.warn('[PSA] Swiper initialization failed:', error);
                }
            });
        }

        /* ---------------------------------------------------------
           PASSWORD VISIBILITY
        --------------------------------------------------------- */
        qsa('[data-password-toggle]').forEach(function (button) {
            button.addEventListener('click', function () {
                const input = qs('#' + CSS.escape(button.dataset.passwordToggle));
                if (!input) return;

                const visible = input.type === 'text';
                input.type = visible ? 'password' : 'text';

                const icon = qs('i', button);
                if (icon) {
                    icon.className = visible
                        ? 'fa fa-eye'
                        : 'fa fa-eye-slash';
                }

                button.setAttribute('aria-label', visible ? 'Show password' : 'Hide password');
            });
        });

        /* ---------------------------------------------------------
           FAQ ACCORDIONS
        --------------------------------------------------------- */
        qsa('.faq-question').forEach(function (question) {
            question.setAttribute('role', 'button');
            question.setAttribute('tabindex', '0');

            const activate = function () {
                const item = question.closest('.faq-item');
                if (!item) return;

                const active = item.classList.toggle('active');
                question.setAttribute('aria-expanded', active ? 'true' : 'false');

                const icon = qs('i', question);
                const span = qs('span', question);

                if (icon) icon.className = active ? 'fa fa-minus' : 'fa fa-plus';
                if (span && !icon) span.textContent = active ? '−' : '+';
            };

            question.addEventListener('click', activate);
            question.addEventListener('keydown', function (event) {
                if (event.key === 'Enter' || event.key === ' ') {
                    event.preventDefault();
                    activate();
                }
            });
        });

        /* ---------------------------------------------------------
           PROGRAM FILTERS
        --------------------------------------------------------- */
        const programSearch = qs('#programSearch');
        const levelFilter = qs('#levelFilter');
        const areaFilter = qs('#areaFilter');
        const modeFilter = qs('#modeFilter');
        const programCards = qsa('.program-card');
        const noResult = qs('#noResult');

        function filterPrograms() {
            if (!programCards.length) return;

            const query = (programSearch?.value || '').trim().toLowerCase();
            const level = levelFilter?.value || 'all';
            const area = areaFilter?.value || 'all';
            const mode = modeFilter?.value || 'all';
            let visible = 0;

            programCards.forEach(function (card) {
                const text = card.textContent.toLowerCase();
                const matchQuery = !query || text.includes(query);
                const matchLevel = level === 'all' || card.dataset.level === level;
                const matchArea = area === 'all' || card.dataset.area === area;
                const matchMode = mode === 'all' || card.dataset.mode === mode;
                const show = matchQuery && matchLevel && matchArea && matchMode;

                card.hidden = !show;
                if (show) visible++;
            });

            if (noResult) noResult.hidden = visible !== 0;
        }

        [programSearch, levelFilter, areaFilter, modeFilter].forEach(function (element) {
            if (!element) return;
            element.addEventListener(element.tagName === 'INPUT' ? 'input' : 'change', filterPrograms);
        });
        filterPrograms();

        /* ---------------------------------------------------------
           PROFESSIONAL PROGRAM FILTERS
        --------------------------------------------------------- */
        const professionalTabs = qsa('.professional-tab');
        const professionalCards = qsa('.professional-program-card');
        const professionalSearch = qs('#professionalSearch');

        function filterProfessional() {
            if (!professionalCards.length) return;

            const activeTab = qs('.professional-tab.active');
            const type = activeTab?.dataset.type || 'all';
            const query = (professionalSearch?.value || '').trim().toLowerCase();

            let visible = 0;

            professionalCards.forEach(function (card) {
                const cardType = card.dataset.type || '';
                const text = card.textContent.toLowerCase();
                const show = (type === 'all' || cardType === type) &&
                    (!query || text.includes(query));

                card.hidden = !show;
                if (show) visible++;
            });

            const empty = qs('#professionalNoResult');
            if (empty) empty.hidden = visible !== 0;
        }

        professionalTabs.forEach(function (tab) {
            tab.addEventListener('click', function () {
                professionalTabs.forEach(function (item) {
                    item.classList.remove('active');
                    item.setAttribute('aria-selected', 'false');
                });
                tab.classList.add('active');
                tab.setAttribute('aria-selected', 'true');
                filterProfessional();
            });
        });

        if (professionalSearch) {
            professionalSearch.addEventListener('input', filterProfessional);
        }
        filterProfessional();

        /* ---------------------------------------------------------
           FORM UX
        --------------------------------------------------------- */
        qsa('form').forEach(function (form) {
            // Add visual focus state.
            qsa('input, select, textarea', form).forEach(function (field) {
                field.addEventListener('focus', function () {
                    field.closest('.form-group, .admin-form > div')?.classList.add('is-focused');
                });

                field.addEventListener('blur', function () {
                    field.closest('.form-group, .admin-form > div')?.classList.remove('is-focused');
                });

                // Clear an error state as soon as the user corrects a field.
                field.addEventListener('input', function () {
                    field.classList.remove('is-invalid');
                    const feedback = field.parentElement?.querySelector('.field-error');
                    if (feedback) feedback.remove();
                });
            });

            // HTML5 validation with a friendly message.
            form.addEventListener('submit', function (event) {
                if (form.dataset.allowInvalid === 'true') return;

                if (!form.checkValidity()) {
                    event.preventDefault();
                    event.stopPropagation();

                    const firstInvalid = qs(':invalid', form);
                    if (firstInvalid) {
                        firstInvalid.classList.add('is-invalid');
                        firstInvalid.focus({ preventScroll: true });
                        firstInvalid.scrollIntoView({ behavior: 'smooth', block: 'center' });
                    }

                    form.classList.add('was-validated');
                    return;
                }

                // Prevent accidental double submissions on POST forms.
                if ((form.method || 'get').toLowerCase() === 'post') {
                    const submit = qs('button[type="submit"], input[type="submit"]', form);
                    if (submit && !submit.disabled) {
                        submit.disabled = true;
                        submit.dataset.originalText = submit.innerHTML || submit.value || '';
                        if (submit.tagName === 'BUTTON') {
                            submit.innerHTML = '<i class="fa fa-spinner fa-spin"></i> Processing...';
                        } else {
                            submit.value = 'Processing...';
                        }
                    }
                }
            });
        });

        /* ---------------------------------------------------------
           SMOOTH INTERNAL LINKS
        --------------------------------------------------------- */
        qsa('a[href^="#"]').forEach(function (link) {
            link.addEventListener('click', function (event) {
                const href = link.getAttribute('href');
                if (!href || href === '#') return;

                const target = qs(href);
                if (!target) return;

                event.preventDefault();
                const headerOffset = header ? header.offsetHeight + 10 : 90;
                const top = target.getBoundingClientRect().top + window.scrollY - headerOffset;

                window.scrollTo({ top: Math.max(0, top), behavior: 'smooth' });
                history.replaceState(null, '', href);
            });
        });

        /* ---------------------------------------------------------
           BOOTSTRAP ENHANCEMENTS
        --------------------------------------------------------- */
        if (window.bootstrap) {
            qsa('[data-bs-toggle="tooltip"]').forEach(function (element) {
                try { new window.bootstrap.Tooltip(element); } catch (e) {}
            });

            qsa('[data-bs-toggle="popover"]').forEach(function (element) {
                try { new window.bootstrap.Popover(element); } catch (e) {}
            });
        }

        /* ---------------------------------------------------------
           JQUERY ENHANCEMENTS
        --------------------------------------------------------- */
        if ($) {
            $('.form-group input, .form-group select, .form-group textarea').on('focus', function () {
                $(this).closest('.form-group').addClass('is-focused');
            }).on('blur', function () {
                $(this).closest('.form-group').removeClass('is-focused');
            });
        }

        /* ---------------------------------------------------------
           REVEAL ANIMATIONS
        --------------------------------------------------------- */
        if ('IntersectionObserver' in window && !window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
            const observer = new IntersectionObserver(function (entries) {
                entries.forEach(function (entry) {
                    if (entry.isIntersecting) {
                        entry.target.classList.add('is-visible');
                        observer.unobserve(entry.target);
                    }
                });
            }, { threshold: 0.10 });

            qsa('.reveal, .card, .step, .stat-card, .image-panel, .program-card, .professional-program-card').forEach(function (element) {
                if (!element.classList.contains('reveal')) element.classList.add('reveal');
                observer.observe(element);
            });
        }

        /* ---------------------------------------------------------
           ACCESSIBILITY: ESC CLOSES UI
        --------------------------------------------------------- */
        document.addEventListener('keydown', function (event) {
            if (event.key === 'Escape') {
                closeMenu();
                qsa('.faq-item.active').forEach(function (item) {
                    item.classList.remove('active');
                });
            }
        });
    });

})(window, document);
