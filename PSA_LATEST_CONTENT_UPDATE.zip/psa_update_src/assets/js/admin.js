
document.addEventListener('DOMContentLoaded', function () {
  const toggle = document.getElementById('adminToggle');
  const sidebar = document.getElementById('adminSidebar');
  const overlay = document.getElementById('adminOverlay');

  function closeSidebar() {
    sidebar?.classList.remove('show');
    overlay?.classList.remove('show');
  }

  if (toggle && sidebar) {
    toggle.addEventListener('click', function () {
      const show = sidebar.classList.toggle('show');
      overlay?.classList.toggle('show', show);
    });
  }
  overlay?.addEventListener('click', closeSidebar);

  document.querySelectorAll('.admin-sidebar a').forEach(function (link) {
    link.addEventListener('click', function () {
      if (window.innerWidth <= 1100) closeSidebar();
    });
  });

  window.addEventListener('resize', function () {
    if (window.innerWidth > 1100) closeSidebar();
  });

  document.querySelectorAll('[data-confirm]').forEach(function (btn) {
    btn.addEventListener('click', function (e) {
      if (!window.confirm(this.dataset.confirm || 'Are you sure?')) e.preventDefault();
    });
  });

  // Generic AJAX-free table filter helper.
  document.querySelectorAll('[data-table-filter]').forEach(function (input) {
    const table = document.querySelector(input.dataset.tableFilter);
    if (!table) return;
    input.addEventListener('input', function () {
      const q = input.value.toLowerCase().trim();
      table.querySelectorAll('tbody tr').forEach(function (row) {
        row.style.display = row.textContent.toLowerCase().includes(q) ? '' : 'none';
      });
    });
  });

  // Password visibility.
  document.querySelectorAll('[data-password-toggle]').forEach(function (btn) {
    btn.addEventListener('click', function () {
      const input = document.getElementById(btn.dataset.passwordToggle);
      if (!input) return;
      input.type = input.type === 'password' ? 'text' : 'password';
    });
  });
});
