# PSA Final Modern PHP Site Deployment Guide

1. Backup your current public_html before replacing files.
2. Upload PSA_final_modern_php_site.zip into public_html.
3. Extract it. If it extracts into a folder, move the contents into public_html.
4. Confirm these files exist directly in public_html: index.php, about.php, programs.php, admissions.php, contact.php, includes/, assets/.
5. Update phone and email in includes/header.php, includes/footer.php, and contact.php.
6. Keep existing config.php, admin/, student/, php/, uploads/, and database.sql if you still need database/login functions.
7. Test index.php, programs.php, about.php, admissions.php, and contact.php.
8. The site uses CDN libraries: Google Fonts Montserrat/Roboto, Font Awesome 4.7, and Swiper.js carousel.
