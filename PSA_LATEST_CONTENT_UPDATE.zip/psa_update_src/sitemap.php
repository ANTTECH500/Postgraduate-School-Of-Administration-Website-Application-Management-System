<?php
declare(strict_types=1);
require_once __DIR__ . '/config.php';
header('Content-Type: application/xml; charset=UTF-8');
$baseUrl=rtrim(SITE_URL,'/');
$today=date('Y-m-d');
$pages=[
 ['/','daily','1.0'],['/about.php','monthly','0.8'],['/programs.php','weekly','1.0'],
 ['/services.php','weekly','0.95'],['/admissions.php','weekly','0.9'],['/apply.php','daily','1.0'],
 ['/track-application.php','daily','0.8'],['/partner-universities.php','monthly','0.8'],['/universities.php','monthly','0.7'],
 ['/scholarships.php','monthly','0.7'],['/accreditations.php','monthly','0.8'],['/events.php','weekly','0.7'],
 ['/blog.php','weekly','0.7'],['/location.php','monthly','0.9'],['/contact.php','monthly','0.9']
];
echo '<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n';
foreach($pages as [$path,$freq,$priority]){
 echo '<url><loc>'.htmlspecialchars($baseUrl.$path,ENT_XML1,'UTF-8').'</loc><lastmod>'.$today.'</lastmod><changefreq>'.$freq.'</changefreq><priority>'.$priority.'</priority></url>'."\n";
}
echo "</urlset>";
