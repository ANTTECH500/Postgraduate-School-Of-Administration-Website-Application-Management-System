# PSA Portal Consolidation & Site Settings

## What was consolidated
The current application uses one canonical data model:
- students
- applications
- programs
- documents
- messages
- tracking_logs
- lms_courses
- lms_enrollments
- admins
- partners
- notices
- system_settings
- professional_programs

The older alternate portal model (`users`, `student_profiles`, `application_documents`, `university_id`) is not used by the executable student/admin application.

## Central settings
`config.php` contains deployment defaults. `admin/settings.php` stores institutional overrides in `system_settings`.

## Current requested public identity
- Institution: Postgraduate School of Administration
- Primary URL: https://pas.institute
- Email: info@pas.institute
- Phones: +233 32 219 4448
- WhatsApp: +233 555 077 777
- Location: Ghana | Behind K. Poly / KsTU, Kumasi
- GPS: AK-040-9257

## Google
The website includes:
- canonical URLs
- Open Graph
- Twitter metadata
- EducationalOrganization JSON-LD
- service ItemList JSON-LD for Contact Us, Available Programmes, Location and Apply Now
- robots.txt
- sitemap.xml / dynamic sitemap.php

Google still decides whether and which sitelinks appear. These changes improve the signals but cannot force a specific Google result layout.

## Database
The production migration is additive. Back up the database before importing it.

## Namecheap
Use PHP 8.1+ and MySQL/MariaDB. Do not install WordPress for this application unless you intentionally migrate the architecture.

## Security
After deployment, rotate the database password because it has been shared during development.
