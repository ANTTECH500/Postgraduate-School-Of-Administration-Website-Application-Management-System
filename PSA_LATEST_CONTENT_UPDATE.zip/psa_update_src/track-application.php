<?php
require_once __DIR__ . '/config.php';
$result = null;
$logs = [];
$error = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf()) {
        $error = 'Your session security token expired. Please refresh and try again.';
    } else {
        $code = clean_input($_POST['reference_code'] ?? '');
        $stmt = $pdo->prepare("SELECT s.student_id,s.reference_code,s.full_name,a.id application_id,a.application_code,a.application_status,a.preferred_program,a.study_level,a.study_mode,a.created_at AS applied_at,p.title AS program_title
            FROM students s
            LEFT JOIN applications a ON a.student_id=s.id
            LEFT JOIN programs p ON a.program_id=p.id
            WHERE s.reference_code=? OR s.student_id=? OR a.application_code=?
            ORDER BY a.created_at DESC LIMIT 1");
        $stmt->execute([$code, $code, $code]);
        $result = $stmt->fetch();

        if ($result && !empty($result['application_id'])) {
            $logStmt = $pdo->prepare("SELECT status,note,created_at FROM tracking_logs WHERE application_id=? ORDER BY created_at ASC");
            $logStmt->execute([$result['application_id']]);
            $logs = $logStmt->fetchAll();
        }
        if (!$result) $error = 'No application was found with that Student ID, Reference Code or Application Code.';
    }
}
?>
<?php include 'includes/header.php'; ?>
<section class="module-hero"><div><div class="eyebrow">Application Tracking</div><h1>Track Your PSA Application</h1><p>Enter your Student ID, Reference Code or Application Code to view the latest application status.</p></div></section>
<section class="section light">
  <div class="section-title"><div class="eyebrow">Admissions Status</div><h2>Application Lookup</h2></div>
  <div class="form-card" style="max-width:820px;margin:auto">
    <?php if ($error): ?><div class="alert error"><i class="fa fa-exclamation-circle"></i> <?= e($error) ?></div><?php endif; ?>
    <form method="post">
      <?= csrf_field() ?>
      <div class="form-group"><label>Student ID / Reference Code / Application Code</label><input name="reference_code" required placeholder="PSA-2026-XXXXXXXX or APP-2026-XXXXXX"></div>
      <button class="btn btn-gold" type="submit"><i class="fa fa-search"></i> Search Application</button>
    </form>

    <?php if ($result): ?>
      <div class="status-card mt-4">
        <div class="d-flex justify-content-between align-items-center gap-3 flex-wrap mb-3">
          <div><span class="text-muted small">Applicant</span><h3 class="mb-0"><?= e($result['full_name']) ?></h3></div>
          <span class="badge"><?= e($result['application_status']) ?></span>
        </div>
        <div class="status-grid">
          <div class="status-item"><span>Student ID</span><strong><?= e($result['student_id']) ?></strong></div>
          <div class="status-item"><span>Reference Code</span><strong><?= e($result['reference_code']) ?></strong></div>
          <div class="status-item"><span>Application Code</span><strong><?= e($result['application_code']) ?></strong></div>
          <div class="status-item"><span>Program</span><strong><?= e($result['program_title'] ?: $result['preferred_program']) ?></strong></div>
          <div class="status-item"><span>Study Level</span><strong><?= e($result['study_level']) ?></strong></div>
          <div class="status-item"><span>Study Mode</span><strong><?= e($result['study_mode']) ?></strong></div>
        </div>
        <?php if ($logs): ?>
        <div class="mt-4"><h4>Application Timeline</h4>
          <?php foreach ($logs as $log): ?><div class="timeline-item"><strong><?= e($log['status']) ?></strong><p class="mb-1"><?= e($log['note']) ?></p><small class="text-muted"><?= e($log['created_at']) ?></small></div><?php endforeach; ?>
        </div>
        <?php endif; ?>
        <div class="hero-actions mt-3"><a class="btn btn-gold" href="/student-login.php"><i class="fa fa-user-circle"></i> Student Portal</a><a class="btn btn-outline" href="/contact.php"><i class="fa fa-comments"></i> Contact PSA</a></div>
      </div>
    <?php endif; ?>
  </div>
</section>
<?php include 'includes/footer.php'; ?>