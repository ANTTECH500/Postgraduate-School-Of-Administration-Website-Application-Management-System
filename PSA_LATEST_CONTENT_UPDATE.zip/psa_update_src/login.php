<?php
require_once __DIR__ . '/config.php';
if (!empty($_SESSION['student_id'])) {
    redirect_to('/student/dashboard.php');
}
redirect_to('/student-login.php');
?>