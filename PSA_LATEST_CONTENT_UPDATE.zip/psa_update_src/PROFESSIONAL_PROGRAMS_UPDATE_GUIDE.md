# Professional Programmes — Public Module Disabled

Per the latest PSA management instruction, the Professional Programmes module is not part of the public website or new application workflow. Existing database records are retained for historical/audit purposes and are not deleted.

The public navigation, sitemap and application form no longer expose professional-programme selections.
