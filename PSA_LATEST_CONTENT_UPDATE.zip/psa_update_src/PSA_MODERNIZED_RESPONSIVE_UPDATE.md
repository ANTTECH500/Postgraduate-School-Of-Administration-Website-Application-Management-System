PSA MODERNIZED RESPONSIVE WEBSITE — UPDATE PACKAGE
====================================================

This package is based on the uploaded PSA website repository.

WHAT WAS FIXED
--------------
1. Public header/footer class mismatch:
   - Existing markup used PSA-* classes while the stylesheet primarily
     used lowercase psa-* classes.
   - Header/footer markup is now consistent.

2. Responsive navigation:
   - Mobile menu opens/closes correctly.
   - Accessible aria-expanded state.
   - Outside-click and Escape-key closing.
   - Navigation resets correctly after resizing.

3. Public-site JavaScript:
   - Swiper carousel initialization.
   - Scroll progress and back-to-top.
   - FAQ keyboard/click interaction.
   - Program search/filtering.
   - Professional-program filtering.
   - Password visibility.
   - HTML5 form validation UX.
   - POST double-submit protection.
   - Bootstrap tooltip/popover support.
   - Smooth internal anchor scrolling.
   - Reveal animations with reduced-motion support.

4. Responsive CSS:
   - Desktop, laptop, tablet and mobile breakpoints.
   - Mobile application/login layouts.
   - Responsive forms.
   - Responsive accreditation logo grid.
   - Responsive tables with horizontal scrolling.
   - Student portal layout compatibility.
   - Admin mobile/touch improvements.

5. Cache busting:
   - CSS/JS references use version ?v=20260813.2 to prevent stale browser cache.

6. Production domain:
   - Site-facing configuration references are standardized to:
       https://psa.institute
       info@psa.institute
   - A database/psa_domain_update.sql file is included to update the
     existing system_settings table.

7. Diagnostics:
   - Public db-test.php and php-test.php were removed from the deployment
     package. Do not leave database diagnostic files publicly accessible.

DATABASE
--------
Current expected database:
  Host: localhost
  Database: psaiaogy_db
  User: psaiaogy_info

The existing production database has 13 tables and has already been
confirmed to contain PSA program, professional-program, LMS, partner,
notice, settings and admin data.

DEPLOYMENT
----------
1. Back up the current public_html directory and database.
2. Extract this package locally.
3. Upload/replace the website files in public_html.
4. Do NOT overwrite config.php blindly if it contains the current
   production database password. Merge only the intended configuration.
5. In phpMyAdmin, select psaiaogy_db and run:
       database/psa_domain_update.sql
6. Clear browser cache or perform a hard refresh.
7. Test:
       /
       /programs.php
       /apply.php
       /student-login.php
       /track-application.php
       /location.php
       /admin/login.php
8. Test the application using dummy data before accepting real applicants.

IMPORTANT SECURITY
------------------
- Rotate the MySQL password before production because it has been shared
  during troubleshooting.
- Do not upload diagnostic scripts containing database credentials.
- Keep config.php protected from direct source exposure.
- Use HTTPS only.
