<?php
/**
 * Central PSA site settings helper.
 * Database settings override config defaults.
 */
require_once __DIR__ . '/../config.php';

function psa_settings(): array {
    static $settings = null;

    if ($settings !== null) {
        return $settings;
    }

    $settings = [
        'institution_name' => SITE_NAME,
        'short_name' => SITE_SHORT_NAME,
        'website' => SITE_URL,
        'email' => SITE_EMAIL,
        'phone_1' => SITE_PHONE_ALT,
        'phone_2' => SITE_PHONE_DISPLAY,
        'whatsapp' => SITE_WHATSAPP,
        'address' => SITE_ADDRESS,
        'gps_address' => SITE_GPS,
        'map_query' => SITE_MAP_QUERY,
        'profile' => SITE_DESCRIPTION,
    ];

    try {
        $rows = $pdo->query('SELECT setting_key, setting_value FROM system_settings')->fetchAll();
        foreach ($rows as $row) {
            $key = (string)$row['setting_key'];
            if (array_key_exists($key, $settings) && trim((string)$row['setting_value']) !== '') {
                $settings[$key] = (string)$row['setting_value'];
            }
        }
    } catch (Throwable $e) {
        error_log('PSA settings read warning: ' . $e->getMessage());
    }

    return $settings;
}

function psa_setting(string $key, ?string $fallback = null): string {
    $settings = psa_settings();
    return (string)($settings[$key] ?? $fallback ?? '');
}

function psa_url(string $path = ''): string {
    return rtrim(psa_setting('website', SITE_URL), '/') . '/' . ltrim($path, '/');
}

function psa_phone_href(string $phone): string {
    return 'tel:' . preg_replace('/[^0-9+]/', '', $phone);
}

function psa_whatsapp_url(string $message = ''): string {
    $number = preg_replace('/[^0-9]/', '', psa_setting('whatsapp', SITE_WHATSAPP));
    $url = 'https://wa.me/' . $number;
    if ($message !== '') {
        $url .= '?text=' . rawurlencode($message);
    }
    return $url;
}
?>