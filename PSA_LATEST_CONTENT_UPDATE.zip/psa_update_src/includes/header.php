<?php
require_once __DIR__ . '/site.php';

$currentPage = basename($_SERVER['PHP_SELF']);
function isActive($page) {
    global $currentPage;
    return $currentPage === $page ? 'active' : '';
}

$siteName = psa_setting('institution_name', SITE_NAME);
$siteUrl = rtrim(psa_setting('website', SITE_URL), '/');
$siteEmail = psa_setting('email', SITE_EMAIL);
$phone1 = psa_setting('phone_1', SITE_PHONE_ALT);
$phone2 = psa_setting('phone_2', SITE_PHONE_DISPLAY);
$address = psa_setting('address', SITE_ADDRESS);
$description = psa_setting('profile', SITE_DESCRIPTION);
$requestPath = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
$currentUrl = $siteUrl . ('/' === $requestPath ? '/' : '/' . ltrim($requestPath, '/'));
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= e($siteName) ?> | Ghana</title>
<meta name="description" content="<?= e($description) ?>">
<meta name="robots" content="index,follow,max-image-preview:large,max-snippet:-1,max-video-preview:-1">
<link rel="canonical" href="<?= e($currentUrl) ?>">
<meta property="og:type" content="website">
<meta property="og:title" content="<?= e($siteName) ?>">
<meta property="og:description" content="<?= e($description) ?>">
<meta property="og:url" content="<?= e($currentUrl) ?>">
<meta property="og:image" content="<?= e($siteUrl) ?>/assets/images/psa-logo.png">
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="<?= e($siteName) ?>">
<meta name="twitter:description" content="<?= e($description) ?>">
<link rel="icon" type="image/png" href="/assets/images/psa-logo.png">
<link rel="apple-touch-icon" href="/assets/images/psa-logo.png">
<meta name="theme-color" content="#0B1F3A">
<link rel="sitemap" type="application/xml" href="/sitemap.xml">

<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@600;700;800;900&family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
<link rel="stylesheet" href="/assets/css/psa-modern.css?v=20260813.2">
<link rel="stylesheet" href="/assets/css/student.css?v=20260813.2">
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>

<!-- Search-engine understanding of PSA's main navigation. Google decides sitelinks algorithmically. -->
<script type="application/ld+json">
<?= json_encode([
    '@context' => 'https://schema.org',
    '@type' => 'EducationalOrganization',
    'name' => $siteName,
    'alternateName' => 'PSA',
    'url' => $siteUrl,
    'logo' => $siteUrl . '/assets/images/psa-logo.png',
    'email' => 'mailto:' . $siteEmail,
    'telephone' => [$phone1, $phone2],
    'address' => [
        '@type' => 'PostalAddress',
        'streetAddress' => $address,
        'addressLocality' => 'Kumasi',
        'addressCountry' => 'GH'
    ],
    'contactPoint' => [
        '@type' => 'ContactPoint',
        'contactType' => 'admissions',
        'telephone' => $phone1,
        'email' => $siteEmail,
        'availableLanguage' => ['English']
    ]
], JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT) ?>
</script>
<script type="application/ld+json">
<?= json_encode([
    '@context' => 'https://schema.org',
    '@type' => 'ItemList',
    'name' => 'PSA Main Services',
    'itemListElement' => [
        ['@type'=>'ListItem','position'=>1,'name'=>'Contact Us','url'=>$siteUrl.'/contact.php'],
        ['@type'=>'ListItem','position'=>2,'name'=>'Available Programmes','url'=>$siteUrl.'/programs.php'],
        ['@type'=>'ListItem','position'=>3,'name'=>'Location','url'=>$siteUrl.'/location.php'],
        ['@type'=>'ListItem','position'=>4,'name'=>'Apply Now','url'=>$siteUrl.'/apply.php']
    ]
], JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT) ?>
</script>
</head>
<body>
<div class="scroll-progress" id="scrollProgress"></div>

<div class="psa-topbar">
    <div><i class="fa fa-map-marker"></i> <?= e($address) ?> | Admissions Support</div>
    <div class="topbar-links">
        <a href="<?= e(psa_phone_href($phone1)) ?>"><i class="fa fa-phone"></i> <?= e($phone1) ?></a>
        <?php if($phone2): ?><a href="<?= e(psa_phone_href($phone2)) ?>"><?= e($phone2) ?></a><?php endif; ?>
        <a href="mailto:<?= e($siteEmail) ?>"><i class="fa fa-envelope"></i> <?= e($siteEmail) ?></a>
        <a href="<?= e(psa_whatsapp_url('Hello PSA, I would like admissions information.')) ?>" target="_blank" rel="noopener"><i class="fa fa-whatsapp"></i> WhatsApp</a>
    </div>
</div>

<header class="psa-header" id="siteHeader">
<nav class="psa-navbar">
<a class="psa-logo" href="/" aria-label="<?= e($siteName) ?> home">
    <img src="/assets/images/psa-logo.png" alt="<?= e($siteName) ?> logo">
    <span><strong>PSA</strong><small><?= e($siteName) ?></small></span>
</a>

<button class="menu-toggle" id="menuToggle" aria-label="Toggle navigation"><i class="fa fa-bars"></i></button>

<ul class="psa-menu" id="PSAMenu">
<li><a class="<?= isActive('index.php') ?>" href="/">Home</a></li>
<li><a class="<?= isActive('about.php') ?>" href="/about.php">About PSA</a></li>
<li><a class="<?= isActive('programs.php') ?>" href="/programs.php">Available Programmes</a></li>
<li><a class="<?= isActive('services.php') ?>" href="/services.php">Services</a></li>
<li><a class="<?= isActive('partner-universities.php') ?>" href="/partner-universities.php">Partner Universities</a></li>
<li><a class="<?= isActive('scholarships.php') ?>" href="/scholarships.php">Scholarships</a></li>
<li><a class="<?= isActive('admissions.php') ?>" href="/admissions.php">Admissions</a></li>
<li><a class="<?= isActive('accreditations.php') ?>" href="/accreditations.php">Accreditations</a></li>
<li><a class="<?= isActive('events.php') ?>" href="/events.php">Events</a></li>
<li><a class="<?= isActive('blog.php') ?>" href="/blog.php">Blog</a></li>
<li><a class="<?= isActive('location.php') ?>" href="/location.php">Location</a></li>
<li><a class="<?= isActive('contact.php') ?>" href="/contact.php">Contact Us</a></li>
</ul>

<div class="nav-actions">
<a class="btn btn-outline" href="/location.php"><i class="fa fa-map-marker"></i> Location</a>
<a class="btn btn-gold" href="/apply.php"><i class="fa fa-paper-plane"></i> Apply Now</a>
</div>
</nav>
</header>
