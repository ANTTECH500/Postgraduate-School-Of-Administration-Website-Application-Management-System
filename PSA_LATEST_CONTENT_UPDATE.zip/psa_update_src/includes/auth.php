<?php
require_once __DIR__ . '/../config.php';
function require_student_login(){ if(!isset($_SESSION['student_id'])) redirect_to('../student-login.php'); }
function current_student(){ global $pdo; if(!isset($_SESSION['student_id'])) return null; $stmt=$pdo->prepare('SELECT * FROM students WHERE id=?'); $stmt->execute([$_SESSION['student_id']]); return $stmt->fetch(); }
?>