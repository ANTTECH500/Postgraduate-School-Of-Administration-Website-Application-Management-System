<?php
require_once __DIR__ . '/site.php';
$siteName = psa_setting('institution_name', SITE_NAME);
$siteEmail = psa_setting('email', SITE_EMAIL);
$phone1 = psa_setting('phone_1', SITE_PHONE_ALT);
$phone2 = psa_setting('phone_2', SITE_PHONE_DISPLAY);
$address = psa_setting('address', SITE_ADDRESS);
?>
<footer class="psa-footer">
<div class="footer-grid">
<div>
<img class="footer-logo" src="/assets/images/psa-logo.png" alt="<?= e($siteName) ?> Logo">
<h3>PSA</h3>
<p><?= e(psa_setting('profile', SITE_DESCRIPTION)) ?></p>
</div>
<div><h4>Explore</h4>
<a href="/about.php">About PSA</a><a href="/programs.php">Available Programmes</a><a href="/services.php">PSA Services</a><a href="/partner-universities.php">Partner Universities</a><a href="/scholarships.php">Scholarships</a></div>
<div><h4>Student Services</h4>
<a href="/admissions.php">Admissions</a><a href="/apply.php">Apply Now</a><a href="/track-application.php">Track Application</a><a href="/student-portal.php">Student Portal</a><a href="/location.php">Location</a></div>
<div><h4>Contact PSA</h4>
<p><i class="fa fa-phone"></i> <?= e($phone1) ?><?php if($phone2): ?> / <?= e($phone2) ?><?php endif; ?></p>
<p><i class="fa fa-envelope"></i> <a href="mailto:<?= e($siteEmail) ?>"><?= e($siteEmail) ?></a></p>
<p><i class="fa fa-map-marker"></i> <?= e($address) ?></p>
<a class="btn btn-gold" href="<?= e(psa_whatsapp_url('Hello PSA, I would like to make an enquiry.')) ?>" target="_blank" rel="noopener"><i class="fa fa-whatsapp"></i> WhatsApp PSA</a>
</div>
</div>
<div class="footer-bottom"><p>© <?= date('Y') ?> <?= e($siteName) ?>. All rights reserved.</p></div>
</footer>
<button class="back-to-top" id="backToTop" aria-label="Back to top"><i class="fa fa-angle-up"></i></button>
<script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="/assets/js/psa-modern.js?v=20260813.2"></script>
</body></html>