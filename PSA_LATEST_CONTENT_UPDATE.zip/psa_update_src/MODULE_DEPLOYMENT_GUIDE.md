# PSA Student Application + Tracking + Communication + LMS Module

Deploy by uploading this ZIP to public_html, extracting it, importing database.sql in phpMyAdmin, and updating DB credentials in config.php.

Test these pages:
- apply.php
- track-application.php
- student-login.php
- student/dashboard.php

Next phase: admin application to manage applications, programs, statuses, messages, documents, LMS and reports.
