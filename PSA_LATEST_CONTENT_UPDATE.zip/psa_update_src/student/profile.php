<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/auth.php';
require_student_login();
$student = current_student();
$message = null;
$error = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fullName = clean_input($_POST['full_name'] ?? '');
    $phone = clean_input($_POST['phone'] ?? '');
    $gender = clean_input($_POST['gender'] ?? '');
    $nationality = clean_input($_POST['nationality'] ?? '');
    $address = clean_input($_POST['address'] ?? '');
    $qualification = clean_input($_POST['highest_qualification'] ?? '');

    if ($fullName === '' || $phone === '') {
        $error = 'Full name and phone number are required.';
    } else {
        $stmt = $pdo->prepare('UPDATE students SET full_name=?, phone=?, gender=?, nationality=?, address=?, highest_qualification=? WHERE id=?');
        $stmt->execute([$fullName, $phone, $gender, $nationality, $address, $qualification, $student['id']]);
        $student = current_student();
        $message = 'Profile updated successfully.';
    }
}
?>
<?php include '../includes/header.php'; ?>
<div class="dashboard-wrap">
  <aside class="dashboard-sidebar">
    <div class="portal-brand"><img src="../assets/images/psa-logo.png" alt="PSA"><div><strong>PSA</strong><small>Student Portal</small></div></div>
    <nav>
      <a href="dashboard.php"><i class="fa fa-dashboard"></i> Dashboard</a>
      <a href="applications.php"><i class="fa fa-file-text"></i> My Applications</a>
      <a class="active" href="profile.php"><i class="fa fa-user"></i> My Profile</a>
      <a href="documents.php"><i class="fa fa-folder-open"></i> Documents</a>
      <a href="messages.php"><i class="fa fa-envelope"></i> Messages</a>
      <a href="lms.php"><i class="fa fa-book"></i> LMS</a>
      <a href="../track-application.php"><i class="fa fa-search"></i> Track Application</a>
      <a href="logout.php"><i class="fa fa-sign-out"></i> Logout</a>
    </nav>
  </aside>
  <main class="dashboard-main">
    <div class="admin-page-actions"><div><div class="eyebrow">Student Portal</div><h1>My Profile</h1><p>Keep your contact and academic information up to date.</p></div></div>
    <?php if ($message): ?><div class="alert success"><?= e($message) ?></div><?php endif; ?>
    <?php if ($error): ?><div class="alert error"><?= e($error) ?></div><?php endif; ?>
    <div class="form-card">
      <div class="form-grid">
        <div class="form-group full"><label>Student ID</label><input value="<?= e($student['student_id']) ?>" disabled></div>
        <div class="form-group full"><label>Reference Code</label><input value="<?= e($student['reference_code']) ?>" disabled></div>
        <div class="form-group full"><label>Email Address</label><input value="<?= e($student['email']) ?>" disabled></div>
        <form method="post" class="form-grid full" style="grid-column:1/-1">
          <div class="form-group"><label>Full Name *</label><input name="full_name" value="<?= e($student['full_name']) ?>" required></div>
          <div class="form-group"><label>Phone *</label><input name="phone" value="<?= e($student['phone']) ?>" required></div>
          <div class="form-group"><label>Gender</label><select name="gender"><option value="">Select</option><option <?= $student['gender']==='Male'?'selected':'' ?>>Male</option><option <?= $student['gender']==='Female'?'selected':'' ?>>Female</option><option <?= $student['gender']==='Other'?'selected':'' ?>>Other</option></select></div>
          <div class="form-group"><label>Nationality</label><input name="nationality" value="<?= e($student['nationality']) ?>"></div>
          <div class="form-group"><label>Highest Qualification</label><input name="highest_qualification" value="<?= e($student['highest_qualification']) ?>"></div>
          <div class="form-group"><label>Address</label><input name="address" value="<?= e($student['address']) ?>"></div>
          <div class="full"><button class="btn btn-gold" type="submit"><i class="fa fa-save"></i> Save Profile</button></div>
        </form>
      </div>
    </div>
  </main>
</div>
<?php include '../includes/footer.php'; ?>