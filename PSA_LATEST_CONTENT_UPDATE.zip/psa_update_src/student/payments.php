<?php
declare(strict_types=1);
require_once '../includes/auth.php';
require_student_login();
$student=current_student();
$stmt=$pdo->prepare("SELECT * FROM payment_records WHERE student_id=? ORDER BY created_at DESC");$stmt->execute([$student['id']]);$payments=$stmt->fetchAll();
?>
<?php include '../includes/header.php';?>
<div class="dashboard-wrap"><aside class="sidebar"><img src="../assets/images/psa-logo.png"><h3><?=e($student['full_name'])?></h3><p><?=e($student['student_id'])?></p><a href="dashboard.php"><i class="fa fa-dashboard"></i> Dashboard</a><a class="active" href="payments.php"><i class="fa fa-credit-card"></i> Payments</a><a href="notifications.php"><i class="fa fa-bell"></i> Notifications</a><a href="messages.php"><i class="fa fa-envelope"></i> Messages</a><a href="logout.php"><i class="fa fa-sign-out"></i> Logout</a></aside><main class="dashboard-main"><div class="status-timeline"><h2>Payment Records</h2><p>Your PSA fee/payment records are shown below.</p><div class="admin-table-wrap"><table class="admin-table"><thead><tr><th>Reference</th><th>Type</th><th>Amount</th><th>Status</th><th>Date</th></tr></thead><tbody><?php foreach($payments as $p):?><tr><td><?=e($p['reference_code'])?></td><td><?=e($p['payment_type'])?></td><td><?=e($p['currency'])?> <?=number_format((float)$p['amount'],2)?></td><td><?=e($p['status'])?></td><td><?=e($p['created_at'])?></td></tr><?php endforeach;?><?php if(!$payments):?><tr><td colspan="5">No payment records found.</td></tr><?php endif;?></tbody></table></div></div></main></div>
<?php include '../includes/footer.php';?>