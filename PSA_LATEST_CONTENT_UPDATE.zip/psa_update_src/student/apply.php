<?php
// Canonical application form lives at the public PSA application endpoint.
header('Location: /apply.php');
exit;
?>