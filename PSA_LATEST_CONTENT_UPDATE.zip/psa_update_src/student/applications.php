<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/auth.php';
require_student_login();
$student = current_student();
$stmt = $pdo->prepare("SELECT a.*, p.title AS program_title FROM applications a LEFT JOIN programs p ON p.id=a.program_id WHERE a.student_id=? ORDER BY a.created_at DESC");
$stmt->execute([$student['id']]);
$applications = $stmt->fetchAll();
?>
<?php include '../includes/header.php'; ?>
<div class="dashboard-wrap">
  <aside class="dashboard-sidebar">
    <div class="portal-brand"><img src="../assets/images/psa-logo.png" alt="PSA"><div><strong>PSA</strong><small>Student Portal</small></div></div>
    <nav>
      <a href="dashboard.php"><i class="fa fa-dashboard"></i> Dashboard</a>
      <a class="active" href="applications.php"><i class="fa fa-file-text"></i> My Applications</a>
      <a href="profile.php"><i class="fa fa-user"></i> My Profile</a>
      <a href="documents.php"><i class="fa fa-folder-open"></i> Documents</a>
      <a href="messages.php"><i class="fa fa-envelope"></i> Messages</a>
      <a href="lms.php"><i class="fa fa-book"></i> LMS</a>
      <a href="../track-application.php"><i class="fa fa-search"></i> Track Application</a>
      <a href="logout.php"><i class="fa fa-sign-out"></i> Logout</a>
    </nav>
  </aside>
  <main class="dashboard-main">
    <div class="admin-page-actions"><div><div class="eyebrow">Student Portal</div><h1>My Applications</h1><p>Review your submitted applications and their current status.</p></div><a class="btn btn-gold" href="../apply.php"><i class="fa fa-plus"></i> New Application</a></div>
    <?php if (!$applications): ?>
      <div class="admin-empty"><i class="fa fa-file-text-o"></i><h3>No applications yet</h3><p>Start your PSA application to receive a Student ID and Reference Code.</p><a class="btn btn-gold" href="../apply.php">Apply Now</a></div>
    <?php else: ?>
      <div class="admin-table-wrap">
        <table class="admin-table">
          <thead><tr><th>Application</th><th>Program</th><th>Study</th><th>Status</th><th>Submitted</th></tr></thead>
          <tbody>
          <?php foreach ($applications as $a): ?>
            <tr>
              <td><strong><?= e($a['application_code']) ?></strong><br><small><?= e($student['reference_code']) ?></small></td>
              <td><?= e($a['program_title'] ?: $a['preferred_program']) ?></td>
              <td><?= e($a['study_level']) ?><br><?= e($a['study_mode']) ?></td>
              <td><span class="badge-status <?= e(strtok($a['application_status'], ' ')) ?>"><?= e($a['application_status']) ?></span></td>
              <td><?= e($a['created_at']) ?></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>
  </main>
</div>
<?php include '../includes/footer.php'; ?>