<?php
declare(strict_types=1);
require_once '../includes/auth.php';
require_student_login();
$student=current_student();
if(isset($_GET['read'])){
 $stmt=$pdo->prepare("UPDATE student_notifications SET read_at=NOW() WHERE id=? AND student_id=?");$stmt->execute([(int)$_GET['read'],$student['id']]);
 header('Location: notifications.php');exit;
}
$stmt=$pdo->prepare("SELECT * FROM student_notifications WHERE student_id=? ORDER BY created_at DESC");$stmt->execute([$student['id']]);$notifications=$stmt->fetchAll();
?>
<?php include '../includes/header.php';?>
<div class="dashboard-wrap"><aside class="sidebar"><img src="../assets/images/psa-logo.png"><h3><?=e($student['full_name'])?></h3><p><?=e($student['student_id'])?></p><a href="dashboard.php"><i class="fa fa-dashboard"></i> Dashboard</a><a class="active" href="notifications.php"><i class="fa fa-bell"></i> Notifications</a><a href="messages.php"><i class="fa fa-envelope"></i> Messages</a><a href="applications.php"><i class="fa fa-file-text"></i> Applications</a><a href="documents.php"><i class="fa fa-upload"></i> Documents</a><a href="lms.php"><i class="fa fa-book"></i> LMS</a><a href="logout.php"><i class="fa fa-sign-out"></i> Logout</a></aside><main class="dashboard-main"><div class="status-timeline"><h2>Notifications</h2><p>Application, admissions and student-support updates from PSA.</p><?php foreach($notifications as $n):?><article class="message-card <?=empty($n['read_at'])?'unread':''?>"><div class="d-flex justify-content-between gap-3"><strong><?=e($n['title'])?></strong><small><?=e($n['created_at'])?></small></div><span class="badge-status"><?=e($n['notification_type'])?></span><p><?=nl2br(e($n['message']))?></p><?php if(empty($n['read_at'])):?><a href="?read=<?=$n['id']?>">Mark as read</a><?php endif;?></article><?php endforeach;?><?php if(!$notifications):?><p>No notifications yet.</p><?php endif;?></div></main></div>
<?php include '../includes/footer.php';?>