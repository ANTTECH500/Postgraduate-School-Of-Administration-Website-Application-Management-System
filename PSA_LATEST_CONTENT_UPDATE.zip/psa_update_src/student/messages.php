<?php
declare(strict_types=1);
require_once '../includes/auth.php';
require_student_login();
$student=current_student();$notice=$error=null;
if($_SERVER['REQUEST_METHOD']==='POST'){
 if(!verify_csrf()){$error='Security token expired. Refresh and try again.';}
 else{
  $subject=clean_input($_POST['subject']??'');$message=clean_input($_POST['message']??'');
  if($subject===''||$message===''){$error='Subject and message are required.';}
  else{
   try{$stmt=$pdo->prepare("INSERT INTO messages(student_id,sender_type,subject,message) VALUES(?,'Student',?,?)");$stmt->execute([$student['id'],$subject,$message]);$notice='Your message has been sent to PSA.';}
   catch(Throwable $e){$error='Unable to send your message right now.';error_log('[PSA] Student message: '.$e->getMessage());}
  }
 }
}
if(isset($_GET['read'])){$stmt=$pdo->prepare("UPDATE messages SET is_read=1 WHERE id=? AND student_id=?");try{$stmt->execute([(int)$_GET['read'],$student['id']]);}catch(Throwable $e){}}
$stmt=$pdo->prepare("SELECT * FROM messages WHERE student_id=? ORDER BY created_at DESC");$stmt->execute([$student['id']]);$messages=$stmt->fetchAll();
?>
<?php include '../includes/header.php'; ?>
<div class="dashboard-wrap"><aside class="sidebar"><img src="../assets/images/psa-logo.png"><h3><?=e($student['full_name'])?></h3><p><?=e($student['student_id'])?></p><a href="dashboard.php"><i class="fa fa-dashboard"></i> Dashboard</a><a class="active" href="messages.php"><i class="fa fa-envelope"></i> Messages</a><a href="applications.php"><i class="fa fa-file-text"></i> Applications</a><a href="documents.php"><i class="fa fa-upload"></i> Documents</a><a href="lms.php"><i class="fa fa-book"></i> LMS</a><a href="logout.php"><i class="fa fa-sign-out"></i> Logout</a></aside>
<main class="dashboard-main"><div class="status-timeline"><h2>Messages &amp; Support</h2><p>Communicate directly with the PSA admissions and student-support team.</p><?php if($notice):?><div class="alert success"><?=e($notice)?></div><?php endif;?><?php if($error):?><div class="alert error"><?=e($error)?></div><?php endif;?>
<form method="post" class="admin-form"><?=csrf_field()?><div><label>Subject</label><input name="subject" required></div><div class="full"><label>Message</label><textarea name="message" rows="5" required></textarea></div><div class="full"><button class="btn btn-gold">Send Message</button></div></form></div>
<div class="status-timeline"><h3>Conversation History</h3><?php foreach($messages as $m):?><article class="message-card <?=empty($m['is_read'])&&$m['sender_type']==='Admin'?'unread':''?>"><div class="d-flex justify-content-between gap-3"><strong><?=e($m['subject'])?></strong><small><?=e($m['created_at'])?></small></div><small><?=e($m['sender_type'])?></small><p><?=nl2br(e($m['message']))?></p><?php if($m['sender_type']==='Admin'&&!empty($m['is_read'])===false):?><a href="?read=<?=$m['id']?>">Mark as read</a><?php endif;?></article><?php endforeach;?><?php if(!$messages):?><p>No messages yet.</p><?php endif;?></div></main></div>
<?php include '../includes/footer.php';?>